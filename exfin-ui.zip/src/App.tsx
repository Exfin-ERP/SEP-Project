import { useState, useMemo, useEffect, useCallback } from 'react';
import { SidebarProvider, SidebarInset, SidebarTrigger } from "./components/ui/sidebar";
import { Separator } from "./components/ui/separator";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "./components/ui/breadcrumb";
import { Toaster } from "./components/ui/sonner";
import { toast } from "sonner@2.0.3";
import { AuthProvider, useAuth } from './components/AuthContext';
import { LoginPage } from './components/LoginPage';
import { OTPVerification } from './components/OTPVerification';
import { RoleGuard } from './components/RoleGuard';
import { AppSidebar } from './components/AppSidebar';
import { Dashboard } from './components/Dashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminPortal } from './components/AdminPortal';
import { BranchManagement } from './components/BranchManagement';
import { AccountantDashboard } from './components/AccountantDashboard';
import { ManagementDashboard } from './components/ManagementDashboard';
import { ExpenseForm, type Expense } from './components/ExpenseForm';
import { RealTimeExpenseForm } from './components/RealTimeExpenseForm';
import { TransactionList } from './components/TransactionList';
import { Analytics } from './components/Analytics';
import { PrintBills } from './components/PrintBills';
import { BalanceTracker } from './components/BalanceTracker';
import { MoneyRequest } from './components/MoneyRequest';
import { EmployeeWelfareRequest } from './components/EmployeeWelfareRequest';
import { ReceiptsHub } from './components/ReceiptsHub';
import { SchoolFeeReceipt } from './components/SchoolFeeReceipt';
import { IdCardFeeReceipt } from './components/IdCardFeeReceipt';
import { FeeCancellationRequest } from './components/FeeCancellationRequest';
import { ExamFeeReceipt } from './components/ExamFeeReceipt';
import { EventManagementReceipt } from './components/EventManagementReceipt';
import { VendorRegistration } from './components/VendorRegistration';
import { VendorPayment } from './components/VendorPayment';
import { RevenueManagement } from './components/RevenueManagement';
import { ExpenditureManagement } from './components/ExpenditureManagement';
import { StudentManagement } from './components/StudentManagement';

// Sample data
const initialExpenses: Expense[] = [
  {
    id: '1',
    amount: 45000,
    category: 'MESS EXPENSES',
    description: 'Mess van diesel and groceries',
    date: new Date('2024-12-15'),
    notes: 'Monthly mess expenses',
    campus: 'SRIVEN BC-1',
    natureOfWork: 'Mess van diesel and groceries',
    paymentMode: 'CASH',
    utilityType: 'MESS EXPENSES',
    billStatus: true,
    paymentStatus: 'Paid',
    authorizedBy: 'PSN SIR',
    accountantName: 'Rajesh Kumar',
    status: 'Pending',
    teamAssigned: 'Sriven Team'
  },
  {
    id: '2',
    amount: 15000,
    category: 'ELECTRICITY EXPENSES',
    description: 'Monthly electricity bill',
    date: new Date('2024-12-14'),
    campus: 'SONTYAM',
    natureOfWork: 'Monthly electricity bill payment',
    paymentMode: 'ONLINE',
    utilityType: 'ELECTRICITY EXPENSES',
    billStatus: true,
    paymentStatus: 'Unpaid',
    authorizedBy: 'MANAGEMENT',
    accountantName: 'Priya Sharma',
    status: 'Approved',
    teamAssigned: 'Pragyana Team'
  },
  {
    id: '3',
    amount: 8500,
    category: 'MAINTENANCE',
    description: 'Building maintenance work',
    date: new Date('2024-12-13'),
    notes: 'Roof repair and painting',
    campus: 'SRIVEN DC-1',
    natureOfWork: 'Building maintenance and repairs',
    paymentMode: 'CHEQUE',
    utilityType: 'MAINTENANCE',
    billStatus: false,
    paymentStatus: 'Advance',
    authorizedBy: 'DIRECTOR',
    accountantName: 'Suresh Babu',
    status: 'Pending',
    teamAssigned: 'Sriven Team'
  }
];

const defaultCategories = [
  'Food & Dining',
  'Transportation',
  'Entertainment',
  'Shopping',
  'Utilities',
  'Healthcare',
  'Education',
  'Travel',
  'Insurance',
  'Other'
];

function MainApp() {
  const { isAuthenticated, otpSent, user } = useAuth();

  // ALL HOOKS MUST BE CALLED FIRST - before any conditional returns
  const [expenses, setExpenses] = useState<Expense[]>(initialExpenses);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [categories, setCategories] = useState<string[]>(defaultCategories);
  const [activeView, setActiveView] = useState('dashboard');
  
  // Set initial view based on user role (only runs when user changes)
  useEffect(() => {
    if (!user) return;
    
    let newView = 'dashboard';
    if (user.role === 'Admin') {
      newView = 'admin';
    } else if (user.role === 'Accountant') {
      newView = 'accountant-dashboard';
    } else if (user.role === 'Management') {
      newView = 'management-dashboard';
    }
    
    // Only update if the view is different to prevent unnecessary re-renders
    setActiveView(prevView => prevView === newView ? prevView : newView);
  }, [user?.id, user?.role]); // Track both ID and role but prevent loops

  // Calculate dashboard data - only when needed for dashboard views
  const dashboardData = useMemo(() => {
    // Only calculate if we're on a dashboard view to save performance
    if (!activeView.includes('dashboard') && activeView !== 'analytics') {
      return {
        totalExpenses: 0,
        monthlyExpenses: 0,
        categoryData: [],
        monthlyTrends: []
      };
    }

    if (!expenses.length) {
      return {
        totalExpenses: 0,
        monthlyExpenses: 0,
        categoryData: [],
        monthlyTrends: []
      };
    }

    try {
      const now = new Date();
      const currentMonth = now.getMonth();
      const currentYear = now.getFullYear();

      // Pre-filter current month expenses for better performance
      const currentMonthExpenses = expenses.filter(expense => {
        if (!expense.date) return false;
        const expenseDate = new Date(expense.date);
        return expenseDate.getMonth() === currentMonth && 
               expenseDate.getFullYear() === currentYear;
      });

      // Current month expenses
      const monthlyExpenses = currentMonthExpenses.reduce((sum, expense) => sum + (expense.amount || 0), 0);

      // Total expenses
      const totalExpenses = expenses.reduce((sum, expense) => sum + (expense.amount || 0), 0);

      // Category data for pie chart - limit to top 8 categories
      const categoryTotals = currentMonthExpenses.reduce((acc, expense) => {
        if (expense.category) {
          acc[expense.category] = (acc[expense.category] || 0) + (expense.amount || 0);
        }
        return acc;
      }, {} as Record<string, number>);

      const colors = ['#8884d8', '#82ca9d', '#ffc658', '#ff7300', '#00ff00', '#ff00ff', '#00ffff', '#ffff00'];
      const categoryData = Object.entries(categoryTotals)
        .sort(([,a], [,b]) => b - a) // Sort by amount
        .slice(0, 8) // Limit to top 8
        .map(([name, value], index) => ({
          name,
          value: Math.round(value),
          color: colors[index % colors.length]
        }));

      // Monthly trends (last 6 months) - simplified
      const monthlyTrends = [];
      for (let i = 5; i >= 0; i--) {
        const date = new Date(currentYear, currentMonth - i, 1);
        const monthName = date.toLocaleDateString('en-US', { month: 'short' });
        
        const monthTotal = expenses
          .filter(expense => {
            if (!expense.date) return false;
            const expenseDate = new Date(expense.date);
            return expenseDate.getMonth() === date.getMonth() && 
                   expenseDate.getFullYear() === date.getFullYear();
          })
          .reduce((sum, expense) => sum + (expense.amount || 0), 0);
        
        monthlyTrends.push({
          month: monthName,
          amount: Math.round(monthTotal)
        });
      }

      return {
        totalExpenses,
        monthlyExpenses,
        categoryData,
        monthlyTrends
      };
    } catch (error) {
      console.error('Error calculating dashboard data:', error);
      return {
        totalExpenses: 0,
        monthlyExpenses: 0,
        categoryData: [],
        monthlyTrends: []
      };
    }
  }, [expenses, activeView]); // Include activeView to optimize calculations

  // Memoize filtered data to prevent recalculation on every render - MUST BE WITH OTHER HOOKS
  const filteredPendingExpenses = useMemo(() => 
    expenses.filter(e => e.status === 'Pending' && e.accountantName === user?.name),
    [expenses, user?.name]
  );

  // ALL CALLBACK HOOKS MUST BE HERE BEFORE CONDITIONAL RETURNS
  const handleAddExpense = useCallback(() => {
    setEditingExpense(null);
    setActiveView('add');
  }, []);

  const handleSaveExpense = useCallback((expenseData: Omit<Expense, 'id'>) => {
    try {
      if (editingExpense) {
        // Update existing expense
        setExpenses(prev => prev.map(expense => 
          expense.id === editingExpense.id 
            ? { ...expenseData, id: editingExpense.id }
            : expense
        ));
        toast.success('Expense updated successfully');
      } else {
        // Add new expense
        const newExpense: Expense = {
          ...expenseData,
          id: `exp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
        };
        setExpenses(prev => [...prev, newExpense]);
        toast.success('Expense added successfully');
      }

      // Add new category if it doesn't exist
      if (expenseData.category && !categories.includes(expenseData.category)) {
        setCategories(prev => [...prev, expenseData.category]);
      }

      setEditingExpense(null);
      
      // Return to appropriate dashboard based on user role
      const roleViewMap: Record<string, string> = {
        'Admin': 'admin',
        'Accountant': 'accountant-dashboard',
        'Management': 'management-dashboard'
      };
      
      const targetView = roleViewMap[user?.role || ''] || 'dashboard';
      setActiveView(targetView);
    } catch (error) {
      console.error('Error saving expense:', error);
      toast.error('Failed to save expense. Please try again.');
    }
  }, [editingExpense, categories, user?.role]);

  const handleEditExpense = useCallback((expense: Expense) => {
    setEditingExpense(expense);
    setActiveView('add');
  }, []);

  const handleDeleteExpense = useCallback((id: string) => {
    try {
      setExpenses(prev => prev.filter(expense => expense.id !== id));
      toast.success('Expense deleted successfully');
    } catch (error) {
      console.error('Error deleting expense:', error);
      toast.error('Failed to delete expense. Please try again.');
    }
  }, []);

  const handleCancelEdit = useCallback(() => {
    setEditingExpense(null);
    
    // Return to appropriate dashboard based on user role
    const roleViewMap: Record<string, string> = {
      'Admin': 'admin',
      'Accountant': 'accountant-dashboard',
      'Management': 'management-dashboard'
    };
    
    const targetView = roleViewMap[user?.role || ''] || 'dashboard';
    setActiveView(targetView);
  }, [user?.role]);

  // NOW handle conditional rendering after ALL hooks are called
  if (!isAuthenticated) {
    if (otpSent) {
      return <OTPVerification />;
    }
    return <LoginPage />;
  }

  // Add loading state while user data is being processed
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const getPageTitle = () => {
    switch (activeView) {
      case 'dashboard': return 'Dashboard';
      case 'accountant-dashboard': return 'Accountant Dashboard';
      case 'management-dashboard': return 'Management Dashboard';
      case 'admin': return 'Admin Portal';
      case 'branch-management': return 'Branch Management';
      case 'user-management': return 'User Management';
      case 'add': return editingExpense ? 'Edit Expense' : 'Book Expenditure';
      case 'student-management': return 'Student Management';
      case 'staff-management': return 'Staff Management';
      case 'revenue-management': return 'Revenue Management';
      case 'expenditure-management': return 'Expenditure Management';
      case 'examination': return 'Examination Management';
      case 'library': return 'Library Management';
      case 'transport': return 'Transport Management';
      case 'hostel-mess': return 'Hostel & Mess Management';
      case 'inventory': return 'Inventory Management';
      case 'transactions': return 'Transactions';
      case 'analytics': return 'Analytics';
      case 'print-bills': return 'Print Bills';
      case 'balance-tracker': return 'Balance Tracker';
      case 'pending-approvals': return 'Pending Approvals';
      case 'money-request': return 'Money Request';
      case 'employee-welfare': return 'Employee Welfare Request';
      case 'receipts': return 'Receipts Management';
      case 'school-fee-receipt': return 'School Fee Receipt';
      case 'id-card-fee-receipt': return 'ID Card Fee Receipt';
      case 'fee-cancellation-request': return 'Fee Cancellation Request Form';
      case 'exam-fee-receipt': return 'Exam Fee Receipt';
      case 'event-management-receipt': return 'Event Management Receipt';
      case 'vendor-registration': return 'Vendor Registration';
      case 'vendor-payments': return 'Vendor Payments';
      default: return 'Dashboard';
    }
  };

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return (
          <RoleGuard allowedRoles={['Management', 'Viewer']}>
            <Dashboard
              totalExpenses={dashboardData.totalExpenses}
              monthlyExpenses={dashboardData.monthlyExpenses}
              categoryData={dashboardData.categoryData}
              monthlyTrends={dashboardData.monthlyTrends}
              onAddExpense={handleAddExpense}
            />
          </RoleGuard>
        );
      case 'accountant-dashboard':
        return (
          <RoleGuard allowedRoles={['Accountant']}>
            <AccountantDashboard
              onNavigate={setActiveView}
              expenses={expenses}
              onAddExpense={handleAddExpense}
            />
          </RoleGuard>
        );
      case 'management-dashboard':
        return (
          <RoleGuard allowedRoles={['Management']}>
            <ManagementDashboard />
          </RoleGuard>
        );
      case 'admin':
        return (
          <RoleGuard 
            allowedRoles={['Admin']}
            fallbackMessage="This is admin-only section for vendor registration and management."
          >
            <AdminPortal onNavigate={setActiveView} />
          </RoleGuard>
        );
      case 'branch-management':
        return (
          <RoleGuard allowedRoles={['Admin']}>
            <BranchManagement />
          </RoleGuard>
        );
      case 'user-management':
        return (
          <RoleGuard allowedRoles={['Admin']}>
            <div className="text-center py-12">
              <h2 className="text-2xl mb-4">User Management Module</h2>
              <p className="text-muted-foreground mb-4">
                Manage all system users, roles, and permissions.
              </p>
              <p className="text-sm text-muted-foreground">
                This module is currently under development.
              </p>
            </div>
          </RoleGuard>
        );
      case 'add':
        return (
          <RoleGuard 
            allowedRoles={['Management', 'Accountant']}
            fallbackMessage="Only Management and Accountant users can add expenses."
          >
            <RealTimeExpenseForm
              expense={editingExpense}
              onSave={() => {
                setEditingExpense(null);
                const roleViewMap: Record<string, string> = {
                  'Admin': 'admin',
                  'Accountant': 'accountant-dashboard',
                  'Management': 'management-dashboard'
                };
                const targetView = roleViewMap[user?.role || ''] || 'dashboard';
                setActiveView(targetView);
              }}
              onCancel={handleCancelEdit}
            />
          </RoleGuard>
        );
      case 'transactions':
        return (
          <RoleGuard allowedRoles={['Management', 'Accountant', 'Viewer']}>
            <TransactionList
              expenses={expenses}
              categories={categories}
              onEdit={handleEditExpense}
              onDelete={handleDeleteExpense}
            />
          </RoleGuard>
        );
      case 'analytics':
        return (
          <RoleGuard 
            allowedRoles={['Management', 'Accountant']}
            fallbackMessage="Analytics are only available to Management and Accountant users."
          >
            <Analytics expenses={expenses} />
          </RoleGuard>
        );
      case 'print-bills':
        return (
          <RoleGuard allowedRoles={['Accountant']}>
            <PrintBills expenses={expenses} />
          </RoleGuard>
        );
      case 'balance-tracker':
        return (
          <RoleGuard allowedRoles={['Accountant']}>
            <BalanceTracker expenses={expenses} />
          </RoleGuard>
        );
      case 'pending-approvals':
        return (
          <RoleGuard allowedRoles={['Accountant']}>
            <TransactionList
              expenses={filteredPendingExpenses}
              categories={categories}
              onEdit={handleEditExpense}
              onDelete={handleDeleteExpense}
              title="Pending Approvals"
              description="Transactions awaiting management approval"
            />
          </RoleGuard>
        );
      case 'money-request':
        return (
          <RoleGuard allowedRoles={['Accountant', 'Management', 'Admin']}>
            <MoneyRequest />
          </RoleGuard>
        );
      case 'employee-welfare':
        return (
          <RoleGuard allowedRoles={['Accountant', 'Management', 'Admin']}>
            <EmployeeWelfareRequest />
          </RoleGuard>
        );
      case 'receipts':
        return (
          <RoleGuard allowedRoles={['Accountant', 'Management', 'Admin']}>
            <ReceiptsHub onNavigate={setActiveView} />
          </RoleGuard>
        );
      case 'school-fee-receipt':
        return (
          <RoleGuard allowedRoles={['Accountant', 'Management', 'Admin']}>
            <SchoolFeeReceipt />
          </RoleGuard>
        );
      case 'id-card-fee-receipt':
        return (
          <RoleGuard allowedRoles={['Accountant', 'Management', 'Admin']}>
            <IdCardFeeReceipt />
          </RoleGuard>
        );
      case 'fee-cancellation-request':
        return (
          <RoleGuard allowedRoles={['Accountant', 'Management', 'Admin']}>
            <FeeCancellationRequest />
          </RoleGuard>
        );
      case 'exam-fee-receipt':
        return (
          <RoleGuard allowedRoles={['Accountant', 'Management', 'Admin']}>
            <ExamFeeReceipt />
          </RoleGuard>
        );
      case 'event-management-receipt':
        return (
          <RoleGuard allowedRoles={['Accountant', 'Management', 'Admin']}>
            <EventManagementReceipt />
          </RoleGuard>
        );
      case 'vendor-registration':
        return (
          <RoleGuard allowedRoles={['Admin']}>
            <VendorRegistration />
          </RoleGuard>
        );
      case 'vendor-payments':
        return (
          <RoleGuard allowedRoles={['Admin']}>
            <VendorPayment />
          </RoleGuard>
        );
      case 'revenue-management':
        return (
          <RoleGuard allowedRoles={['Admin', 'Management', 'Accountant']}>
            <RevenueManagement />
          </RoleGuard>
        );
      case 'expenditure-management':
        return (
          <RoleGuard allowedRoles={['Admin', 'Management', 'Accountant']}>
            <ExpenditureManagement />
          </RoleGuard>
        );
      case 'student-management':
        return (
          <RoleGuard allowedRoles={['Admin', 'Management']}>
            <StudentManagement />
          </RoleGuard>
        );
      case 'staff-management':
      case 'examination':
      case 'library':
      case 'transport':
      case 'hostel-mess':
      case 'inventory':
        return (
          <RoleGuard allowedRoles={['Admin', 'Management']}>
            <div className="text-center py-12">
              <h2 className="text-2xl mb-4">Module Coming Soon</h2>
              <p className="text-muted-foreground mb-4">
                The {getPageTitle()} module is currently under development.
              </p>
              <p className="text-sm text-muted-foreground">
                Database schema and API endpoints are ready. UI implementation in progress.
              </p>
            </div>
          </RoleGuard>
        );
      default:
        return (
          <div className="text-center py-8">
            <p>Page not found</p>
          </div>
        );
    }
  };

  try {
    return (
      <SidebarProvider>
        <AppSidebar activeView={activeView} onViewChange={setActiveView} />
        <SidebarInset>
          <header className="flex h-16 shrink-0 items-center gap-2 transition-[width,height] ease-linear group-has-[[data-collapsible=icon]]/sidebar-wrapper:h-12">
            <div className="flex items-center justify-between w-full gap-2 px-4">
              <div className="flex items-center gap-2">
                <SidebarTrigger className="-ml-1" />
                <Separator orientation="vertical" className="mr-2 h-4" />
                <Breadcrumb>
                  <BreadcrumbList>
                    <BreadcrumbItem className="hidden md:block">
                      <BreadcrumbLink href="#">Sri Venkateswara Enterprises</BreadcrumbLink>
                    </BreadcrumbItem>
                    <BreadcrumbSeparator className="hidden md:block" />
                    <BreadcrumbItem>
                      <BreadcrumbPage>{getPageTitle()}</BreadcrumbPage>
                    </BreadcrumbItem>
                  </BreadcrumbList>
                </Breadcrumb>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span>Welcome, {user?.name || 'User'}</span>
                <span className="text-xs bg-primary/10 px-2 py-1 rounded">{user?.role}</span>
              </div>
            </div>
          </header>
          <div className="flex flex-1 flex-col gap-4 p-4 pt-0">
            {renderContent()}
          </div>
        </SidebarInset>
        <Toaster />
      </SidebarProvider>
    );
  } catch (error) {
    console.error('App render error:', error);
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-xl mb-4">Something went wrong</h2>
          <p className="text-muted-foreground">Please refresh the page to try again.</p>
        </div>
      </div>
    );
  }
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}