// Real-Time Service for Broadcasting Updates
import { RealTimeUpdate } from '../database/models';

type UpdateListener = (update: RealTimeUpdate) => void;

export class RealTimeService {
  private listeners: Map<string, UpdateListener[]> = new Map();
  private globalListeners: UpdateListener[] = [];

  // Subscribe to real-time updates for a specific user
  subscribe(userId: string, listener: UpdateListener): () => void {
    if (!this.listeners.has(userId)) {
      this.listeners.set(userId, []);
    }
    
    this.listeners.get(userId)!.push(listener);
    
    // Return unsubscribe function
    return () => {
      const userListeners = this.listeners.get(userId);
      if (userListeners) {
        const index = userListeners.indexOf(listener);
        if (index > -1) {
          userListeners.splice(index, 1);
        }
        
        // Clean up empty listener arrays
        if (userListeners.length === 0) {
          this.listeners.delete(userId);
        }
      }
    };
  }

  // Subscribe to all real-time updates (for admin/management)
  subscribeGlobal(listener: UpdateListener): () => void {
    this.globalListeners.push(listener);
    
    return () => {
      const index = this.globalListeners.indexOf(listener);
      if (index > -1) {
        this.globalListeners.splice(index, 1);
      }
    };
  }

  // Broadcast update to specific users or roles
  async broadcastUpdate(update: RealTimeUpdate): Promise<void> {
    try {
      // Broadcast to global listeners (admin/management dashboards)
      this.globalListeners.forEach(listener => {
        try {
          listener(update);
        } catch (error) {
          console.error('Error in global listener:', error);
        }
      });

      // Broadcast to specific affected users
      if (update.affected_users) {
        for (const userOrRole of update.affected_users) {
          // If it's a role, broadcast to all users with that role
          if (['Admin', 'Management', 'Accountant', 'Viewer'].includes(userOrRole)) {
            this.broadcastToRole(userOrRole, update);
          } else {
            // It's a specific user ID
            const userListeners = this.listeners.get(userOrRole);
            if (userListeners) {
              userListeners.forEach(listener => {
                try {
                  listener(update);
                } catch (error) {
                  console.error(`Error in user listener for ${userOrRole}:`, error);
                }
              });
            }
          }
        }
      }

      // Always notify the user who triggered the update
      const initiatorListeners = this.listeners.get(update.user_id);
      if (initiatorListeners) {
        initiatorListeners.forEach(listener => {
          try {
            listener(update);
          } catch (error) {
            console.error(`Error in initiator listener for ${update.user_id}:`, error);
          }
        });
      }

      // Log the update for debugging
      console.log(`Real-time update broadcasted: ${update.type}`, {
        timestamp: update.timestamp,
        user_id: update.user_id,
        affected_users: update.affected_users
      });

    } catch (error) {
      console.error('Error broadcasting real-time update:', error);
    }
  }

  // Broadcast to all users with a specific role
  private broadcastToRole(role: string, update: RealTimeUpdate): void {
    // In a real implementation, you would query the database for users with this role
    // For now, we'll iterate through all listeners and check their role
    // This is a simplified approach - in production, you'd maintain role-based listener maps
    
    this.listeners.forEach((listeners, userId) => {
      // In a real app, you'd check the user's role from the database
      // For this mock implementation, we'll broadcast to all listeners
      // as we don't have role information readily available
      listeners.forEach(listener => {
        try {
          listener(update);
        } catch (error) {
          console.error(`Error in role-based listener for ${userId}:`, error);
        }
      });
    });
  }

  // Get connection status
  getConnectionStatus(): { totalConnections: number; userConnections: number } {
    const userConnections = Array.from(this.listeners.values())
      .reduce((total, listeners) => total + listeners.length, 0);
    
    return {
      totalConnections: userConnections + this.globalListeners.length,
      userConnections
    };
  }

  // Ping all connected clients (heartbeat)
  async pingClients(): Promise<void> {
    const pingUpdate: RealTimeUpdate = {
      type: 'TRANSACTION_UPDATED', // Using existing type for compatibility
      data: { type: 'PING' },
      timestamp: new Date().toISOString(),
      user_id: 'system'
    };

    // Send ping to all listeners
    this.globalListeners.forEach(listener => {
      try {
        listener(pingUpdate);
      } catch (error) {
        console.error('Error in ping to global listener:', error);
      }
    });

    this.listeners.forEach((listeners) => {
      listeners.forEach(listener => {
        try {
          listener(pingUpdate);
        } catch (error) {
          console.error('Error in ping to user listener:', error);
        }
      });
    });
  }

  // Clean up disconnected clients (would be called periodically)
  cleanup(): void {
    // Remove empty listener arrays
    const emptyUsers = Array.from(this.listeners.entries())
      .filter(([_, listeners]) => listeners.length === 0)
      .map(([userId, _]) => userId);

    emptyUsers.forEach(userId => {
      this.listeners.delete(userId);
    });
  }
}

// Singleton instance for app-wide use
export const realTimeService = new RealTimeService();

// Auto-cleanup every 5 minutes
setInterval(() => {
  realTimeService.cleanup();
}, 5 * 60 * 1000);

// Heartbeat every 30 seconds
setInterval(() => {
  realTimeService.pingClients();
}, 30 * 1000);