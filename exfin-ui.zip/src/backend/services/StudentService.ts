/**
 * Student Service Layer
 * Handles business logic and integration between frontend and Student API
 */

import { studentAPI, Student, StudentFilters, StudentResponse } from '../api/StudentAPI';

/**
 * Student Service
 * Provides a clean interface for frontend components to interact with student data
 */
export class StudentService {
  /**
   * Create a new student
   */
  async createStudent(studentData: Omit<Student, 'id' | 'createdAt' | 'updatedAt'>, userId: number): Promise<StudentResponse> {
    try {
      return await studentAPI.createStudent(studentData, userId);
    } catch (error) {
      console.error('StudentService: Error creating student:', error);
      return {
        success: false,
        error: {
          code: 'SERVICE_ERROR',
          message: 'Failed to create student',
          details: error
        }
      };
    }
  }

  /**
   * Get student by ID
   */
  async getStudentById(studentId: string): Promise<Student | null> {
    try {
      return await studentAPI.getStudentById(studentId);
    } catch (error) {
      console.error('StudentService: Error fetching student:', error);
      return null;
    }
  }

  /**
   * Get students with filters
   */
  async getStudents(filters: StudentFilters = {}): Promise<StudentResponse> {
    try {
      return await studentAPI.getStudents(filters);
    } catch (error) {
      console.error('StudentService: Error fetching students:', error);
      return {
        success: false,
        error: {
          code: 'SERVICE_ERROR',
          message: 'Failed to fetch students',
          details: error
        }
      };
    }
  }

  /**
   * Update student
   */
  async updateStudent(studentId: string, updates: Partial<Student>, userId: number): Promise<StudentResponse> {
    try {
      return await studentAPI.updateStudent(studentId, updates, userId);
    } catch (error) {
      console.error('StudentService: Error updating student:', error);
      return {
        success: false,
        error: {
          code: 'SERVICE_ERROR',
          message: 'Failed to update student',
          details: error
        }
      };
    }
  }

  /**
   * Delete student (soft delete)
   */
  async deleteStudent(studentId: string, userId: number): Promise<StudentResponse> {
    try {
      return await studentAPI.deleteStudent(studentId, userId);
    } catch (error) {
      console.error('StudentService: Error deleting student:', error);
      return {
        success: false,
        error: {
          code: 'SERVICE_ERROR',
          message: 'Failed to delete student',
          details: error
        }
      };
    }
  }

  /**
   * Bulk upload students from CSV/Excel
   */
  async bulkUploadStudents(students: Omit<Student, 'id' | 'createdAt' | 'updatedAt'>[], userId: number): Promise<StudentResponse> {
    try {
      return await studentAPI.bulkUploadStudents(students, userId);
    } catch (error) {
      console.error('StudentService: Error in bulk upload:', error);
      return {
        success: false,
        error: {
          code: 'SERVICE_ERROR',
          message: 'Failed to complete bulk upload',
          details: error
        }
      };
    }
  }

  /**
   * Get students by class
   */
  async getStudentsByClass(classGrade: string, section?: string, organizationId?: number): Promise<StudentResponse> {
    return this.getStudents({
      classGrade,
      section,
      organizationId,
      status: 'Active'
    });
  }

  /**
   * Get students by academic year
   */
  async getStudentsByAcademicYear(academicYear: string, organizationId?: number): Promise<StudentResponse> {
    return this.getStudents({
      academicYear,
      organizationId,
      status: 'Active'
    });
  }

  /**
   * Search students
   */
  async searchStudents(searchTerm: string, organizationId?: number): Promise<StudentResponse> {
    return this.getStudents({
      search: searchTerm,
      organizationId
    });
  }

  /**
   * Get student summary statistics
   */
  async getStudentSummary(organizationId?: number): Promise<{
    totalStudents: number;
    activeStudents: number;
    maleStudents: number;
    femaleStudents: number;
    byClass: { [key: string]: number };
    byStatus: { [key: string]: number };
  }> {
    try {
      const response = await this.getStudents({ organizationId, limit: 1 });
      
      if (!response.success || !response.summary) {
        return {
          totalStudents: 0,
          activeStudents: 0,
          maleStudents: 0,
          femaleStudents: 0,
          byClass: {},
          byStatus: {}
        };
      }

      // Additional queries for detailed breakdown
      // This would be implemented with proper database queries
      return {
        ...response.summary,
        byClass: {}, // Would be populated from database
        byStatus: {}  // Would be populated from database
      };
    } catch (error) {
      console.error('StudentService: Error getting summary:', error);
      return {
        totalStudents: 0,
        activeStudents: 0,
        maleStudents: 0,
        femaleStudents: 0,
        byClass: {},
        byStatus: {}
      };
    }
  }

  /**
   * Promote students to next class
   */
  async promoteStudents(studentIds: string[], newClass: string, newAcademicYear: string, userId: number): Promise<StudentResponse> {
    try {
      let successCount = 0;
      let failCount = 0;
      const errors: any[] = [];

      for (const studentId of studentIds) {
        const result = await this.updateStudent(studentId, {
          classGrade: newClass,
          academicYear: newAcademicYear,
          section: '', // Reset section
          rollNumber: '' // Reset roll number
        }, userId);

        if (result.success) {
          successCount++;
        } else {
          failCount++;
          errors.push({ studentId, error: result.error });
        }
      }

      return {
        success: true,
        message: `Promotion completed: ${successCount} successful, ${failCount} failed`,
        data: { successCount, failCount, errors } as any
      };
    } catch (error) {
      console.error('StudentService: Error promoting students:', error);
      return {
        success: false,
        error: {
          code: 'SERVICE_ERROR',
          message: 'Failed to promote students',
          details: error
        }
      };
    }
  }

  /**
   * Transfer student to different branch/organization
   */
  async transferStudent(
    studentId: string,
    newOrganizationId: number,
    newBranchId: number,
    transferDate: Date,
    userId: number
  ): Promise<StudentResponse> {
    try {
      // Update student with new organization/branch
      const result = await this.updateStudent(studentId, {
        organizationId: newOrganizationId,
        branchId: newBranchId,
        status: 'Active' // Reactivate if transferred
      }, userId);

      if (result.success) {
        // Log transfer in audit trail
        // This would be implemented with proper audit logging
        return {
          success: true,
          data: result.data,
          message: 'Student transferred successfully'
        };
      }

      return result;
    } catch (error) {
      console.error('StudentService: Error transferring student:', error);
      return {
        success: false,
        error: {
          code: 'SERVICE_ERROR',
          message: 'Failed to transfer student',
          details: error
        }
      };
    }
  }

  /**
   * Mark student as passed out
   */
  async markAsPassedOut(studentId: string, passingDate: Date, userId: number): Promise<StudentResponse> {
    try {
      return await this.updateStudent(studentId, {
        status: 'Passed Out'
      }, userId);
    } catch (error) {
      console.error('StudentService: Error marking student as passed out:', error);
      return {
        success: false,
        error: {
          code: 'SERVICE_ERROR',
          message: 'Failed to mark student as passed out',
          details: error
        }
      };
    }
  }

  /**
   * Validate admission number format
   */
  validateAdmissionNumber(admissionNumber: string, organizationId: number): boolean {
    const patterns = {
      1: /^PRAG-\d{4}-\d{3,4}$/,  // Pragyana
      2: /^SRIV-\d{4}-\d{3,4}$/,  // Sriven
      3: /^SVEN-\d{4}-\d{3,4}$/   // Sri Venkateswara Enterprises
    };

    const pattern = patterns[organizationId as keyof typeof patterns];
    return pattern ? pattern.test(admissionNumber) : true;
  }

  /**
   * Parse CSV/Excel data for bulk upload
   */
  parseUploadData(data: any[]): Omit<Student, 'id' | 'createdAt' | 'updatedAt'>[] {
    return data.map(row => ({
      studentId: '',
      admissionNumber: row['Admission Number'] || row['admission_number'],
      firstName: row['First Name'] || row['first_name'],
      lastName: row['Last Name'] || row['last_name'],
      fullName: `${row['First Name'] || row['first_name']} ${row['Last Name'] || row['last_name']}`,
      dateOfBirth: new Date(row['Date of Birth'] || row['dob']),
      gender: row['Gender'] || row['gender'] as 'Male' | 'Female' | 'Other',
      classGrade: row['Class'] || row['class'],
      section: row['Section'] || row['section'] || '',
      rollNumber: row['Roll Number'] || row['roll_number'] || '',
      academicYear: row['Academic Year'] || row['academic_year'] || '2024-25',
      admissionDate: new Date(row['Admission Date'] || row['admission_date'] || new Date()),
      status: 'Active' as const,
      parentPhone: row['Parent Phone'] || row['parent_phone'],
      parentEmail: row['Parent Email'] || row['parent_email'],
      email: row['Email'] || row['email'],
      phone: row['Phone'] || row['phone'],
      address: row['Address'] || row['address'],
      city: row['City'] || row['city'],
      state: row['State'] || row['state'],
      pincode: row['Pincode'] || row['pincode'],
      bloodGroup: row['Blood Group'] || row['blood_group'],
      caste: row['Caste'] || row['caste'],
      religion: row['Religion'] || row['religion'],
      fatherName: row['Father Name'] || row['father_name'],
      motherName: row['Mother Name'] || row['mother_name'],
      guardianName: row['Guardian Name'] || row['guardian_name']
    }));
  }
}

// Export singleton instance
export const studentService = new StudentService();
