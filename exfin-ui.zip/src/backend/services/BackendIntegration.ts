// Backend Integration Service - Connects Frontend to Backend APIs
import TransactionAPI from '../api/TransactionAPI';
import ManagementAPI from '../api/ManagementAPI';
import { RealTimeService } from './RealTimeService';
import { 
  Transaction, ApiResponse, PaginatedResponse, TransactionFilters, 
  SortOptions, CategorySummary, DailySummary, MonthlySummary 
} from '../database/models';

// Frontend Integration Layer
class BackendIntegrationService {
  private transactionAPI: TransactionAPI;
  private managementAPI: ManagementAPI;
  private realTimeService: RealTimeService;
  private currentUserId: string | null = null;

  constructor() {
    this.transactionAPI = new TransactionAPI();
    this.managementAPI = new ManagementAPI();
    this.realTimeService = new RealTimeService();
  }

  // Set current user context
  setCurrentUser(userId: string): void {
    this.currentUserId = userId;
  }

  // Subscribe to real-time updates
  subscribeToUpdates(callback: (update: any) => void): () => void {
    if (!this.currentUserId) {
      throw new Error('User must be set before subscribing to updates');
    }
    
    return this.realTimeService.subscribe(this.currentUserId, callback);
  }

  // Subscribe to global updates (for admin/management)
  subscribeToGlobalUpdates(callback: (update: any) => void): () => void {
    return this.realTimeService.subscribeGlobal(callback);
  }

  // Transaction Management Methods
  async createTransaction(transactionData: Omit<Transaction, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<Transaction>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.transactionAPI.createTransaction(transactionData, this.currentUserId);
  }

  async updateTransaction(transactionId: string, updates: Partial<Transaction>): Promise<ApiResponse<Transaction>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.transactionAPI.updateTransaction(transactionId, updates, this.currentUserId);
  }

  async approveTransaction(transactionId: string, remarks?: string): Promise<ApiResponse<Transaction>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.transactionAPI.approveTransaction(transactionId, this.currentUserId, remarks);
  }

  async rejectTransaction(transactionId: string, reason: string): Promise<ApiResponse<Transaction>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.transactionAPI.rejectTransaction(transactionId, this.currentUserId, reason);
  }

  async getTransactions(
    filters?: TransactionFilters,
    sort?: SortOptions,
    page = 1,
    limit = 50
  ): Promise<ApiResponse<PaginatedResponse<Transaction>>> {
    return await this.transactionAPI.getTransactions(filters, sort, page, limit, this.currentUserId || undefined);
  }

  async getTransactionById(transactionId: string): Promise<ApiResponse<Transaction>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.transactionAPI.getTransactionById(transactionId, this.currentUserId);
  }

  async deleteTransaction(transactionId: string): Promise<ApiResponse<boolean>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.transactionAPI.deleteTransaction(transactionId, this.currentUserId);
  }

  // Management Dashboard Methods
  async getDashboardOverview(): Promise<ApiResponse<any>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.managementAPI.getDashboardOverview(this.currentUserId);
  }

  async getCategoryAnalytics(startDate?: string, endDate?: string): Promise<ApiResponse<any>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.managementAPI.getCategoryAnalytics(this.currentUserId, startDate, endDate);
  }

  async getCashFlowAnalytics(
    period: 'daily' | 'weekly' | 'monthly' = 'daily',
    days = 30
  ): Promise<ApiResponse<any>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.managementAPI.getCashFlowAnalytics(this.currentUserId, period, days);
  }

  async getUserPerformanceAnalytics(startDate?: string, endDate?: string): Promise<ApiResponse<any>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.managementAPI.getUserPerformanceAnalytics(this.currentUserId, startDate, endDate);
  }

  async getSystemHealth(): Promise<ApiResponse<any>> {
    if (!this.currentUserId) {
      throw new Error('User context required');
    }
    
    return await this.managementAPI.getSystemHealth(this.currentUserId);
  }

  // Utility Methods for Frontend Integration

  // Format currency for display
  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  }

  // Format date for display
  formatDate(date: string | Date): string {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj.toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }

  // Format datetime for display
  formatDateTime(date: string | Date): string {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj.toLocaleString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  // Get status badge color
  getStatusColor(status: string): string {
    switch (status) {
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800';
      case 'APPROVED':
        return 'bg-green-100 text-green-800';
      case 'REJECTED':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  // Get payment mode icon
  getPaymentModeIcon(mode: string): string {
    switch (mode) {
      case 'CASH':
        return '💵';
      case 'ONLINE':
        return '💳';
      case 'CHEQUE':
        return '📝';
      case 'UPI':
        return '📱';
      case 'CARD':
        return '💳';
      default:
        return '💰';
    }
  }

  // Validate transaction data
  validateTransactionData(data: Partial<Transaction>): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!data.amount || data.amount <= 0) {
      errors.push('Amount must be greater than zero');
    }

    if (!data.category_id) {
      errors.push('Category is required');
    }

    if (!data.description || data.description.trim().length === 0) {
      errors.push('Description is required');
    }

    if (!data.payment_mode) {
      errors.push('Payment mode is required');
    }

    if (!data.transaction_date) {
      errors.push('Transaction date is required');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  // Calculate budget utilization
  calculateBudgetUtilization(spent: number, budget: number): {
    percentage: number;
    status: 'SAFE' | 'WARNING' | 'DANGER';
    remaining: number;
  } {
    const percentage = (spent / budget) * 100;
    let status: 'SAFE' | 'WARNING' | 'DANGER';

    if (percentage >= 100) {
      status = 'DANGER';
    } else if (percentage >= 80) {
      status = 'WARNING';
    } else {
      status = 'SAFE';
    }

    return {
      percentage: Math.round(percentage * 100) / 100,
      status,
      remaining: Math.max(0, budget - spent)
    };
  }

  // Generate report data for export
  async generateReportData(
    type: 'transactions' | 'categories' | 'users',
    filters?: any
  ): Promise<any[]> {
    switch (type) {
      case 'transactions':
        const transactionsResult = await this.getTransactions(filters, undefined, 1, 1000);
        return transactionsResult.data?.data || [];
      
      case 'categories':
        const categoriesResult = await this.getCategoryAnalytics();
        return categoriesResult.data?.categories || [];
      
      case 'users':
        const usersResult = await this.getUserPerformanceAnalytics();
        return usersResult.data?.user_stats || [];
      
      default:
        return [];
    }
  }

  // Handle API errors gracefully
  handleApiError(error: any): string {
    if (error.response?.data?.message) {
      return error.response.data.message;
    } else if (error.message) {
      return error.message;
    } else {
      return 'An unexpected error occurred';
    }
  }

  // Debounced search function
  private searchTimeouts = new Map<string, NodeJS.Timeout>();

  debouncedSearch(
    searchTerm: string,
    callback: (term: string) => void,
    delay = 300,
    key = 'default'
  ): void {
    // Clear existing timeout for this key
    const existingTimeout = this.searchTimeouts.get(key);
    if (existingTimeout) {
      clearTimeout(existingTimeout);
    }

    // Set new timeout
    const timeout = setTimeout(() => {
      callback(searchTerm);
      this.searchTimeouts.delete(key);
    }, delay);

    this.searchTimeouts.set(key, timeout);
  }

  // Cache management for performance
  private cache = new Map<string, { data: any; timestamp: number; ttl: number }>();

  async getCachedData<T>(
    key: string,
    fetcher: () => Promise<T>,
    ttl = 60000 // 1 minute default TTL
  ): Promise<T> {
    const cached = this.cache.get(key);
    const now = Date.now();

    if (cached && (now - cached.timestamp) < cached.ttl) {
      return cached.data;
    }

    const data = await fetcher();
    this.cache.set(key, {
      data,
      timestamp: now,
      ttl
    });

    return data;
  }

  clearCache(key?: string): void {
    if (key) {
      this.cache.delete(key);
    } else {
      this.cache.clear();
    }
  }
}

// Singleton instance
export const backendService = new BackendIntegrationService();

// Helper hook for React components
export const useBackendService = () => {
  return backendService;
};