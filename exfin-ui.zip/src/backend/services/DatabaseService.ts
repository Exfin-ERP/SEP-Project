// Database Service Layer for Financial Management System
import { 
  User, Transaction, Category, CashBalance, AuditLog, Branch, Vendor,
  ApiResponse, PaginatedResponse, TransactionFilters, SortOptions,
  CategorySummary, DailySummary, MonthlySummary, UserActivity
} from '../database/models';

// Mock Database Implementation (In production, this would connect to PostgreSQL/MySQL)
class DatabaseService {
  private users: User[] = [];
  private transactions: Transaction[] = [];
  private categories: Category[] = [];
  private cashBalances: CashBalance[] = [];
  private auditLogs: AuditLog[] = [];
  private branches: Branch[] = [];
  private vendors: Vendor[] = [];

  constructor() {
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Initialize default categories
    this.categories = [
      {
        id: 'cat_001',
        name: 'Advances',
        description: 'Staff advances and salary advances',
        budget_limit: 500000,
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'cat_002',
        name: 'Electricity',
        description: 'Electricity bills and power expenses',
        budget_limit: 100000,
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'cat_003',
        name: 'Rentals',
        description: 'Building and equipment rentals',
        budget_limit: 200000,
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'cat_004',
        name: 'Loans',
        description: 'Loan repayments and interests',
        budget_limit: 300000,
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'cat_005',
        name: 'EMIs',
        description: 'Equipment and vehicle EMIs',
        budget_limit: 150000,
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'cat_006',
        name: 'Fuel',
        description: 'Vehicle fuel and transportation costs',
        budget_limit: 80000,
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      },
      {
        id: 'cat_007',
        name: 'Miscellaneous',
        description: 'Other expenses and miscellaneous costs',
        budget_limit: 100000,
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ];

    // Initialize sample users
    this.users = [
      {
        id: 'user_001',
        username: 'admin',
        email: 'admin@sriviswa.edu',
        name: 'Admin User',
        role: 'Admin',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        is_active: true
      },
      {
        id: 'user_002',
        username: 'manager',
        email: 'manager@sriviswa.edu',
        name: 'Management User',
        role: 'Management',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        is_active: true
      },
      {
        id: 'user_003',
        username: 'accountant1',
        email: 'accountant1@sriviswa.edu',
        name: 'Rajesh Kumar',
        role: 'Accountant',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        is_active: true
      },
      {
        id: 'user_004',
        username: 'accountant2',
        email: 'accountant2@sriviswa.edu',
        name: 'Priya Sharma',
        role: 'Accountant',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        is_active: true
      }
    ];

    // Initialize sample transactions
    this.initializeSampleTransactions();
  }

  private initializeSampleTransactions() {
    const sampleTransactions: Transaction[] = [
      {
        id: 'txn_001',
        user_id: 'user_003',
        category_id: 'cat_006',
        amount: 15000,
        transaction_type: 'DEBIT',
        description: 'Fuel expenses for college buses',
        payment_mode: 'CASH',
        transaction_date: new Date().toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        status: 'APPROVED',
        approved_by: 'user_002',
        approved_at: new Date().toISOString(),
        campus: 'SRIVEN BC-1',
        bill_number: 'FUEL001'
      },
      {
        id: 'txn_002',
        user_id: 'user_004',
        category_id: 'cat_002',
        amount: 25000,
        transaction_type: 'DEBIT',
        description: 'Monthly electricity bill payment',
        payment_mode: 'ONLINE',
        transaction_date: new Date(Date.now() - 86400000).toISOString(), // Yesterday
        created_at: new Date(Date.now() - 86400000).toISOString(),
        updated_at: new Date().toISOString(),
        status: 'PENDING',
        campus: 'SONTYAM',
        bill_number: 'ELEC001'
      },
      {
        id: 'txn_003',
        user_id: 'user_003',
        category_id: 'cat_001',
        amount: 50000,
        transaction_type: 'DEBIT',
        description: 'Staff salary advance',
        payment_mode: 'CHEQUE',
        transaction_date: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
        created_at: new Date(Date.now() - 172800000).toISOString(),
        updated_at: new Date().toISOString(),
        status: 'APPROVED',
        approved_by: 'user_002',
        approved_at: new Date().toISOString(),
        campus: 'SRIVEN DC-1',
        bill_number: 'ADV001'
      }
    ];

    this.transactions = sampleTransactions;
  }

  // User Management
  async getUserById(id: string): Promise<User | null> {
    return this.users.find(user => user.id === id) || null;
  }

  async getUserByUsername(username: string): Promise<User | null> {
    return this.users.find(user => user.username === username) || null;
  }

  async getAllUsers(): Promise<User[]> {
    return this.users.filter(user => user.is_active);
  }

  // Transaction Management
  async createTransaction(transaction: Omit<Transaction, 'id' | 'created_at' | 'updated_at'>): Promise<Transaction> {
    const newTransaction: Transaction = {
      ...transaction,
      id: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.transactions.push(newTransaction);
    
    // Log the transaction creation
    await this.logAudit({
      user_id: transaction.user_id,
      action: 'CREATE_TRANSACTION',
      table_name: 'transactions',
      record_id: newTransaction.id,
      new_values: newTransaction
    });

    return newTransaction;
  }

  async updateTransaction(id: string, updates: Partial<Transaction>): Promise<Transaction | null> {
    const index = this.transactions.findIndex(txn => txn.id === id);
    if (index === -1) return null;

    const oldTransaction = { ...this.transactions[index] };
    const updatedTransaction = {
      ...this.transactions[index],
      ...updates,
      updated_at: new Date().toISOString()
    };

    this.transactions[index] = updatedTransaction;

    // Log the transaction update
    await this.logAudit({
      user_id: updates.user_id || oldTransaction.user_id,
      action: 'UPDATE_TRANSACTION',
      table_name: 'transactions',
      record_id: id,
      old_values: oldTransaction,
      new_values: updatedTransaction
    });

    return updatedTransaction;
  }

  async getTransactions(filters?: TransactionFilters, sort?: SortOptions, page = 1, limit = 50): Promise<PaginatedResponse<Transaction>> {
    let filteredTransactions = [...this.transactions];

    // Apply filters
    if (filters) {
      if (filters.start_date) {
        filteredTransactions = filteredTransactions.filter(txn => 
          new Date(txn.transaction_date) >= new Date(filters.start_date!)
        );
      }
      if (filters.end_date) {
        filteredTransactions = filteredTransactions.filter(txn => 
          new Date(txn.transaction_date) <= new Date(filters.end_date!)
        );
      }
      if (filters.category_ids && filters.category_ids.length > 0) {
        filteredTransactions = filteredTransactions.filter(txn => 
          filters.category_ids!.includes(txn.category_id)
        );
      }
      if (filters.user_ids && filters.user_ids.length > 0) {
        filteredTransactions = filteredTransactions.filter(txn => 
          filters.user_ids!.includes(txn.user_id)
        );
      }
      if (filters.status && filters.status.length > 0) {
        filteredTransactions = filteredTransactions.filter(txn => 
          filters.status!.includes(txn.status)
        );
      }
      if (filters.payment_modes && filters.payment_modes.length > 0) {
        filteredTransactions = filteredTransactions.filter(txn => 
          filters.payment_modes!.includes(txn.payment_mode)
        );
      }
      if (filters.min_amount !== undefined) {
        filteredTransactions = filteredTransactions.filter(txn => 
          txn.amount >= filters.min_amount!
        );
      }
      if (filters.max_amount !== undefined) {
        filteredTransactions = filteredTransactions.filter(txn => 
          txn.amount <= filters.max_amount!
        );
      }
      if (filters.campus) {
        filteredTransactions = filteredTransactions.filter(txn => 
          txn.campus?.toLowerCase().includes(filters.campus!.toLowerCase())
        );
      }
      if (filters.search_term) {
        const searchTerm = filters.search_term.toLowerCase();
        filteredTransactions = filteredTransactions.filter(txn => 
          txn.description.toLowerCase().includes(searchTerm) ||
          txn.bill_number?.toLowerCase().includes(searchTerm) ||
          txn.reference_number?.toLowerCase().includes(searchTerm)
        );
      }
    }

    // Apply sorting
    if (sort) {
      filteredTransactions.sort((a, b) => {
        const aValue = (a as any)[sort.field];
        const bValue = (b as any)[sort.field];
        
        if (sort.direction === 'ASC') {
          return aValue > bValue ? 1 : -1;
        } else {
          return aValue < bValue ? 1 : -1;
        }
      });
    } else {
      // Default sort by creation date descending
      filteredTransactions.sort((a, b) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );
    }

    // Apply pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedTransactions = filteredTransactions.slice(startIndex, endIndex);

    return {
      data: paginatedTransactions,
      total: filteredTransactions.length,
      page,
      limit,
      total_pages: Math.ceil(filteredTransactions.length / limit)
    };
  }

  async getTransactionById(id: string): Promise<Transaction | null> {
    return this.transactions.find(txn => txn.id === id) || null;
  }

  async deleteTransaction(id: string): Promise<boolean> {
    const index = this.transactions.findIndex(txn => txn.id === id);
    if (index === -1) return false;

    const deletedTransaction = this.transactions[index];
    this.transactions.splice(index, 1);

    // Log the transaction deletion
    await this.logAudit({
      user_id: deletedTransaction.user_id,
      action: 'DELETE_TRANSACTION',
      table_name: 'transactions',
      record_id: id,
      old_values: deletedTransaction
    });

    return true;
  }

  // Category Management
  async getAllCategories(): Promise<Category[]> {
    return this.categories.filter(category => category.is_active);
  }

  async getCategoryById(id: string): Promise<Category | null> {
    return this.categories.find(category => category.id === id) || null;
  }

  // Analytics and Reporting
  async getCategorySummary(startDate?: string, endDate?: string): Promise<CategorySummary[]> {
    const transactions = await this.getFilteredTransactions(startDate, endDate);
    const categoryMap = new Map<string, CategorySummary>();

    // Initialize all categories
    for (const category of this.categories) {
      categoryMap.set(category.id, {
        category_id: category.id,
        category_name: category.name,
        total_amount: 0,
        transaction_count: 0,
        budget_limit: category.budget_limit
      });
    }

    // Aggregate transaction data
    for (const transaction of transactions) {
      const summary = categoryMap.get(transaction.category_id);
      if (summary) {
        summary.total_amount += transaction.amount;
        summary.transaction_count += 1;
        
        if (!summary.last_transaction_date || 
            new Date(transaction.transaction_date) > new Date(summary.last_transaction_date)) {
          summary.last_transaction_date = transaction.transaction_date;
        }
      }
    }

    // Calculate budget utilization
    const summaries = Array.from(categoryMap.values());
    summaries.forEach(summary => {
      if (summary.budget_limit) {
        summary.budget_utilization = (summary.total_amount / summary.budget_limit) * 100;
      }
    });

    return summaries.sort((a, b) => b.total_amount - a.total_amount);
  }

  async getDailySummary(date: string): Promise<DailySummary> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const dayTransactions = this.transactions.filter(txn => {
      const txnDate = new Date(txn.transaction_date);
      return txnDate >= startOfDay && txnDate <= endOfDay;
    });

    const receipts = dayTransactions
      .filter(txn => txn.transaction_type === 'CREDIT')
      .reduce((sum, txn) => sum + txn.amount, 0);

    const payments = dayTransactions
      .filter(txn => txn.transaction_type === 'DEBIT')
      .reduce((sum, txn) => sum + txn.amount, 0);

    // Get previous day balance for opening balance
    const previousDay = new Date(date);
    previousDay.setDate(previousDay.getDate() - 1);
    const previousBalance = await this.getCashBalance(previousDay.toISOString().split('T')[0]);

    return {
      date,
      total_receipts: receipts,
      total_payments: payments,
      net_amount: receipts - payments,
      transaction_count: dayTransactions.length,
      opening_balance: previousBalance?.closing_balance || 0,
      closing_balance: (previousBalance?.closing_balance || 0) + receipts - payments
    };
  }

  async getMonthlySummary(month: string, year: number): Promise<MonthlySummary> {
    const startDate = new Date(year, parseInt(month) - 1, 1).toISOString();
    const endDate = new Date(year, parseInt(month), 0, 23, 59, 59).toISOString();

    const monthTransactions = this.transactions.filter(txn => {
      const txnDate = new Date(txn.transaction_date);
      return txnDate >= new Date(startDate) && txnDate <= new Date(endDate);
    });

    const receipts = monthTransactions
      .filter(txn => txn.transaction_type === 'CREDIT')
      .reduce((sum, txn) => sum + txn.amount, 0);

    const payments = monthTransactions
      .filter(txn => txn.transaction_type === 'DEBIT')
      .reduce((sum, txn) => sum + txn.amount, 0);

    const categories = await this.getCategorySummary(startDate, endDate);

    return {
      month,
      year,
      total_receipts: receipts,
      total_payments: payments,
      net_amount: receipts - payments,
      transaction_count: monthTransactions.length,
      categories
    };
  }

  async getUserActivity(startDate?: string, endDate?: string): Promise<UserActivity[]> {
    const transactions = await this.getFilteredTransactions(startDate, endDate);
    const userMap = new Map<string, UserActivity>();

    // Initialize all users
    for (const user of this.users) {
      userMap.set(user.id, {
        user_id: user.id,
        user_name: user.name,
        transaction_count: 0,
        total_amount: 0,
        last_activity: '',
        role: user.role
      });
    }

    // Aggregate user data
    for (const transaction of transactions) {
      const activity = userMap.get(transaction.user_id);
      if (activity) {
        activity.transaction_count += 1;
        activity.total_amount += transaction.amount;
        
        if (!activity.last_activity || 
            new Date(transaction.created_at) > new Date(activity.last_activity)) {
          activity.last_activity = transaction.created_at;
        }
      }
    }

    return Array.from(userMap.values())
      .filter(activity => activity.transaction_count > 0)
      .sort((a, b) => b.transaction_count - a.transaction_count);
  }

  // Cash Balance Management
  async getCashBalance(date: string): Promise<CashBalance | null> {
    return this.cashBalances.find(balance => balance.date === date) || null;
  }

  async updateCashBalance(userId: string, date: string, balanceData: Partial<CashBalance>): Promise<CashBalance> {
    const existingBalance = await this.getCashBalance(date);
    
    if (existingBalance) {
      const updatedBalance = {
        ...existingBalance,
        ...balanceData,
        updated_at: new Date().toISOString()
      };
      
      const index = this.cashBalances.findIndex(b => b.id === existingBalance.id);
      this.cashBalances[index] = updatedBalance;
      
      return updatedBalance;
    } else {
      const newBalance: CashBalance = {
        id: `bal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        user_id: userId,
        date,
        opening_balance: 0,
        closing_balance: 0,
        total_receipts: 0,
        total_payments: 0,
        handover_status: 'PENDING',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        ...balanceData
      };
      
      this.cashBalances.push(newBalance);
      return newBalance;
    }
  }

  // Audit Logging
  private async logAudit(logData: Omit<AuditLog, 'id' | 'created_at'>): Promise<void> {
    const auditLog: AuditLog = {
      ...logData,
      id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      created_at: new Date().toISOString()
    };
    
    this.auditLogs.push(auditLog);
  }

  // Helper methods
  private async getFilteredTransactions(startDate?: string, endDate?: string): Promise<Transaction[]> {
    let filtered = [...this.transactions];
    
    if (startDate) {
      filtered = filtered.filter(txn => 
        new Date(txn.transaction_date) >= new Date(startDate)
      );
    }
    
    if (endDate) {
      filtered = filtered.filter(txn => 
        new Date(txn.transaction_date) <= new Date(endDate)
      );
    }
    
    return filtered;
  }

  // Vendor Management
  async getAllVendors(): Promise<Vendor[]> {
    return this.vendors.filter(vendor => vendor.is_active);
  }

  async createVendor(vendor: Omit<Vendor, 'id' | 'created_at' | 'updated_at'>): Promise<Vendor> {
    const newVendor: Vendor = {
      ...vendor,
      id: `vendor_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.vendors.push(newVendor);
    return newVendor;
  }

  // Branch Management
  async getAllBranches(): Promise<Branch[]> {
    return this.branches.filter(branch => branch.is_active);
  }
}

export default DatabaseService;