/**
 * Student Management API
 * Complete REST API endpoints for student lifecycle management
 * Implements best practices for educational ERP systems
 */

import { DatabaseService } from '../services/DatabaseService';

export interface Student {
  id: string;
  studentId: string;
  admissionNumber: string;
  firstName: string;
  lastName: string;
  fullName: string;
  dateOfBirth: Date;
  gender: 'Male' | 'Female' | 'Other';
  classGrade: string;
  section: string;
  rollNumber: string;
  academicYear: string;
  admissionDate: Date;
  status: 'Active' | 'Inactive' | 'Passed Out' | 'Transferred';
  email?: string;
  phone?: string;
  parentPhone: string;
  parentEmail?: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  bloodGroup?: string;
  caste?: string;
  religion?: string;
  photoUrl?: string;
  fatherName?: string;
  motherName?: string;
  guardianName?: string;
  organizationId?: number;
  branchId?: number;
  createdAt?: Date;
  updatedAt?: Date;
  createdBy?: number;
  updatedBy?: number;
}

export interface StudentFilters {
  page?: number;
  limit?: number;
  search?: string;
  classGrade?: string;
  section?: string;
  status?: string;
  academicYear?: string;
  organizationId?: number;
  branchId?: number;
  gender?: string;
}

export interface StudentResponse {
  success: boolean;
  data?: Student | Student[];
  pagination?: {
    currentPage: number;
    totalPages: number;
    totalRecords: number;
    perPage: number;
  };
  summary?: {
    totalStudents: number;
    activeStudents: number;
    maleStudents: number;
    femaleStudents: number;
  };
  message?: string;
  error?: {
    code: string;
    message: string;
    details?: any[];
  };
}

/**
 * Student API Class
 * Handles all student-related API operations
 */
export class StudentAPI {
  private db: DatabaseService;

  constructor() {
    this.db = new DatabaseService();
  }

  /**
   * Create a new student
   * POST /api/v1/students
   */
  async createStudent(studentData: Omit<Student, 'id' | 'createdAt' | 'updatedAt'>, userId: number): Promise<StudentResponse> {
    try {
      // Validation
      const validation = this.validateStudentData(studentData);
      if (!validation.isValid) {
        return {
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid student data',
            details: validation.errors
          }
        };
      }

      // Check for duplicate admission number
      const existingStudent = await this.db.query(
        'SELECT id FROM students WHERE admission_number = ? AND is_deleted = FALSE',
        [studentData.admissionNumber]
      );

      if (existingStudent && existingStudent.length > 0) {
        return {
          success: false,
          error: {
            code: 'DUPLICATE_ENTRY',
            message: 'A student with this admission number already exists'
          }
        };
      }

      // Generate student ID if not provided
      const studentId = studentData.studentId || await this.generateStudentId(studentData.organizationId);

      // Insert student
      const result = await this.db.query(`
        INSERT INTO students (
          student_id, admission_number, first_name, last_name, 
          date_of_birth, gender, class_id, section, roll_number,
          academic_year, admission_date, status, email, phone,
          parent_phone, parent_email, address, city, state, pincode,
          blood_group, caste, religion, photo_url,
          father_name, mother_name, guardian_name,
          organization_id, branch_id, created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        studentId,
        studentData.admissionNumber,
        studentData.firstName,
        studentData.lastName,
        studentData.dateOfBirth,
        studentData.gender,
        await this.getClassId(studentData.classGrade, studentData.organizationId),
        studentData.section,
        studentData.rollNumber,
        studentData.academicYear,
        studentData.admissionDate,
        studentData.status || 'Active',
        studentData.email,
        studentData.phone,
        studentData.parentPhone,
        studentData.parentEmail,
        studentData.address,
        studentData.city,
        studentData.state,
        studentData.pincode,
        studentData.bloodGroup,
        studentData.caste,
        studentData.religion,
        studentData.photoUrl,
        studentData.fatherName,
        studentData.motherName,
        studentData.guardianName,
        studentData.organizationId,
        studentData.branchId,
        userId
      ]);

      // Fetch and return the created student
      const createdStudent = await this.getStudentById(studentId);

      return {
        success: true,
        data: createdStudent,
        message: 'Student created successfully'
      };
    } catch (error) {
      console.error('Error creating student:', error);
      return {
        success: false,
        error: {
          code: 'DATABASE_ERROR',
          message: 'Failed to create student',
          details: error
        }
      };
    }
  }

  /**
   * Get student by ID
   * GET /api/v1/students/:id
   */
  async getStudentById(studentId: string): Promise<Student | null> {
    try {
      const result = await this.db.query(`
        SELECT 
          s.*,
          c.class_name as classGrade,
          CONCAT(s.first_name, ' ', s.last_name) as fullName
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        WHERE s.student_id = ? AND s.is_deleted = FALSE
      `, [studentId]);

      if (!result || result.length === 0) {
        return null;
      }

      return this.mapDatabaseToStudent(result[0]);
    } catch (error) {
      console.error('Error fetching student:', error);
      return null;
    }
  }

  /**
   * Get students with filtering and pagination
   * GET /api/v1/students
   */
  async getStudents(filters: StudentFilters = {}): Promise<StudentResponse> {
    try {
      const {
        page = 1,
        limit = 20,
        search = '',
        classGrade,
        section,
        status,
        academicYear,
        organizationId,
        branchId,
        gender
      } = filters;

      const offset = (page - 1) * limit;

      // Build WHERE clause
      const conditions: string[] = ['s.is_deleted = FALSE'];
      const params: any[] = [];

      if (search) {
        conditions.push(`(
          s.first_name LIKE ? OR 
          s.last_name LIKE ? OR 
          s.admission_number LIKE ? OR 
          s.student_id LIKE ? OR
          s.parent_phone LIKE ?
        )`);
        const searchPattern = `%${search}%`;
        params.push(searchPattern, searchPattern, searchPattern, searchPattern, searchPattern);
      }

      if (classGrade) {
        conditions.push('c.class_name = ?');
        params.push(classGrade);
      }

      if (section) {
        conditions.push('s.section = ?');
        params.push(section);
      }

      if (status) {
        conditions.push('s.status = ?');
        params.push(status);
      }

      if (academicYear) {
        conditions.push('s.academic_year = ?');
        params.push(academicYear);
      }

      if (organizationId) {
        conditions.push('s.organization_id = ?');
        params.push(organizationId);
      }

      if (branchId) {
        conditions.push('s.branch_id = ?');
        params.push(branchId);
      }

      if (gender) {
        conditions.push('s.gender = ?');
        params.push(gender);
      }

      const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

      // Get total count
      const countResult = await this.db.query(`
        SELECT COUNT(*) as total
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        ${whereClause}
      `, params);

      const totalRecords = countResult[0]?.total || 0;
      const totalPages = Math.ceil(totalRecords / limit);

      // Get students
      const students = await this.db.query(`
        SELECT 
          s.*,
          c.class_name as classGrade,
          CONCAT(s.first_name, ' ', s.last_name) as fullName
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        ${whereClause}
        ORDER BY s.created_at DESC
        LIMIT ? OFFSET ?
      `, [...params, limit, offset]);

      // Get summary statistics
      const summaryResult = await this.db.query(`
        SELECT 
          COUNT(*) as totalStudents,
          SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) as activeStudents,
          SUM(CASE WHEN gender = 'Male' THEN 1 ELSE 0 END) as maleStudents,
          SUM(CASE WHEN gender = 'Female' THEN 1 ELSE 0 END) as femaleStudents
        FROM students
        WHERE is_deleted = FALSE
        ${organizationId ? 'AND organization_id = ?' : ''}
      `, organizationId ? [organizationId] : []);

      const mappedStudents = students.map(s => this.mapDatabaseToStudent(s));

      return {
        success: true,
        data: mappedStudents,
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords,
          perPage: limit
        },
        summary: {
          totalStudents: summaryResult[0]?.totalStudents || 0,
          activeStudents: summaryResult[0]?.activeStudents || 0,
          maleStudents: summaryResult[0]?.maleStudents || 0,
          femaleStudents: summaryResult[0]?.femaleStudents || 0
        }
      };
    } catch (error) {
      console.error('Error fetching students:', error);
      return {
        success: false,
        error: {
          code: 'DATABASE_ERROR',
          message: 'Failed to fetch students',
          details: error
        }
      };
    }
  }

  /**
   * Update student
   * PUT /api/v1/students/:id
   */
  async updateStudent(studentId: string, updates: Partial<Student>, userId: number): Promise<StudentResponse> {
    try {
      // Check if student exists
      const existing = await this.getStudentById(studentId);
      if (!existing) {
        return {
          success: false,
          error: {
            code: 'RESOURCE_NOT_FOUND',
            message: 'Student not found'
          }
        };
      }

      // Validate updates
      const validation = this.validateStudentData(updates as any, true);
      if (!validation.isValid) {
        return {
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid student data',
            details: validation.errors
          }
        };
      }

      // Build update query
      const updateFields: string[] = [];
      const params: any[] = [];

      const fieldMap = {
        firstName: 'first_name',
        lastName: 'last_name',
        dateOfBirth: 'date_of_birth',
        gender: 'gender',
        section: 'section',
        rollNumber: 'roll_number',
        academicYear: 'academic_year',
        status: 'status',
        email: 'email',
        phone: 'phone',
        parentPhone: 'parent_phone',
        parentEmail: 'parent_email',
        address: 'address',
        city: 'city',
        state: 'state',
        pincode: 'pincode',
        bloodGroup: 'blood_group',
        caste: 'caste',
        religion: 'religion',
        photoUrl: 'photo_url',
        fatherName: 'father_name',
        motherName: 'mother_name',
        guardianName: 'guardian_name'
      };

      for (const [key, dbField] of Object.entries(fieldMap)) {
        if (updates[key as keyof Student] !== undefined) {
          updateFields.push(`${dbField} = ?`);
          params.push(updates[key as keyof Student]);
        }
      }

      if (updates.classGrade) {
        updateFields.push('class_id = ?');
        params.push(await this.getClassId(updates.classGrade, existing.organizationId));
      }

      if (updateFields.length === 0) {
        return {
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'No fields to update'
          }
        };
      }

      // Add updated_by and updated_at
      updateFields.push('updated_by = ?', 'updated_at = NOW()');
      params.push(userId);

      // Add student_id to params
      params.push(studentId);

      await this.db.query(`
        UPDATE students 
        SET ${updateFields.join(', ')}
        WHERE student_id = ? AND is_deleted = FALSE
      `, params);

      // Fetch and return updated student
      const updatedStudent = await this.getStudentById(studentId);

      return {
        success: true,
        data: updatedStudent!,
        message: 'Student updated successfully'
      };
    } catch (error) {
      console.error('Error updating student:', error);
      return {
        success: false,
        error: {
          code: 'DATABASE_ERROR',
          message: 'Failed to update student',
          details: error
        }
      };
    }
  }

  /**
   * Delete student (soft delete)
   * DELETE /api/v1/students/:id
   */
  async deleteStudent(studentId: string, userId: number): Promise<StudentResponse> {
    try {
      const existing = await this.getStudentById(studentId);
      if (!existing) {
        return {
          success: false,
          error: {
            code: 'RESOURCE_NOT_FOUND',
            message: 'Student not found'
          }
        };
      }

      await this.db.query(`
        UPDATE students 
        SET is_deleted = TRUE, deleted_at = NOW(), deleted_by = ?
        WHERE student_id = ?
      `, [userId, studentId]);

      return {
        success: true,
        message: 'Student deleted successfully'
      };
    } catch (error) {
      console.error('Error deleting student:', error);
      return {
        success: false,
        error: {
          code: 'DATABASE_ERROR',
          message: 'Failed to delete student',
          details: error
        }
      };
    }
  }

  /**
   * Bulk upload students
   * POST /api/v1/students/bulk-upload
   */
  async bulkUploadStudents(students: Omit<Student, 'id' | 'createdAt' | 'updatedAt'>[], userId: number): Promise<StudentResponse> {
    try {
      const results = {
        success: 0,
        failed: 0,
        errors: [] as any[]
      };

      for (const studentData of students) {
        const result = await this.createStudent(studentData, userId);
        if (result.success) {
          results.success++;
        } else {
          results.failed++;
          results.errors.push({
            admissionNumber: studentData.admissionNumber,
            error: result.error
          });
        }
      }

      return {
        success: true,
        message: `Bulk upload completed: ${results.success} successful, ${results.failed} failed`,
        data: results as any
      };
    } catch (error) {
      console.error('Error in bulk upload:', error);
      return {
        success: false,
        error: {
          code: 'BULK_UPLOAD_ERROR',
          message: 'Failed to complete bulk upload',
          details: error
        }
      };
    }
  }

  /**
   * Helper: Validate student data
   */
  private validateStudentData(data: Partial<Student>, isUpdate = false): { isValid: boolean; errors: any[] } {
    const errors: any[] = [];

    if (!isUpdate) {
      // Required fields for create
      if (!data.firstName) errors.push({ field: 'firstName', message: 'First name is required' });
      if (!data.lastName) errors.push({ field: 'lastName', message: 'Last name is required' });
      if (!data.admissionNumber) errors.push({ field: 'admissionNumber', message: 'Admission number is required' });
      if (!data.parentPhone) errors.push({ field: 'parentPhone', message: 'Parent phone is required' });
      if (!data.dateOfBirth) errors.push({ field: 'dateOfBirth', message: 'Date of birth is required' });
      if (!data.gender) errors.push({ field: 'gender', message: 'Gender is required' });
      if (!data.academicYear) errors.push({ field: 'academicYear', message: 'Academic year is required' });
    }

    // Validate email format
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push({ field: 'email', message: 'Invalid email format' });
    }

    if (data.parentEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.parentEmail)) {
      errors.push({ field: 'parentEmail', message: 'Invalid parent email format' });
    }

    // Validate phone numbers
    if (data.phone && !/^\+?[\d\s-()]+$/.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Invalid phone number format' });
    }

    if (data.parentPhone && !/^\+?[\d\s-()]+$/.test(data.parentPhone)) {
      errors.push({ field: 'parentPhone', message: 'Invalid parent phone number format' });
    }

    // Validate pincode
    if (data.pincode && !/^\d{5,6}$/.test(data.pincode)) {
      errors.push({ field: 'pincode', message: 'Invalid pincode format' });
    }

    // Validate gender
    if (data.gender && !['Male', 'Female', 'Other'].includes(data.gender)) {
      errors.push({ field: 'gender', message: 'Invalid gender value' });
    }

    // Validate status
    if (data.status && !['Active', 'Inactive', 'Passed Out', 'Transferred'].includes(data.status)) {
      errors.push({ field: 'status', message: 'Invalid status value' });
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * Helper: Generate student ID
   */
  private async generateStudentId(organizationId?: number): Promise<string> {
    const prefix = organizationId === 1 ? 'PRAG' : organizationId === 2 ? 'SRIV' : 'STU';
    const timestamp = Date.now().toString().slice(-8);
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `${prefix}-${timestamp}-${random}`;
  }

  /**
   * Helper: Get class ID from class name
   */
  private async getClassId(className: string, organizationId?: number): Promise<number | null> {
    try {
      const result = await this.db.query(
        'SELECT id FROM classes WHERE class_name = ? AND organization_id = ?',
        [className, organizationId]
      );
      return result && result.length > 0 ? result[0].id : null;
    } catch (error) {
      console.error('Error fetching class ID:', error);
      return null;
    }
  }

  /**
   * Helper: Map database record to Student object
   */
  private mapDatabaseToStudent(dbRecord: any): Student {
    return {
      id: dbRecord.id,
      studentId: dbRecord.student_id,
      admissionNumber: dbRecord.admission_number,
      firstName: dbRecord.first_name,
      lastName: dbRecord.last_name,
      fullName: dbRecord.fullName || `${dbRecord.first_name} ${dbRecord.last_name}`,
      dateOfBirth: new Date(dbRecord.date_of_birth),
      gender: dbRecord.gender,
      classGrade: dbRecord.classGrade || dbRecord.class_name,
      section: dbRecord.section,
      rollNumber: dbRecord.roll_number,
      academicYear: dbRecord.academic_year,
      admissionDate: new Date(dbRecord.admission_date),
      status: dbRecord.status,
      email: dbRecord.email,
      phone: dbRecord.phone,
      parentPhone: dbRecord.parent_phone,
      parentEmail: dbRecord.parent_email,
      address: dbRecord.address,
      city: dbRecord.city,
      state: dbRecord.state,
      pincode: dbRecord.pincode,
      bloodGroup: dbRecord.blood_group,
      caste: dbRecord.caste,
      religion: dbRecord.religion,
      photoUrl: dbRecord.photo_url,
      fatherName: dbRecord.father_name,
      motherName: dbRecord.mother_name,
      guardianName: dbRecord.guardian_name,
      organizationId: dbRecord.organization_id,
      branchId: dbRecord.branch_id,
      createdAt: dbRecord.created_at,
      updatedAt: dbRecord.updated_at,
      createdBy: dbRecord.created_by,
      updatedBy: dbRecord.updated_by
    };
  }
}

// Export singleton instance
export const studentAPI = new StudentAPI();
