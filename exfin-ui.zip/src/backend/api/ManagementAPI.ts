// Management Dashboard API Endpoints
import DatabaseService from '../services/DatabaseService';
import { 
  ApiResponse, CategorySummary, DailySummary, MonthlySummary, 
  UserActivity, Transaction, CashBalance 
} from '../database/models';

class ManagementAPI {
  private db: DatabaseService;

  constructor() {
    this.db = new DatabaseService();
  }

  // Get comprehensive dashboard overview
  async getDashboardOverview(userId: string): Promise<ApiResponse<{
    daily_summary: DailySummary;
    weekly_summary: DailySummary[];
    monthly_summary: MonthlySummary;
    category_summary: CategorySummary[];
    user_activity: UserActivity[];
    pending_transactions: Transaction[];
    cash_balance: CashBalance | null;
    recent_transactions: Transaction[];
  }>> {
    try {
      // Validate user permissions
      const user = await this.db.getUserById(userId);
      if (!user || !['Admin', 'Management'].includes(user.role)) {
        return {
          success: false,
          message: 'Insufficient permissions',
          timestamp: new Date().toISOString()
        };
      }

      const today = new Date().toISOString().split('T')[0];
      const currentMonth = new Date().getMonth() + 1;
      const currentYear = new Date().getFullYear();

      // Get daily summary for today
      const dailySummary = await this.db.getDailySummary(today);

      // Get weekly summary (last 7 days)
      const weeklySummary = [];
      for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        const daySum = await this.db.getDailySummary(dateStr);
        weeklySummary.push(daySum);
      }

      // Get monthly summary
      const monthlySummary = await this.db.getMonthlySummary(
        currentMonth.toString().padStart(2, '0'),
        currentYear
      );

      // Get category summary for current month
      const monthStart = new Date(currentYear, currentMonth - 1, 1).toISOString();
      const categorySummary = await this.db.getCategorySummary(monthStart);

      // Get user activity for current month
      const userActivity = await this.db.getUserActivity(monthStart);

      // Get pending transactions
      const pendingResult = await this.db.getTransactions(
        { status: ['PENDING'] },
        { field: 'created_at', direction: 'DESC' },
        1,
        20
      );

      // Get today's cash balance
      const cashBalance = await this.db.getCashBalance(today);

      // Get recent transactions (last 10)
      const recentResult = await this.db.getTransactions(
        {},
        { field: 'created_at', direction: 'DESC' },
        1,
        10
      );

      return {
        success: true,
        data: {
          daily_summary: dailySummary,
          weekly_summary: weeklySummary,
          monthly_summary: monthlySummary,
          category_summary: categorySummary,
          user_activity: userActivity,
          pending_transactions: pendingResult.data,
          cash_balance: cashBalance,
          recent_transactions: recentResult.data
        },
        message: 'Dashboard overview retrieved successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching dashboard overview:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Get category-wise analytics
  async getCategoryAnalytics(
    userId: string,
    startDate?: string,
    endDate?: string
  ): Promise<ApiResponse<{
    categories: CategorySummary[];
    budget_alerts: Array<{
      category_id: string;
      category_name: string;
      spent: number;
      budget: number;
      utilization: number;
      status: 'WITHIN_BUDGET' | 'APPROACHING_LIMIT' | 'OVER_BUDGET';
    }>;
    spending_trends: Array<{
      category_name: string;
      monthly_data: Array<{
        month: string;
        amount: number;
      }>;
    }>;
  }>> {
    try {
      // Validate user permissions
      const user = await this.db.getUserById(userId);
      if (!user || !['Admin', 'Management'].includes(user.role)) {
        return {
          success: false,
          message: 'Insufficient permissions',
          timestamp: new Date().toISOString()
        };
      }

      // Default to current month if no dates provided
      if (!startDate || !endDate) {
        const now = new Date();
        startDate = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
        endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString();
      }

      // Get category summary
      const categories = await this.db.getCategorySummary(startDate, endDate);

      // Generate budget alerts
      const budgetAlerts = categories
        .filter(cat => cat.budget_limit)
        .map(cat => {
          const utilization = cat.budget_utilization || 0;
          let status: 'WITHIN_BUDGET' | 'APPROACHING_LIMIT' | 'OVER_BUDGET';
          
          if (utilization > 100) {
            status = 'OVER_BUDGET';
          } else if (utilization > 80) {
            status = 'APPROACHING_LIMIT';
          } else {
            status = 'WITHIN_BUDGET';
          }

          return {
            category_id: cat.category_id,
            category_name: cat.category_name,
            spent: cat.total_amount,
            budget: cat.budget_limit!,
            utilization,
            status
          };
        })
        .sort((a, b) => b.utilization - a.utilization);

      // Generate spending trends (last 6 months)
      const spendingTrends = [];
      const allCategories = await this.db.getAllCategories();
      
      for (const category of allCategories) {
        const monthlyData = [];
        
        for (let i = 5; i >= 0; i--) {
          const date = new Date();
          date.setMonth(date.getMonth() - i);
          const monthStart = new Date(date.getFullYear(), date.getMonth(), 1).toISOString();
          const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0).toISOString();
          
          const monthCategories = await this.db.getCategorySummary(monthStart, monthEnd);
          const categoryData = monthCategories.find(c => c.category_id === category.id);
          
          monthlyData.push({
            month: date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
            amount: categoryData ? categoryData.total_amount : 0
          });
        }
        
        spendingTrends.push({
          category_name: category.name,
          monthly_data: monthlyData
        });
      }

      return {
        success: true,
        data: {
          categories,
          budget_alerts: budgetAlerts,
          spending_trends: spendingTrends
        },
        message: 'Category analytics retrieved successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching category analytics:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Get cash flow analytics
  async getCashFlowAnalytics(
    userId: string,
    period: 'daily' | 'weekly' | 'monthly' = 'daily',
    days = 30
  ): Promise<ApiResponse<{
    cash_flow: Array<{
      date: string;
      opening_balance: number;
      receipts: number;
      payments: number;
      closing_balance: number;
      net_flow: number;
    }>;
    summary: {
      total_receipts: number;
      total_payments: number;
      net_flow: number;
      average_daily_receipts: number;
      average_daily_payments: number;
    };
  }>> {
    try {
      // Validate user permissions
      const user = await this.db.getUserById(userId);
      if (!user || !['Admin', 'Management'].includes(user.role)) {
        return {
          success: false,
          message: 'Insufficient permissions',
          timestamp: new Date().toISOString()
        };
      }

      const cashFlow = [];
      let totalReceipts = 0;
      let totalPayments = 0;

      // Generate cash flow data for the specified period
      for (let i = days - 1; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        
        const dailySummary = await this.db.getDailySummary(dateStr);
        
        cashFlow.push({
          date: dateStr,
          opening_balance: dailySummary.opening_balance,
          receipts: dailySummary.total_receipts,
          payments: dailySummary.total_payments,
          closing_balance: dailySummary.closing_balance,
          net_flow: dailySummary.net_amount
        });

        totalReceipts += dailySummary.total_receipts;
        totalPayments += dailySummary.total_payments;
      }

      const summary = {
        total_receipts: totalReceipts,
        total_payments: totalPayments,
        net_flow: totalReceipts - totalPayments,
        average_daily_receipts: totalReceipts / days,
        average_daily_payments: totalPayments / days
      };

      return {
        success: true,
        data: {
          cash_flow: cashFlow,
          summary
        },
        message: 'Cash flow analytics retrieved successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching cash flow analytics:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Get user performance analytics
  async getUserPerformanceAnalytics(
    userId: string,
    startDate?: string,
    endDate?: string
  ): Promise<ApiResponse<{
    user_stats: UserActivity[];
    department_summary: Array<{
      role: string;
      user_count: number;
      total_transactions: number;
      total_amount: number;
      average_transaction_size: number;
    }>;
    top_performers: Array<{
      user_name: string;
      role: string;
      transaction_count: number;
      total_amount: number;
      efficiency_score: number;
    }>;
  }>> {
    try {
      // Validate user permissions
      const user = await this.db.getUserById(userId);
      if (!user || !['Admin', 'Management'].includes(user.role)) {
        return {
          success: false,
          message: 'Insufficient permissions',
          timestamp: new Date().toISOString()
        };
      }

      // Get user activity stats
      const userStats = await this.db.getUserActivity(startDate, endDate);

      // Calculate department summary
      const allUsers = await this.db.getAllUsers();
      const departmentMap = new Map();

      for (const u of allUsers) {
        if (!departmentMap.has(u.role)) {
          departmentMap.set(u.role, {
            role: u.role,
            user_count: 0,
            total_transactions: 0,
            total_amount: 0,
            average_transaction_size: 0
          });
        }

        const dept = departmentMap.get(u.role);
        dept.user_count++;

        const userActivity = userStats.find(ua => ua.user_id === u.id);
        if (userActivity) {
          dept.total_transactions += userActivity.transaction_count;
          dept.total_amount += userActivity.total_amount;
        }
      }

      const departmentSummary = Array.from(departmentMap.values()).map(dept => ({
        ...dept,
        average_transaction_size: dept.total_transactions > 0 
          ? dept.total_amount / dept.total_transactions 
          : 0
      }));

      // Calculate top performers (efficiency score based on transactions processed)
      const topPerformers = userStats
        .map(stat => ({
          user_name: stat.user_name,
          role: stat.role,
          transaction_count: stat.transaction_count,
          total_amount: stat.total_amount,
          efficiency_score: stat.transaction_count * 10 + (stat.total_amount / 1000) // Simple scoring
        }))
        .sort((a, b) => b.efficiency_score - a.efficiency_score)
        .slice(0, 10);

      return {
        success: true,
        data: {
          user_stats: userStats,
          department_summary: departmentSummary,
          top_performers: topPerformers
        },
        message: 'User performance analytics retrieved successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching user performance analytics:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Get system health metrics
  async getSystemHealth(userId: string): Promise<ApiResponse<{
    database_status: 'HEALTHY' | 'WARNING' | 'ERROR';
    total_records: {
      transactions: number;
      users: number;
      categories: number;
    };
    recent_errors: Array<{
      timestamp: string;
      error_type: string;
      message: string;
    }>;
    performance_metrics: {
      average_response_time: number;
      peak_transactions_per_day: number;
      system_uptime: string;
    };
  }>> {
    try {
      // Validate user permissions
      const user = await this.db.getUserById(userId);
      if (!user || user.role !== 'Admin') {
        return {
          success: false,
          message: 'Admin access required',
          timestamp: new Date().toISOString()
        };
      }

      // Get record counts
      const transactionsResult = await this.db.getTransactions({}, undefined, 1, 1);
      const users = await this.db.getAllUsers();
      const categories = await this.db.getAllCategories();

      // Simulate system health metrics
      const systemHealth = {
        database_status: 'HEALTHY' as const,
        total_records: {
          transactions: transactionsResult.total,
          users: users.length,
          categories: categories.length
        },
        recent_errors: [
          // Simulated error log entries
        ],
        performance_metrics: {
          average_response_time: 150, // ms
          peak_transactions_per_day: 245,
          system_uptime: '15 days, 8 hours'
        }
      };

      return {
        success: true,
        data: systemHealth,
        message: 'System health metrics retrieved successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching system health:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }
}

export default ManagementAPI;