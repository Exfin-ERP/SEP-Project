// Transaction API Endpoints and Business Logic
import DatabaseService from '../services/DatabaseService';
import { Transaction, ApiResponse, PaginatedResponse, TransactionFilters, SortOptions } from '../database/models';
import { RealTimeService } from '../services/RealTimeService';

class TransactionAPI {
  private db: DatabaseService;
  private realTimeService: RealTimeService;

  constructor() {
    this.db = new DatabaseService();
    this.realTimeService = new RealTimeService();
  }

  // Create new transaction
  async createTransaction(
    transactionData: Omit<Transaction, 'id' | 'created_at' | 'updated_at'>,
    userId: string
  ): Promise<ApiResponse<Transaction>> {
    try {
      // Validate user permissions
      const user = await this.db.getUserById(userId);
      if (!user) {
        return {
          success: false,
          message: 'User not found',
          errors: ['Invalid user ID'],
          timestamp: new Date().toISOString()
        };
      }

      // Validate category
      const category = await this.db.getCategoryById(transactionData.category_id);
      if (!category) {
        return {
          success: false,
          message: 'Category not found',
          errors: ['Invalid category ID'],
          timestamp: new Date().toISOString()
        };
      }

      // Validate amount
      if (transactionData.amount <= 0) {
        return {
          success: false,
          message: 'Invalid amount',
          errors: ['Amount must be greater than zero'],
          timestamp: new Date().toISOString()
        };
      }

      // Check budget limits for debit transactions
      if (transactionData.transaction_type === 'DEBIT' && category.budget_limit) {
        const currentMonthStart = new Date();
        currentMonthStart.setDate(1);
        currentMonthStart.setHours(0, 0, 0, 0);
        
        const categorySummary = await this.db.getCategorySummary(
          currentMonthStart.toISOString(),
          new Date().toISOString()
        );
        
        const categorySpend = categorySummary.find(c => c.category_id === transactionData.category_id);
        const currentSpend = categorySpend ? categorySpend.total_amount : 0;
        
        if (currentSpend + transactionData.amount > category.budget_limit) {
          return {
            success: false,
            message: 'Budget limit exceeded',
            errors: [`This transaction would exceed the budget limit of ₹${category.budget_limit} for ${category.name}`],
            timestamp: new Date().toISOString()
          };
        }
      }

      // Create transaction
      const newTransaction = await this.db.createTransaction(transactionData);

      // Send real-time update
      await this.realTimeService.broadcastUpdate({
        type: 'TRANSACTION_CREATED',
        data: newTransaction,
        timestamp: new Date().toISOString(),
        user_id: userId,
        affected_users: ['Management', 'Admin'] // Notify management and admin
      });

      // Update cash balance if needed
      if (transactionData.payment_mode === 'CASH') {
        await this.updateDailyCashBalance(
          transactionData.user_id,
          transactionData.transaction_date.split('T')[0],
          transactionData.transaction_type === 'CREDIT' ? transactionData.amount : -transactionData.amount
        );
      }

      return {
        success: true,
        data: newTransaction,
        message: 'Transaction created successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error creating transaction:', error);
      return {
        success: false,
        message: 'Internal server error',
        errors: ['Failed to create transaction'],
        timestamp: new Date().toISOString()
      };
    }
  }

  // Update existing transaction
  async updateTransaction(
    transactionId: string,
    updates: Partial<Transaction>,
    userId: string
  ): Promise<ApiResponse<Transaction>> {
    try {
      // Validate user permissions
      const user = await this.db.getUserById(userId);
      if (!user) {
        return {
          success: false,
          message: 'User not found',
          timestamp: new Date().toISOString()
        };
      }

      // Get existing transaction
      const existingTransaction = await this.db.getTransactionById(transactionId);
      if (!existingTransaction) {
        return {
          success: false,
          message: 'Transaction not found',
          timestamp: new Date().toISOString()
        };
      }

      // Check permissions - only creator or management can update
      if (existingTransaction.user_id !== userId && !['Admin', 'Management'].includes(user.role)) {
        return {
          success: false,
          message: 'Insufficient permissions',
          errors: ['You can only update your own transactions'],
          timestamp: new Date().toISOString()
        };
      }

      // Update transaction
      const updatedTransaction = await this.db.updateTransaction(transactionId, updates);
      if (!updatedTransaction) {
        return {
          success: false,
          message: 'Failed to update transaction',
          timestamp: new Date().toISOString()
        };
      }

      // Send real-time update
      await this.realTimeService.broadcastUpdate({
        type: 'TRANSACTION_UPDATED',
        data: updatedTransaction,
        timestamp: new Date().toISOString(),
        user_id: userId,
        affected_users: [existingTransaction.user_id, 'Management', 'Admin']
      });

      return {
        success: true,
        data: updatedTransaction,
        message: 'Transaction updated successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error updating transaction:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Approve transaction (Management only)
  async approveTransaction(
    transactionId: string,
    approverId: string,
    remarks?: string
  ): Promise<ApiResponse<Transaction>> {
    try {
      // Validate approver permissions
      const approver = await this.db.getUserById(approverId);
      if (!approver || !['Admin', 'Management'].includes(approver.role)) {
        return {
          success: false,
          message: 'Insufficient permissions',
          errors: ['Only Admin or Management can approve transactions'],
          timestamp: new Date().toISOString()
        };
      }

      // Get transaction
      const transaction = await this.db.getTransactionById(transactionId);
      if (!transaction) {
        return {
          success: false,
          message: 'Transaction not found',
          timestamp: new Date().toISOString()
        };
      }

      if (transaction.status !== 'PENDING') {
        return {
          success: false,
          message: 'Transaction is not pending approval',
          timestamp: new Date().toISOString()
        };
      }

      // Approve transaction
      const approvedTransaction = await this.db.updateTransaction(transactionId, {
        status: 'APPROVED',
        approved_by: approverId,
        approved_at: new Date().toISOString(),
        notes: remarks
      });

      if (!approvedTransaction) {
        return {
          success: false,
          message: 'Failed to approve transaction',
          timestamp: new Date().toISOString()
        };
      }

      // Send real-time update
      await this.realTimeService.broadcastUpdate({
        type: 'TRANSACTION_APPROVED',
        data: approvedTransaction,
        timestamp: new Date().toISOString(),
        user_id: approverId,
        affected_users: [transaction.user_id, 'Accountant']
      });

      return {
        success: true,
        data: approvedTransaction,
        message: 'Transaction approved successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error approving transaction:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Reject transaction (Management only)
  async rejectTransaction(
    transactionId: string,
    rejectorId: string,
    reason: string
  ): Promise<ApiResponse<Transaction>> {
    try {
      // Validate rejector permissions
      const rejector = await this.db.getUserById(rejectorId);
      if (!rejector || !['Admin', 'Management'].includes(rejector.role)) {
        return {
          success: false,
          message: 'Insufficient permissions',
          timestamp: new Date().toISOString()
        };
      }

      if (!reason.trim()) {
        return {
          success: false,
          message: 'Rejection reason is required',
          timestamp: new Date().toISOString()
        };
      }

      // Get transaction
      const transaction = await this.db.getTransactionById(transactionId);
      if (!transaction) {
        return {
          success: false,
          message: 'Transaction not found',
          timestamp: new Date().toISOString()
        };
      }

      // Reject transaction
      const rejectedTransaction = await this.db.updateTransaction(transactionId, {
        status: 'REJECTED',
        approved_by: rejectorId,
        approved_at: new Date().toISOString(),
        notes: reason
      });

      if (!rejectedTransaction) {
        return {
          success: false,
          message: 'Failed to reject transaction',
          timestamp: new Date().toISOString()
        };
      }

      // Send real-time update
      await this.realTimeService.broadcastUpdate({
        type: 'TRANSACTION_UPDATED',
        data: rejectedTransaction,
        timestamp: new Date().toISOString(),
        user_id: rejectorId,
        affected_users: [transaction.user_id]
      });

      return {
        success: true,
        data: rejectedTransaction,
        message: 'Transaction rejected',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error rejecting transaction:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Get transactions with filters and pagination
  async getTransactions(
    filters?: TransactionFilters,
    sort?: SortOptions,
    page = 1,
    limit = 50,
    userId?: string
  ): Promise<ApiResponse<PaginatedResponse<Transaction>>> {
    try {
      // Apply role-based filtering
      if (userId) {
        const user = await this.db.getUserById(userId);
        if (user && user.role === 'Accountant') {
          // Accountants can only see their own transactions
          filters = { ...filters, user_ids: [userId] };
        }
      }

      const result = await this.db.getTransactions(filters, sort, page, limit);

      // Enrich transactions with user and category details
      const enrichedTransactions = await Promise.all(
        result.data.map(async (transaction) => {
          const user = await this.db.getUserById(transaction.user_id);
          const category = await this.db.getCategoryById(transaction.category_id);
          
          return {
            ...transaction,
            user_name: user?.name || 'Unknown User',
            category_name: category?.name || 'Unknown Category'
          };
        })
      );

      return {
        success: true,
        data: {
          ...result,
          data: enrichedTransactions
        },
        message: 'Transactions retrieved successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching transactions:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Get transaction by ID
  async getTransactionById(
    transactionId: string,
    userId: string
  ): Promise<ApiResponse<Transaction>> {
    try {
      const transaction = await this.db.getTransactionById(transactionId);
      if (!transaction) {
        return {
          success: false,
          message: 'Transaction not found',
          timestamp: new Date().toISOString()
        };
      }

      // Check permissions
      const user = await this.db.getUserById(userId);
      if (user?.role === 'Accountant' && transaction.user_id !== userId) {
        return {
          success: false,
          message: 'Insufficient permissions',
          timestamp: new Date().toISOString()
        };
      }

      return {
        success: true,
        data: transaction,
        message: 'Transaction retrieved successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching transaction:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Delete transaction
  async deleteTransaction(
    transactionId: string,
    userId: string
  ): Promise<ApiResponse<boolean>> {
    try {
      // Get transaction
      const transaction = await this.db.getTransactionById(transactionId);
      if (!transaction) {
        return {
          success: false,
          message: 'Transaction not found',
          timestamp: new Date().toISOString()
        };
      }

      // Check permissions
      const user = await this.db.getUserById(userId);
      if (!user) {
        return {
          success: false,
          message: 'User not found',
          timestamp: new Date().toISOString()
        };
      }

      // Only allow deletion of own transactions and only if pending
      if (transaction.user_id !== userId && !['Admin', 'Management'].includes(user.role)) {
        return {
          success: false,
          message: 'Insufficient permissions',
          timestamp: new Date().toISOString()
        };
      }

      if (transaction.status === 'APPROVED') {
        return {
          success: false,
          message: 'Cannot delete approved transactions',
          timestamp: new Date().toISOString()
        };
      }

      // Delete transaction
      const deleted = await this.db.deleteTransaction(transactionId);
      if (!deleted) {
        return {
          success: false,
          message: 'Failed to delete transaction',
          timestamp: new Date().toISOString()
        };
      }

      return {
        success: true,
        data: true,
        message: 'Transaction deleted successfully',
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error deleting transaction:', error);
      return {
        success: false,
        message: 'Internal server error',
        timestamp: new Date().toISOString()
      };
    }
  }

  // Helper method to update daily cash balance
  private async updateDailyCashBalance(
    userId: string,
    date: string,
    amount: number
  ): Promise<void> {
    try {
      const currentBalance = await this.db.getCashBalance(date);
      
      if (currentBalance) {
        if (amount > 0) {
          await this.db.updateCashBalance(userId, date, {
            total_receipts: currentBalance.total_receipts + amount,
            closing_balance: currentBalance.closing_balance + amount
          });
        } else {
          await this.db.updateCashBalance(userId, date, {
            total_payments: currentBalance.total_payments + Math.abs(amount),
            closing_balance: currentBalance.closing_balance + amount
          });
        }
      } else {
        // Create new balance record
        await this.db.updateCashBalance(userId, date, {
          opening_balance: 0,
          total_receipts: amount > 0 ? amount : 0,
          total_payments: amount < 0 ? Math.abs(amount) : 0,
          closing_balance: amount
        });
      }

      // Send real-time cash balance update
      await this.realTimeService.broadcastUpdate({
        type: 'CASH_BALANCE_UPDATED',
        data: { date, userId, amount },
        timestamp: new Date().toISOString(),
        user_id: userId,
        affected_users: ['Management', 'Admin', userId]
      });
    } catch (error) {
      console.error('Error updating cash balance:', error);
    }
  }
}

export default TransactionAPI;