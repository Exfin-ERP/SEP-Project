// Database Models and Types for Financial Management System

export interface User {
  id: string;
  username: string;
  email: string;
  name: string;
  role: 'Admin' | 'Management' | 'Accountant' | 'Viewer';
  branch_id?: string;
  created_at: string;
  updated_at: string;
  is_active: boolean;
  last_login?: string;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  budget_limit?: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Transaction {
  id: string;
  user_id: string;
  category_id: string;
  amount: number;
  transaction_type: 'DEBIT' | 'CREDIT';
  description: string;
  reference_number?: string;
  payment_mode: 'CASH' | 'ONLINE' | 'CHEQUE' | 'UPI' | 'CARD';
  transaction_date: string;
  created_at: string;
  updated_at: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  approved_by?: string;
  approved_at?: string;
  notes?: string;
  campus?: string;
  vendor_id?: string;
  bill_number?: string;
  supporting_documents?: string[];
}

export interface CashBalance {
  id: string;
  user_id: string;
  opening_balance: number;
  closing_balance: number;
  total_receipts: number;
  total_payments: number;
  date: string;
  handover_to?: string;
  handover_status: 'PENDING' | 'COMPLETED' | 'VERIFIED';
  created_at: string;
  updated_at: string;
}

export interface AuditLog {
  id: string;
  user_id: string;
  action: string;
  table_name: string;
  record_id: string;
  old_values?: Record<string, any>;
  new_values?: Record<string, any>;
  ip_address?: string;
  user_agent?: string;
  created_at: string;
}

export interface Branch {
  id: string;
  name: string;
  code: string;
  address: string;
  phone?: string;
  email?: string;
  manager_id?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Vendor {
  id: string;
  name: string;
  contact_person: string;
  phone: string;
  email?: string;
  address: string;
  bank_details?: {
    account_number: string;
    ifsc_code: string;
    bank_name: string;
    account_holder_name: string;
  };
  pan_number?: string;
  gst_number?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message: string;
  errors?: string[];
  timestamp: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}

// Dashboard Analytics Types
export interface CategorySummary {
  category_id: string;
  category_name: string;
  total_amount: number;
  transaction_count: number;
  budget_limit?: number;
  budget_utilization?: number;
  last_transaction_date?: string;
}

export interface DailySummary {
  date: string;
  total_receipts: number;
  total_payments: number;
  net_amount: number;
  transaction_count: number;
  opening_balance: number;
  closing_balance: number;
}

export interface MonthlySummary {
  month: string;
  year: number;
  total_receipts: number;
  total_payments: number;
  net_amount: number;
  transaction_count: number;
  categories: CategorySummary[];
}

export interface UserActivity {
  user_id: string;
  user_name: string;
  transaction_count: number;
  total_amount: number;
  last_activity: string;
  role: string;
}

// Real-time Update Types
export interface RealTimeUpdate {
  type: 'TRANSACTION_CREATED' | 'TRANSACTION_UPDATED' | 'TRANSACTION_APPROVED' | 'CASH_BALANCE_UPDATED';
  data: any;
  timestamp: string;
  user_id: string;
  affected_users?: string[];
}

// Filter and Search Types
export interface TransactionFilters {
  start_date?: string;
  end_date?: string;
  category_ids?: string[];
  user_ids?: string[];
  status?: ('PENDING' | 'APPROVED' | 'REJECTED')[];
  payment_modes?: ('CASH' | 'ONLINE' | 'CHEQUE' | 'UPI' | 'CARD')[];
  min_amount?: number;
  max_amount?: number;
  campus?: string;
  search_term?: string;
}

export interface SortOptions {
  field: string;
  direction: 'ASC' | 'DESC';
}

// Database Configuration
export interface DatabaseConfig {
  host: string;
  port: number;
  database: string;
  username: string;
  password: string;
  ssl?: boolean;
  pool_min: number;
  pool_max: number;
  timeout: number;
}

// Environment Configuration
export interface AppConfig {
  app_name: string;
  app_version: string;
  environment: 'development' | 'staging' | 'production';
  port: number;
  database: DatabaseConfig;
  jwt_secret: string;
  jwt_expiry: string;
  cors_origins: string[];
  upload_path: string;
  max_file_size: number;
  allowed_file_types: string[];
  backup_schedule: string;
  log_level: 'debug' | 'info' | 'warn' | 'error';
}