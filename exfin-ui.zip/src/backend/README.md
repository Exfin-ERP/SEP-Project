# Financial Management Backend System

## Overview

This backend system provides comprehensive financial management capabilities for Sri Venkateswara Enterprises with real-time updates, role-based access control, and advanced analytics. The system handles cash transactions, budget management, and provides a management portal with real-time dashboards.

## Architecture

### Core Components

1. **Database Layer** (`/database/models.ts`)
   - Type definitions for all entities
   - Database schema models
   - API response types

2. **Service Layer** (`/services/`)
   - `DatabaseService.ts` - Core database operations
   - `RealTimeService.ts` - Real-time update broadcasting
   - `BackendIntegration.ts` - Frontend integration layer

3. **API Layer** (`/api/`)
   - `TransactionAPI.ts` - Transaction management endpoints
   - `ManagementAPI.ts` - Management dashboard and analytics

4. **Frontend Integration** (`/components/`)
   - `RealTimeManagementDashboard.tsx` - Real-time management interface
   - `RealTimeExpenseForm.tsx` - Backend-integrated expense form

## Key Features

### 1. Real-Time Cash Updates

- **Automatic Synchronization**: All cash transactions automatically update across all relevant pages
- **Live Dashboard**: Management dashboard updates in real-time without page refresh
- **Instant Notifications**: Users receive immediate feedback on transaction status changes
- **WebSocket-like Updates**: Uses event-driven architecture for real-time communication

### 2. Category Management

**Supported Categories:**
- Advances (Staff salary advances)
- Electricity (Power bills and utilities)
- Rentals (Building and equipment rentals)
- Loans (Loan repayments and interests)
- EMIs (Equipment and vehicle EMIs)
- Fuel (Transportation and fuel costs)
- Miscellaneous (Other expenses)

**Category Features:**
- Budget limits and utilization tracking
- Real-time budget alerts
- Spending trend analysis
- Automatic budget validation

### 3. Transaction Tracking

**Transaction Details:**
- Amount spent
- Category assignment
- Date and time stamps
- User who created/updated
- Payment mode (Cash, Online, Cheque, UPI, Card)
- Supporting documents
- Approval workflow

**Status Tracking:**
- Pending → Under Review → Approved/Rejected
- Real-time status updates
- Audit trail with timestamps
- Approval remarks and comments

### 4. Management Portal

**Dashboard Overview:**
- Daily, weekly, and monthly summaries
- Category-wise spending breakdown
- User activity monitoring
- Cash flow analytics
- Budget utilization reports

**Real-Time Features:**
- Live transaction monitoring
- Instant approval/rejection capabilities
- Real-time budget alerts
- User activity tracking

### 5. Role-Based Access Control

**User Roles:**
- **Admin**: Full system access, user management, vendor registration
- **Management**: Dashboard access, transaction approval, analytics
- **Accountant**: Transaction entry, own transaction management
- **Viewer**: Read-only access to reports and dashboards

**Security Features:**
- Secure user authentication
- Role-based route protection
- API endpoint authorization
- Audit logging for all actions

## API Endpoints

### Transaction Management

```typescript
// Create new transaction
POST /api/transactions
{
  category_id: string,
  amount: number,
  description: string,
  payment_mode: 'CASH' | 'ONLINE' | 'CHEQUE' | 'UPI' | 'CARD',
  transaction_date: string
}

// Update transaction
PUT /api/transactions/:id
{
  // Updated fields
}

// Approve transaction (Management only)
POST /api/transactions/:id/approve
{
  remarks?: string
}

// Reject transaction (Management only)
POST /api/transactions/:id/reject
{
  reason: string
}

// Get transactions with filters
GET /api/transactions?filters&page&limit

// Get single transaction
GET /api/transactions/:id
```

### Management Dashboard

```typescript
// Get dashboard overview
GET /api/management/dashboard

// Get category analytics
GET /api/management/categories/analytics?startDate&endDate

// Get cash flow analytics
GET /api/management/cashflow?period&days

// Get user performance
GET /api/management/users/performance?startDate&endDate

// Get system health metrics
GET /api/management/system/health
```

## Real-Time Updates

### Event Types

1. **TRANSACTION_CREATED** - New transaction added
2. **TRANSACTION_UPDATED** - Transaction modified
3. **TRANSACTION_APPROVED** - Transaction approved by management
4. **CASH_BALANCE_UPDATED** - Daily cash balance changed

### Subscription System

```typescript
// Subscribe to user-specific updates
const unsubscribe = backendService.subscribeToUpdates((update) => {
  // Handle real-time updates
  console.log('Update received:', update);
});

// Subscribe to global updates (Management/Admin)
const unsubscribeGlobal = backendService.subscribeToGlobalUpdates((update) => {
  // Handle system-wide updates
});
```

## Database Schema

### Core Tables

**Users**
- id, username, email, name, role
- branch_id, created_at, updated_at
- is_active, last_login

**Transactions**
- id, user_id, category_id, amount
- transaction_type, description, payment_mode
- transaction_date, status, approved_by
- campus, bill_number, notes, supporting_documents

**Categories**
- id, name, description, budget_limit
- is_active, created_at, updated_at

**Cash_Balances**
- id, user_id, date, opening_balance
- closing_balance, total_receipts, total_payments
- handover_status

**Audit_Logs**
- id, user_id, action, table_name, record_id
- old_values, new_values, created_at

## Frontend Integration

### Backend Service Usage

```typescript
// Initialize backend service
import { backendService } from '../backend/services/BackendIntegration';

// Set current user
backendService.setCurrentUser(userId);

// Create transaction
const response = await backendService.createTransaction(transactionData);

// Subscribe to real-time updates
const unsubscribe = backendService.subscribeToUpdates((update) => {
  // Handle updates
});

// Get dashboard data
const dashboard = await backendService.getDashboardOverview();
```

### Utility Functions

```typescript
// Format currency
backendService.formatCurrency(amount);

// Format dates
backendService.formatDate(date);
backendService.formatDateTime(datetime);

// Validate transaction data
backendService.validateTransactionData(data);

// Calculate budget utilization
backendService.calculateBudgetUtilization(spent, budget);
```

## Deployment Considerations

### Production Setup

1. **Database Configuration**
   - PostgreSQL or MySQL for production
   - Connection pooling
   - Backup strategies

2. **Real-Time Infrastructure**
   - WebSocket server setup
   - Load balancing for multiple instances
   - Connection management

3. **Security**
   - JWT token authentication
   - HTTPS enforcement
   - Rate limiting
   - Input validation

4. **Monitoring**
   - Application performance monitoring
   - Error tracking
   - Database performance metrics
   - Real-time connection monitoring

### Environment Variables

```env
DATABASE_URL=postgresql://user:pass@localhost:5432/finance_db
JWT_SECRET=your-secret-key
CORS_ORIGINS=http://localhost:3000,https://yourdomain.com
UPLOAD_PATH=/uploads
MAX_FILE_SIZE=10485760
LOG_LEVEL=info
```

## Testing

### Unit Tests
- Service layer functions
- API endpoint validation
- Real-time update logic
- Budget calculation algorithms

### Integration Tests
- End-to-end transaction flow
- Real-time update propagation
- Role-based access control
- Dashboard data accuracy

## Performance Optimization

### Caching Strategy
- Category data caching
- Dashboard metrics caching
- User session caching
- Database query optimization

### Real-Time Optimization
- Connection pooling
- Update batching
- Selective broadcasting
- Client-side caching

## Support and Maintenance

### Monitoring
- Transaction volume tracking
- System performance metrics
- Error rate monitoring
- User activity analytics

### Backup and Recovery
- Automated database backups
- Transaction log preservation
- Disaster recovery procedures
- Data retention policies

This backend system provides a robust foundation for financial management with real-time capabilities, comprehensive analytics, and secure role-based access control.