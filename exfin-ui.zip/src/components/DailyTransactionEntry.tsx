import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Separator } from "./ui/separator";
import { Badge } from "./ui/badge";
import { Plus, Trash2, Save, Calculator, Building2, CreditCard, Banknote } from 'lucide-react';
import { useAuth } from './AuthContext';
import { toast } from "sonner@2.0.3";

// Types for daily transactions
export interface FeeCollection {
  id: string;
  branch: string;
  paymentMethod: string;
  amount: number;
  reference: string;
  remarks: string;
}

export interface CashExpenditure {
  id: string;
  purpose: string;
  amount: number;
  remarks?: string;
}

export interface BankDeposit {
  id: string;
  bankName: string;
  amount: number;
  reference?: string;
}

export interface DailyTransactionData {
  date: string;
  accountantName: string;
  openingBalance: number;
  feeCollections: FeeCollection[];
  cashExpenditures: CashExpenditure[];
  bankDeposits: BankDeposit[];
  closingBalance: number;
  totalCashCollection: number;
  totalDigitalCollection: number;
  totalExpenditure: number;
  totalBankDeposits: number;
}

// Branch list based on the organizational structure
const branches = [
  // Schools (Pragyana Team)
  'PRAGYANA-A1 (School)',
  'PRAGYANA-A2 (School)', 
  'PRAGYANA-B1 (School)',
  'PRAGYANA-B2 (School)',
  'SONTYAM (School)',
  
  // Colleges (Sriven Team)
  'SRIVEN BC-1 (College)',
  'SRIVEN BC-2 (College)',
  'SRIVEN DC-1 (College)',
  'SRIVEN DC-2 (College)',
  'SRIVEN EC-1 (College)',
  'SRIVEN EC-2 (College)',
  'SRIVEN MBA-1 (College)',
  'SRIVEN MBA-2 (College)',
  'SRIVEN MCA-1 (College)',
  'SRIVEN MCA-2 (College)',
  'SRIVEN PHARMACY (College)',
  'SRIVEN NURSING (College)',
  'SRIVEN MAIN (College)',
  
  // Business & Central
  'CENTRAL OFFICE',
  'BUSINESS ENTITY-1',
  'BUSINESS ENTITY-2'
];

const paymentMethods = [
  'Cash',
  'UPI',
  'Card Swipe',
  'PhonePe',
  'Google Pay',
  'Paytm',
  'Cheque',
  'Bank Transfer',
  'NEFT/RTGS',
  'DD (Demand Draft)'
];

const commonBanks = [
  'State Bank of India',
  'HDFC Bank',
  'ICICI Bank',
  'Axis Bank',
  'Punjab National Bank',
  'Bank of Baroda',
  'Canara Bank',
  'Union Bank of India',
  'Indian Bank',
  'Central Bank of India'
];

export function DailyTransactionEntry() {
  const { user } = useAuth();
  const [transactionData, setTransactionData] = useState<DailyTransactionData>({
    date: new Date().toISOString().split('T')[0],
    accountantName: user?.name || '',
    openingBalance: 25000, // This should come from previous day's closing balance
    feeCollections: [],
    cashExpenditures: [],
    bankDeposits: [],
    closingBalance: 0,
    totalCashCollection: 0,
    totalDigitalCollection: 0,
    totalExpenditure: 0,
    totalBankDeposits: 0
  });

  // Calculate totals whenever data changes
  useEffect(() => {
    const cashCollection = transactionData.feeCollections
      .filter(fc => fc.paymentMethod === 'Cash')
      .reduce((sum, fc) => sum + fc.amount, 0);
    
    const digitalCollection = transactionData.feeCollections
      .filter(fc => fc.paymentMethod !== 'Cash')
      .reduce((sum, fc) => sum + fc.amount, 0);
    
    const totalExpenditure = transactionData.cashExpenditures
      .reduce((sum, ce) => sum + ce.amount, 0);
    
    const totalBankDeposits = transactionData.bankDeposits
      .reduce((sum, bd) => sum + bd.amount, 0);
    
    const closingBalance = transactionData.openingBalance + cashCollection - totalExpenditure - totalBankDeposits;
    
    setTransactionData(prev => ({
      ...prev,
      totalCashCollection: cashCollection,
      totalDigitalCollection: digitalCollection,
      totalExpenditure,
      totalBankDeposits,
      closingBalance
    }));
  }, [transactionData.feeCollections, transactionData.cashExpenditures, transactionData.bankDeposits, transactionData.openingBalance]);

  // Fee Collection functions
  const addFeeCollection = () => {
    const newCollection: FeeCollection = {
      id: Date.now().toString(),
      branch: '',
      paymentMethod: 'Cash',
      amount: 0,
      reference: '',
      remarks: ''
    };
    setTransactionData(prev => ({
      ...prev,
      feeCollections: [...prev.feeCollections, newCollection]
    }));
  };

  const updateFeeCollection = (id: string, field: keyof FeeCollection, value: string | number) => {
    setTransactionData(prev => ({
      ...prev,
      feeCollections: prev.feeCollections.map(fc =>
        fc.id === id ? { ...fc, [field]: value } : fc
      )
    }));
  };

  const removeFeeCollection = (id: string) => {
    setTransactionData(prev => ({
      ...prev,
      feeCollections: prev.feeCollections.filter(fc => fc.id !== id)
    }));
  };

  // Cash Expenditure functions
  const addCashExpenditure = () => {
    const newExpenditure: CashExpenditure = {
      id: Date.now().toString(),
      purpose: '',
      amount: 0,
      remarks: ''
    };
    setTransactionData(prev => ({
      ...prev,
      cashExpenditures: [...prev.cashExpenditures, newExpenditure]
    }));
  };

  const updateCashExpenditure = (id: string, field: keyof CashExpenditure, value: string | number) => {
    setTransactionData(prev => ({
      ...prev,
      cashExpenditures: prev.cashExpenditures.map(ce =>
        ce.id === id ? { ...ce, [field]: value } : ce
      )
    }));
  };

  const removeCashExpenditure = (id: string) => {
    setTransactionData(prev => ({
      ...prev,
      cashExpenditures: prev.cashExpenditures.filter(ce => ce.id !== id)
    }));
  };

  // Bank Deposit functions
  const addBankDeposit = () => {
    const newDeposit: BankDeposit = {
      id: Date.now().toString(),
      bankName: '',
      amount: 0,
      reference: ''
    };
    setTransactionData(prev => ({
      ...prev,
      bankDeposits: [...prev.bankDeposits, newDeposit]
    }));
  };

  const updateBankDeposit = (id: string, field: keyof BankDeposit, value: string | number) => {
    setTransactionData(prev => ({
      ...prev,
      bankDeposits: prev.bankDeposits.map(bd =>
        bd.id === id ? { ...bd, [field]: value } : bd
      )
    }));
  };

  const removeBankDeposit = (id: string) => {
    setTransactionData(prev => ({
      ...prev,
      bankDeposits: prev.bankDeposits.filter(bd => bd.id !== id)
    }));
  };

  const handleSave = () => {
    // Here you would save to your backend/database
    console.log('Saving transaction data:', transactionData);
    toast.success('Daily transaction data saved successfully!');
  };

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Daily Transaction Entry</h2>
          <p className="text-muted-foreground">Record daily fee collections, expenditures, and bank deposits</p>
        </div>
        <Button onClick={handleSave} className="flex items-center gap-2">
          <Save className="w-4 h-4" />
          Save Transaction Data
        </Button>
      </div>

      {/* Transaction Date and Accountant Info */}
      <Card>
        <CardHeader>
          <CardTitle>Transaction Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="date">Transaction Date</Label>
              <Input
                id="date"
                type="date"
                value={transactionData.date}
                onChange={(e) => setTransactionData(prev => ({ ...prev, date: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="accountant">Accountant Name</Label>
              <Input
                id="accountant"
                value={transactionData.accountantName}
                onChange={(e) => setTransactionData(prev => ({ ...prev, accountantName: e.target.value }))}
                placeholder="Enter accountant name"
              />
            </div>
            <div>
              <Label htmlFor="opening-balance">Opening Balance (Cash in Hand)</Label>
              <Input
                id="opening-balance"
                type="number"
                value={transactionData.openingBalance}
                onChange={(e) => setTransactionData(prev => ({ ...prev, openingBalance: Number(e.target.value) }))}
                placeholder="0"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Fee Collection Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            Fee Collection Details
          </CardTitle>
          <CardDescription>Record fee collections from different branches and payment methods</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {transactionData.feeCollections.map((collection) => (
              <div key={collection.id} className="p-4 border rounded-lg bg-blue-50/30">
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                  <div>
                    <Label>Branch/Institution</Label>
                    <Select value={collection.branch} onValueChange={(value) => updateFeeCollection(collection.id, 'branch', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select branch" />
                      </SelectTrigger>
                      <SelectContent>
                        {branches.map(branch => (
                          <SelectItem key={branch} value={branch}>{branch}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label>Payment Method</Label>
                    <Select value={collection.paymentMethod} onValueChange={(value) => updateFeeCollection(collection.id, 'paymentMethod', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentMethods.map(method => (
                          <SelectItem key={method} value={method}>{method}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Amount (₹)</Label>
                    <Input
                      type="number"
                      value={collection.amount || ''}
                      onChange={(e) => updateFeeCollection(collection.id, 'amount', Number(e.target.value))}
                      placeholder="0"
                    />
                  </div>

                  <div>
                    <Label>Reference/Transaction ID</Label>
                    <Input
                      value={collection.reference}
                      onChange={(e) => updateFeeCollection(collection.id, 'reference', e.target.value)}
                      placeholder="Enter reference ID"
                    />
                  </div>

                  <div>
                    <Label>Remarks</Label>
                    <Input
                      value={collection.remarks}
                      onChange={(e) => updateFeeCollection(collection.id, 'remarks', e.target.value)}
                      placeholder="Optional remarks"
                    />
                  </div>

                  <div className="flex items-end">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeFeeCollection(collection.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
            
            <Button onClick={addFeeCollection} variant="outline" className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Fee Collection Entry
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Cash Expenditure Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Banknote className="w-5 h-5" />
            Cash Expenditure Details
          </CardTitle>
          <CardDescription>Record cash expenditures and payments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {transactionData.cashExpenditures.map((expenditure) => (
              <div key={expenditure.id} className="p-4 border rounded-lg bg-red-50/30">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="md:col-span-2">
                    <Label>Purpose of Expenditure</Label>
                    <Input
                      value={expenditure.purpose}
                      onChange={(e) => updateCashExpenditure(expenditure.id, 'purpose', e.target.value)}
                      placeholder="Describe the expense purpose"
                    />
                  </div>

                  <div>
                    <Label>Amount (₹)</Label>
                    <Input
                      type="number"
                      value={expenditure.amount || ''}
                      onChange={(e) => updateCashExpenditure(expenditure.id, 'amount', Number(e.target.value))}
                      placeholder="0"
                    />
                  </div>

                  <div className="flex items-end">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeCashExpenditure(expenditure.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="mt-3">
                  <Label>Additional Remarks</Label>
                  <Textarea
                    value={expenditure.remarks || ''}
                    onChange={(e) => updateCashExpenditure(expenditure.id, 'remarks', e.target.value)}
                    placeholder="Optional additional details about this expenditure"
                    rows={2}
                  />
                </div>
              </div>
            ))}
            
            <Button onClick={addCashExpenditure} variant="outline" className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Cash Expenditure
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Bank Deposit Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            Bank Deposit Details
          </CardTitle>
          <CardDescription>Record cash deposits made to banks</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {transactionData.bankDeposits.map((deposit) => (
              <div key={deposit.id} className="p-4 border rounded-lg bg-green-50/30">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <Label>Bank Name</Label>
                    <Select value={deposit.bankName} onValueChange={(value) => updateBankDeposit(deposit.id, 'bankName', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select bank" />
                      </SelectTrigger>
                      <SelectContent>
                        {commonBanks.map(bank => (
                          <SelectItem key={bank} value={bank}>{bank}</SelectItem>
                        ))}
                        <SelectItem value="other">Other Bank</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Deposit Amount (₹)</Label>
                    <Input
                      type="number"
                      value={deposit.amount || ''}
                      onChange={(e) => updateBankDeposit(deposit.id, 'amount', Number(e.target.value))}
                      placeholder="0"
                    />
                  </div>

                  <div>
                    <Label>Reference/Slip Number</Label>
                    <Input
                      value={deposit.reference || ''}
                      onChange={(e) => updateBankDeposit(deposit.id, 'reference', e.target.value)}
                      placeholder="Bank slip number"
                    />
                  </div>

                  <div className="flex items-end">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeBankDeposit(deposit.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
            
            <Button onClick={addBankDeposit} variant="outline" className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Bank Deposit
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Summary and Closing Balance */}
      <Card className="bg-gradient-to-r from-blue-50 to-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Daily Summary & Closing Balance
          </CardTitle>
          <CardDescription>Automatically calculated summary of the day's transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-4">
              <h4 className="font-medium text-lg">Collections</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Opening Balance:</span>
                  <Badge variant="outline" className="font-mono">
                    ₹{transactionData.openingBalance.toLocaleString('en-IN')}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Cash Collections:</span>
                  <Badge className="bg-green-100 text-green-800 font-mono">
                    ₹{transactionData.totalCashCollection.toLocaleString('en-IN')}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Digital Collections:</span>
                  <Badge className="bg-blue-100 text-blue-800 font-mono">
                    ₹{transactionData.totalDigitalCollection.toLocaleString('en-IN')}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-lg">Outgoings</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Cash Expenditures:</span>
                  <Badge className="bg-red-100 text-red-800 font-mono">
                    ₹{transactionData.totalExpenditure.toLocaleString('en-IN')}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span>Bank Deposits:</span>
                  <Badge className="bg-orange-100 text-orange-800 font-mono">
                    ₹{transactionData.totalBankDeposits.toLocaleString('en-IN')}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-lg">Final Balance</h4>
              <div className="p-4 bg-white rounded-lg border-2 border-primary/20">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-1">Closing Balance (Cash in Hand)</p>
                  <p className="text-2xl font-bold text-primary">
                    ₹{transactionData.closingBalance.toLocaleString('en-IN')}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {transactionData.closingBalance >= 0 ? 'Positive Balance' : 'Deficit Balance'}
                  </p>
                </div>
              </div>
              
              <div className="text-xs text-muted-foreground">
                <p>Formula: Opening + Cash Collections - Cash Expenditures - Bank Deposits</p>
                <p>
                  {transactionData.openingBalance.toLocaleString('en-IN')} + {transactionData.totalCashCollection.toLocaleString('en-IN')} - {transactionData.totalExpenditure.toLocaleString('en-IN')} - {transactionData.totalBankDeposits.toLocaleString('en-IN')} = {transactionData.closingBalance.toLocaleString('en-IN')}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}