import { ReactNode } from 'react';
import { Alert, AlertDescription, AlertTitle } from "./ui/alert";
import { Shield, AlertTriangle } from 'lucide-react';
import { useAuth, type UserRole } from './AuthContext';

interface RoleGuardProps {
  allowedRoles: UserRole[];
  children: ReactNode;
  fallbackMessage?: string;
}

export function RoleGuard({ allowedRoles, children, fallbackMessage }: RoleGuardProps) {
  const { user } = useAuth();

  if (!user) {
    return (
      <Alert className="border-destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Authentication Required</AlertTitle>
        <AlertDescription>
          You must be logged in to access this content.
        </AlertDescription>
      </Alert>
    );
  }

  if (!allowedRoles.includes(user.role)) {
    return (
      <Alert className="border-destructive">
        <Shield className="h-4 w-4" />
        <AlertTitle>Access Denied</AlertTitle>
        <AlertDescription>
          {fallbackMessage || 
            `This content requires ${allowedRoles.length > 1 
              ? `one of the following roles: ${allowedRoles.join(', ')}` 
              : `${allowedRoles[0]} role`}. Your current role is ${user.role}.`
          }
        </AlertDescription>
      </Alert>
    );
  }

  return <>{children}</>;
}

// Helper function to check if user has permission
export function hasPermission(userRole: UserRole, requiredRoles: UserRole[]): boolean {
  return requiredRoles.includes(userRole);
}

// Role hierarchy for permission checking
const roleHierarchy: Record<UserRole, number> = {
  'Admin': 4,
  'Management': 3,
  'Accountant': 2,
  'Viewer': 1
};

export function hasMinimumRole(userRole: UserRole, minimumRole: UserRole): boolean {
  return roleHierarchy[userRole] >= roleHierarchy[minimumRole];
}