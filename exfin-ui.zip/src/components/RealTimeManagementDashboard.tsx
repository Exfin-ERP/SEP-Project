import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import { 
  TrendingUp, TrendingDown, DollarSign, Users, Receipt, AlertTriangle, 
  CheckCircle, Clock, Activity, BarChart3, RefreshCw
} from "lucide-react";
import { useAuth } from './AuthContext';
import { UserLoginInfo } from './UserLoginInfo';

// Mock dashboard data for stable rendering
const getMockDashboardData = () => ({
  daily_summary: {
    date: new Date().toISOString().split('T')[0],
    total_receipts: 125000,
    total_payments: 68000,
    net_amount: 57000,
    transaction_count: 24,
    opening_balance: 250000,
    closing_balance: 307000
  },
  weekly_summary: [
    { date: '2024-12-01', total_receipts: 95000, total_payments: 52000, net_amount: 43000, transaction_count: 18 },
    { date: '2024-12-02', total_receipts: 110000, total_payments: 61000, net_amount: 49000, transaction_count: 21 },
    { date: '2024-12-03', total_receipts: 88000, total_payments: 45000, net_amount: 43000, transaction_count: 16 },
    { date: '2024-12-04', total_receipts: 105000, total_payments: 58000, net_amount: 47000, transaction_count: 19 },
    { date: '2024-12-05', total_receipts: 98000, total_payments: 54000, net_amount: 44000, transaction_count: 17 },
    { date: '2024-12-06', total_receipts: 115000, total_payments: 63000, net_amount: 52000, transaction_count: 22 },
    { date: '2024-12-07', total_receipts: 125000, total_payments: 68000, net_amount: 57000, transaction_count: 24 }
  ],
  category_summary: [
    { category_id: 'cat_001', category_name: 'Advances', total_amount: 85000, transaction_count: 8, budget_limit: 500000, budget_utilization: 17 },
    { category_id: 'cat_002', category_name: 'Electricity', total_amount: 45000, transaction_count: 12, budget_limit: 100000, budget_utilization: 45 },
    { category_id: 'cat_003', category_name: 'Rentals', total_amount: 120000, transaction_count: 6, budget_limit: 200000, budget_utilization: 60 },
    { category_id: 'cat_004', category_name: 'Loans', total_amount: 95000, transaction_count: 4, budget_limit: 300000, budget_utilization: 31.7 },
    { category_id: 'cat_005', category_name: 'EMIs', total_amount: 78000, transaction_count: 5, budget_limit: 150000, budget_utilization: 52 },
    { category_id: 'cat_006', category_name: 'Fuel', total_amount: 52000, transaction_count: 15, budget_limit: 80000, budget_utilization: 65 },
    { category_id: 'cat_007', category_name: 'Miscellaneous', total_amount: 38000, transaction_count: 11, budget_limit: 100000, budget_utilization: 38 }
  ],
  user_activity: [
    { user_id: 'user_003', user_name: 'Rajesh Kumar', transaction_count: 28, total_amount: 245000, last_activity: new Date().toISOString(), role: 'Accountant' },
    { user_id: 'user_004', user_name: 'Priya Sharma', transaction_count: 22, total_amount: 198000, last_activity: new Date().toISOString(), role: 'Accountant' },
    { user_id: 'user_005', user_name: 'Suresh Babu', transaction_count: 19, total_amount: 165000, last_activity: new Date().toISOString(), role: 'Accountant' }
  ],
  pending_transactions: [
    { id: 'txn_001', amount: 15000, category_name: 'Fuel', user_name: 'Rajesh Kumar', description: 'Fuel expenses for college buses', transaction_date: new Date().toISOString(), status: 'PENDING' },
    { id: 'txn_002', amount: 25000, category_name: 'Electricity', user_name: 'Priya Sharma', description: 'Monthly electricity bill payment', transaction_date: new Date().toISOString(), status: 'PENDING' }
  ],
  recent_transactions: [
    { id: 'txn_003', amount: 50000, category_name: 'Advances', user_name: 'Rajesh Kumar', description: 'Staff salary advance', transaction_date: new Date().toISOString(), status: 'APPROVED', payment_mode: 'CHEQUE' },
    { id: 'txn_004', amount: 8500, category_name: 'Maintenance', user_name: 'Suresh Babu', description: 'Building maintenance work', transaction_date: new Date().toISOString(), status: 'APPROVED', payment_mode: 'CASH' },
    { id: 'txn_005', amount: 12000, category_name: 'Fuel', user_name: 'Priya Sharma', description: 'Vehicle fuel for transport', transaction_date: new Date().toISOString(), status: 'APPROVED', payment_mode: 'UPI' }
  ]
});

export function RealTimeManagementDashboard() {
  const { user } = useAuth();
  const [dashboardData] = useState(getMockDashboardData);
  const [lastUpdate] = useState(new Date());
  const [realTimeConnected] = useState(true);

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Format date
  const formatDate = (date: string | Date) => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj.toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Format datetime
  const formatDateTime = (date: string | Date) => {
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj.toLocaleString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING':
        return 'bg-yellow-100 text-yellow-800';
      case 'APPROVED':
        return 'bg-green-100 text-green-800';
      case 'REJECTED':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Get payment mode icon
  const getPaymentModeIcon = (mode: string) => {
    switch (mode) {
      case 'CASH':
        return '💵';
      case 'ONLINE':
        return '💳';
      case 'CHEQUE':
        return '📝';
      case 'UPI':
        return '📱';
      case 'CARD':
        return '💳';
      default:
        return '💰';
    }
  };

  // Calculate metrics
  const metrics = useMemo(() => {
    if (!dashboardData) return null;

    const { category_summary } = dashboardData;
    
    // Budget alerts
    const budgetAlerts = category_summary
      .filter(cat => cat.budget_limit && cat.budget_utilization)
      .filter(cat => cat.budget_utilization! > 80)
      .sort((a, b) => (b.budget_utilization || 0) - (a.budget_utilization || 0));

    // Top spending categories
    const topCategories = category_summary
      .sort((a, b) => b.total_amount - a.total_amount)
      .slice(0, 5);

    return {
      budgetAlerts,
      topCategories
    };
  }, [dashboardData]);

  return (
    <div className="space-y-6">
      {/* User Login Info */}
      <UserLoginInfo className="bg-blue-50 p-3 rounded-lg border border-blue-200" />
      
      {/* Header with real-time status */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Management Dashboard</h1>
          <p>Real-time financial overview and transaction management</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className={`w-2 h-2 rounded-full ${realTimeConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span>{realTimeConnected ? 'Live' : 'Disconnected'}</span>
          </div>
          <div className="text-sm text-muted-foreground">
            Updated: {lastUpdate.toLocaleTimeString()}
          </div>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Today's Cash Flow</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl ${dashboardData.daily_summary.net_amount >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(dashboardData.daily_summary.net_amount)}
            </div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              {dashboardData.daily_summary.net_amount >= 0 ? (
                <TrendingUp className="w-4 h-4 text-green-500" />
              ) : (
                <TrendingDown className="w-4 h-4 text-red-500" />
              )}
              <span>Net flow today</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Today's Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{dashboardData.daily_summary.transaction_count}</div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Activity className="w-4 h-4" />
              <span>Total transactions</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-yellow-600">{dashboardData.pending_transactions.length}</div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>Awaiting approval</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Cash Balance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{formatCurrency(dashboardData.daily_summary.closing_balance)}</div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <DollarSign className="w-4 h-4" />
              <span>Current balance</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Budget Alerts */}
      {metrics?.budgetAlerts && metrics.budgetAlerts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              Budget Alerts
            </CardTitle>
            <CardDescription>Categories approaching or exceeding budget limits</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {metrics.budgetAlerts.map((alert) => (
                <div key={alert.category_id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{alert.category_name}</p>
                    <p className="text-muted-foreground">
                      {formatCurrency(alert.total_amount)} of {formatCurrency(alert.budget_limit || 0)}
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge variant={alert.budget_utilization! > 100 ? "destructive" : "secondary"}>
                      {alert.budget_utilization?.toFixed(1)}%
                    </Badge>
                    <Progress 
                      value={Math.min(alert.budget_utilization || 0, 100)} 
                      className="w-32 mt-1"
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="users">User Activity</TabsTrigger>
          <TabsTrigger value="recent">Recent Transactions</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Weekly Trend */}
            <Card>
              <CardHeader>
                <CardTitle>Weekly Cash Flow</CardTitle>
                <CardDescription>Daily transaction summary for the past week</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {dashboardData.weekly_summary.map((day, index) => (
                    <div key={index} className="flex items-center justify-between p-2 border-b">
                      <span className="text-sm">{formatDate(day.date)}</span>
                      <div className="flex items-center gap-4">
                        <span className="text-sm text-green-600">
                          +{formatCurrency(day.total_receipts)}
                        </span>
                        <span className="text-sm text-red-600">
                          -{formatCurrency(day.total_payments)}
                        </span>
                        <span className={`text-sm font-medium ${day.net_amount >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatCurrency(day.net_amount)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Top Categories */}
            <Card>
              <CardHeader>
                <CardTitle>Top Spending Categories</CardTitle>
                <CardDescription>Highest spending categories this month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {metrics?.topCategories.map((category, index) => (
                    <div key={category.category_id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium">
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium">{category.category_name}</p>
                          <p className="text-muted-foreground">{category.transaction_count} transactions</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{formatCurrency(category.total_amount)}</p>
                        {category.budget_limit && (
                          <p className="text-muted-foreground">
                            {category.budget_utilization?.toFixed(1)}% of budget
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Category Performance</CardTitle>
              <CardDescription>Spending breakdown by category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Category</TableHead>
                      <TableHead>Transactions</TableHead>
                      <TableHead>Total Amount</TableHead>
                      <TableHead>Budget Limit</TableHead>
                      <TableHead>Utilization</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dashboardData.category_summary.map((category) => (
                      <TableRow key={category.category_id}>
                        <TableCell className="font-medium">{category.category_name}</TableCell>
                        <TableCell>{category.transaction_count}</TableCell>
                        <TableCell>{formatCurrency(category.total_amount)}</TableCell>
                        <TableCell>
                          {category.budget_limit ? formatCurrency(category.budget_limit) : 'No limit'}
                        </TableCell>
                        <TableCell>
                          {category.budget_utilization ? (
                            <div className="flex items-center gap-2">
                              <Progress value={Math.min(category.budget_utilization, 100)} className="w-16" />
                              <span className="text-sm">{category.budget_utilization.toFixed(1)}%</span>
                            </div>
                          ) : (
                            'N/A'
                          )}
                        </TableCell>
                        <TableCell>
                          {category.budget_limit ? (
                            <Badge variant={
                              (category.budget_utilization || 0) > 100 ? "destructive" :
                              (category.budget_utilization || 0) > 80 ? "secondary" : "default"
                            }>
                              {(category.budget_utilization || 0) > 100 ? 'Over Budget' :
                               (category.budget_utilization || 0) > 80 ? 'Warning' : 'On Track'}
                            </Badge>
                          ) : (
                            <Badge variant="outline">No Limit</Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>User Activity</CardTitle>
              <CardDescription>Transaction activity by user</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Transactions</TableHead>
                      <TableHead>Total Amount</TableHead>
                      <TableHead>Last Activity</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dashboardData.user_activity.map((user) => (
                      <TableRow key={user.user_id}>
                        <TableCell className="font-medium">{user.user_name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{user.role}</Badge>
                        </TableCell>
                        <TableCell>{user.transaction_count}</TableCell>
                        <TableCell>{formatCurrency(user.total_amount)}</TableCell>
                        <TableCell>{formatDateTime(user.last_activity)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recent" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>Latest transaction activity across all users</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Payment Mode</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dashboardData.recent_transactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="font-mono">{transaction.id}</TableCell>
                        <TableCell>{transaction.user_name}</TableCell>
                        <TableCell>{transaction.category_name}</TableCell>
                        <TableCell>{formatCurrency(transaction.amount)}</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {getPaymentModeIcon(transaction.payment_mode)} {transaction.payment_mode}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(transaction.status)}>
                            {transaction.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{formatDateTime(transaction.transaction_date)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}