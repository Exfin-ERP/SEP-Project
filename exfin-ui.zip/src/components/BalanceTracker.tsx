import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { DollarSign, TrendingUp, TrendingDown, Calendar, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { format } from "date-fns";
import { useAuth } from './AuthContext';

interface BalanceTrackerProps {
  expenses: any[];
}

export function BalanceTracker({ expenses }: BalanceTrackerProps) {
  const { user } = useAuth();

  // Mock balance data - in real app, this would come from backend
  const [balanceData] = useState({
    openingBalance: 25000.00,
    allocatedBalance: 25000.00,
    currentBalance: 22350.75,
    totalSpent: 2649.25,
    pendingApprovals: 850.00,
    projectedBalance: 21500.75, // currentBalance - pendingApprovals
    monthlyLimit: 25000.00,
    warningThreshold: 5000.00, // Warning when balance goes below this
    criticalThreshold: 2000.00 // Critical when balance goes below this
  });

  // Calculate balance status
  const balancePercentage = (balanceData.currentBalance / balanceData.allocatedBalance) * 100;
  const spentPercentage = (balanceData.totalSpent / balanceData.allocatedBalance) * 100;
  
  const getBalanceStatus = () => {
    if (balanceData.currentBalance <= balanceData.criticalThreshold) {
      return { status: 'Critical', color: 'text-red-600', bgColor: 'bg-red-100' };
    } else if (balanceData.currentBalance <= balanceData.warningThreshold) {
      return { status: 'Warning', color: 'text-yellow-600', bgColor: 'bg-yellow-100' };
    } else {
      return { status: 'Good', color: 'text-green-600', bgColor: 'bg-green-100' };
    }
  };

  const balanceStatus = getBalanceStatus();

  // Filter accountant's transactions
  const accountantTransactions = useMemo(() => {
    return expenses
      .filter(expense => expense.accountantName === user?.name)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [expenses, user?.name]);

  // Group transactions by status
  const transactionsByStatus = useMemo(() => {
    const grouped = {
      approved: accountantTransactions.filter(t => t.status === 'Approved'),
      pending: accountantTransactions.filter(t => t.status === 'Pending'),
      rejected: accountantTransactions.filter(t => t.status === 'Rejected')
    };
    return grouped;
  }, [accountantTransactions]);

  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  };

  // Daily spending for the current month
  const dailySpending = useMemo(() => {
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    const monthlyTransactions = accountantTransactions.filter(t => {
      const transactionDate = new Date(t.date);
      return transactionDate.getMonth() === currentMonth && 
             transactionDate.getFullYear() === currentYear &&
             t.status === 'Approved';
    });

    // Group by date
    const grouped = monthlyTransactions.reduce((acc, transaction) => {
      const dateKey = format(new Date(transaction.date), 'yyyy-MM-dd');
      if (!acc[dateKey]) {
        acc[dateKey] = 0;
      }
      acc[dateKey] += transaction.amount;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(grouped)
      .map(([date, amount]) => ({ date, amount }))
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(-7); // Last 7 days
  }, [accountantTransactions]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Balance Tracker</h2>
          <p className="text-muted-foreground">Monitor your expenditure balance and spending patterns</p>
        </div>
        <Badge className={`${balanceStatus.bgColor} ${balanceStatus.color}`}>
          Balance Status: {balanceStatus.status}
        </Badge>
      </div>

      {/* Balance Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Opening Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(balanceData.openingBalance)}</div>
            <p className="text-xs text-muted-foreground">Monthly allocated amount</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Balance</CardTitle>
            <DollarSign className={`h-4 w-4 ${balanceStatus.color}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${balanceStatus.color}`}>
              {formatCurrency(balanceData.currentBalance)}
            </div>
            <div className="flex items-center text-xs text-muted-foreground">
              <span>{balancePercentage.toFixed(1)}% remaining</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {formatCurrency(balanceData.totalSpent)}
            </div>
            <div className="flex items-center text-xs text-muted-foreground">
              <span>{spentPercentage.toFixed(1)}% of allocated</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <Clock className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {formatCurrency(balanceData.pendingApprovals)}
            </div>
            <p className="text-xs text-muted-foreground">
              Projected: {formatCurrency(balanceData.projectedBalance)}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Balance Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Balance Utilization
          </CardTitle>
          <CardDescription>Track your spending against allocated budget</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">Spent Amount</span>
              <span className="text-sm">{formatCurrency(balanceData.totalSpent)} / {formatCurrency(balanceData.allocatedBalance)}</span>
            </div>
            <Progress value={spentPercentage} className="h-2" />
            <p className="text-xs text-muted-foreground mt-1">
              {spentPercentage.toFixed(1)}% of budget utilized
            </p>
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">Remaining Balance</span>
              <span className="text-sm">{formatCurrency(balanceData.currentBalance)} remaining</span>
            </div>
            <Progress value={balancePercentage} className="h-2" />
            <p className="text-xs text-muted-foreground mt-1">
              {balancePercentage.toFixed(1)}% balance remaining
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Warnings and Alerts */}
      {balanceData.currentBalance <= balanceData.warningThreshold && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-700">
              <AlertTriangle className="w-5 h-5" />
              {balanceData.currentBalance <= balanceData.criticalThreshold ? 'Critical Balance Alert' : 'Low Balance Warning'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-yellow-700">
              {balanceData.currentBalance <= balanceData.criticalThreshold 
                ? `Your balance is critically low at ${formatCurrency(balanceData.currentBalance)}. Please contact management immediately.`
                : `Your balance is running low at ${formatCurrency(balanceData.currentBalance)}. Consider planning expenditures carefully.`
              }
            </p>
          </CardContent>
        </Card>
      )}

      {/* Transaction Status Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-600">
              <CheckCircle className="w-5 h-5" />
              Approved Transactions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{transactionsByStatus.approved.length}</div>
            <p className="text-sm text-muted-foreground">
              Total: {formatCurrency(transactionsByStatus.approved.reduce((sum, t) => sum + t.amount, 0))}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-600">
              <Clock className="w-5 h-5" />
              Pending Approvals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-600">{transactionsByStatus.pending.length}</div>
            <p className="text-sm text-muted-foreground">
              Total: {formatCurrency(transactionsByStatus.pending.reduce((sum, t) => sum + t.amount, 0))}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-5 h-5" />
              Rejected Transactions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">{transactionsByStatus.rejected.length}</div>
            <p className="text-sm text-muted-foreground">
              Total: {formatCurrency(transactionsByStatus.rejected.reduce((sum, t) => sum + t.amount, 0))}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Daily Spending Trend */}
      {dailySpending.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Daily Spending (Last 7 Days)
            </CardTitle>
            <CardDescription>Track your daily expenditure patterns</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Amount Spent</TableHead>
                  <TableHead>Percentage of Daily Avg</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dailySpending.map((day) => {
                  const avgDaily = balanceData.totalSpent / 30; // Rough daily average
                  const percentage = (day.amount / avgDaily) * 100;
                  
                  return (
                    <TableRow key={day.date}>
                      <TableCell>{format(new Date(day.date), 'dd MMM yyyy')}</TableCell>
                      <TableCell>{formatCurrency(day.amount)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span>{percentage.toFixed(0)}%</span>
                          <Progress value={Math.min(percentage, 200)} className="w-20 h-2" />
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Balance Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle>Balance Management Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-medium mb-2 text-green-600">Good Practices:</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Monitor balance daily</li>
                <li>• Plan major expenditures in advance</li>
                <li>• Submit bills promptly for faster approval</li>
                <li>• Keep detailed records of all transactions</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2 text-red-600">Warning Signs:</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Balance below ₹5,000 (warning threshold)</li>
                <li>• Balance below ₹2,000 (critical threshold)</li>
                <li>• High number of pending approvals</li>
                <li>• Spending over 80% of allocated budget</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}