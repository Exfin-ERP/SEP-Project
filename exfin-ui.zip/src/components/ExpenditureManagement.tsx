import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Badge } from "./ui/badge";
import { Textarea } from "./ui/textarea";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Alert, AlertDescription } from "./ui/alert";
import { toast } from "sonner@2.0.3";
import { 
  DollarSign, 
  Users, 
  Building, 
  ShoppingCart, 
  Wrench, 
  PartyPopper,
  CreditCard,
  CalendarIcon,
  Download,
  Search,
  Filter,
  Plus,
  Upload,
  AlertCircle
} from 'lucide-react';
import { format } from 'date-fns';
import { UserLoginInfo } from './UserLoginInfo';

interface ExpenditureEntry {
  id: string;
  category: 'Salaries' | 'Rent & Utilities' | 'Purchases' | 'Maintenance' | 'Events & Activities' | 'Loan Repayments' | 'Miscellaneous';
  staffId?: string;
  staffName?: string;
  designation?: string;
  month?: string;
  grossSalary?: number;
  deductions?: number;
  netPay?: number;
  vendorName?: string;
  billNo?: string;
  invoiceNo?: string;
  itemName?: string;
  quantity?: number;
  rate?: number;
  serviceType?: string;
  eventName?: string;
  budgetAllocated?: number;
  actualSpend?: number;
  loanId?: string;
  emiAmount?: number;
  balanceAmount?: number;
  amount: number;
  date: Date;
  dueDate?: Date;
  paidDate?: Date;
  paymentMode: 'Cash' | 'Online' | 'Cheque' | 'DD' | 'UPI';
  status: 'Paid' | 'Pending' | 'Approved' | 'Rejected';
  approvalStatus: 'Pending' | 'Approved' | 'Rejected';
  approvedBy?: string;
  description: string;
  tdsApplicable: boolean;
  tdsAmount?: number;
  gstApplicable: boolean;
  gstAmount?: number;
  attachments?: string[];
  remarks?: string;
}

export function ExpenditureManagement() {
  const [activeTab, setActiveTab] = useState('add');
  const [expenditures, setExpenditures] = useState<ExpenditureEntry[]>([]);
  const [formData, setFormData] = useState<Partial<ExpenditureEntry>>({
    category: 'Salaries',
    date: new Date(),
    paymentMode: 'Cash',
    status: 'Pending',
    approvalStatus: 'Pending',
    tdsApplicable: false,
    gstApplicable: false
  });
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [dueDate, setDueDate] = useState<Date | undefined>();
  const [paidDate, setPaidDate] = useState<Date | undefined>();
  const [searchTerm, setSearchTerm] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.amount || !formData.description) {
      toast.error('Please fill all required fields');
      return;
    }

    // Calculate TDS and GST if applicable
    let finalAmount = Number(formData.amount);
    if (formData.tdsApplicable && formData.tdsAmount) {
      finalAmount -= formData.tdsAmount;
    }
    if (formData.gstApplicable && formData.gstAmount) {
      finalAmount += formData.gstAmount;
    }

    const newExpenditure: ExpenditureEntry = {
      id: `EXP${Date.now()}`,
      category: formData.category as ExpenditureEntry['category'],
      staffId: formData.staffId,
      staffName: formData.staffName,
      designation: formData.designation,
      month: formData.month,
      grossSalary: formData.grossSalary,
      deductions: formData.deductions,
      netPay: formData.netPay,
      vendorName: formData.vendorName,
      billNo: formData.billNo,
      invoiceNo: formData.invoiceNo,
      itemName: formData.itemName,
      quantity: formData.quantity,
      rate: formData.rate,
      serviceType: formData.serviceType,
      eventName: formData.eventName,
      budgetAllocated: formData.budgetAllocated,
      actualSpend: formData.actualSpend,
      loanId: formData.loanId,
      emiAmount: formData.emiAmount,
      balanceAmount: formData.balanceAmount,
      amount: finalAmount,
      date: selectedDate || new Date(),
      dueDate: dueDate,
      paidDate: paidDate,
      paymentMode: formData.paymentMode as ExpenditureEntry['paymentMode'],
      status: formData.status as ExpenditureEntry['status'],
      approvalStatus: formData.approvalStatus as ExpenditureEntry['approvalStatus'],
      approvedBy: formData.approvedBy,
      description: formData.description,
      tdsApplicable: formData.tdsApplicable || false,
      tdsAmount: formData.tdsAmount,
      gstApplicable: formData.gstApplicable || false,
      gstAmount: formData.gstAmount,
      attachments: formData.attachments,
      remarks: formData.remarks
    };

    setExpenditures([newExpenditure, ...expenditures]);
    
    if (finalAmount > 50000) {
      toast.warning(`High-value expenditure added - Amount: ₹${finalAmount.toLocaleString('en-IN')}. Approval required.`);
    } else {
      toast.success(`Expenditure entry added successfully - ID: ${newExpenditure.id}`);
    }
    
    // Reset form
    setFormData({
      category: 'Salaries',
      date: new Date(),
      paymentMode: 'Cash',
      status: 'Pending',
      approvalStatus: 'Pending',
      tdsApplicable: false,
      gstApplicable: false
    });
    setSelectedDate(new Date());
    setDueDate(undefined);
    setPaidDate(undefined);
  };

  const filteredExpenditures = expenditures.filter(exp => 
    exp.staffName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exp.vendorName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exp.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exp.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalExpenditure = expenditures.reduce((sum, exp) => sum + exp.amount, 0);
  const monthlyExpenditure = expenditures
    .filter(exp => {
      const expDate = new Date(exp.date);
      const now = new Date();
      return expDate.getMonth() === now.getMonth() && expDate.getFullYear() === now.getFullYear();
    })
    .reduce((sum, exp) => sum + exp.amount, 0);

  const pendingApprovals = expenditures.filter(exp => exp.approvalStatus === 'Pending').length;

  const renderFormFields = () => {
    switch (formData.category) {
      case 'Salaries':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="staffId">Staff ID *</Label>
                <Input
                  id="staffId"
                  value={formData.staffId || ''}
                  onChange={(e) => setFormData({ ...formData, staffId: e.target.value })}
                  placeholder="Enter staff ID"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="staffName">Staff Name *</Label>
                <Input
                  id="staffName"
                  value={formData.staffName || ''}
                  onChange={(e) => setFormData({ ...formData, staffName: e.target.value })}
                  placeholder="Enter staff name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="designation">Designation *</Label>
                <Input
                  id="designation"
                  value={formData.designation || ''}
                  onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                  placeholder="Enter designation"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="month">Salary Month *</Label>
                <Select value={formData.month} onValueChange={(value) => setFormData({ ...formData, month: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select month" />
                  </SelectTrigger>
                  <SelectContent>
                    {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(month => (
                      <SelectItem key={month} value={month}>{month}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="grossSalary">Gross Salary (₹) *</Label>
                <Input
                  id="grossSalary"
                  type="number"
                  value={formData.grossSalary || ''}
                  onChange={(e) => {
                    const gross = parseFloat(e.target.value);
                    const deductions = formData.deductions || 0;
                    setFormData({ 
                      ...formData, 
                      grossSalary: gross,
                      netPay: gross - deductions,
                      amount: gross - deductions
                    });
                  }}
                  placeholder="Enter gross salary"
                  min="0"
                  step="0.01"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="deductions">Deductions (₹)</Label>
                <Input
                  id="deductions"
                  type="number"
                  value={formData.deductions || ''}
                  onChange={(e) => {
                    const deductions = parseFloat(e.target.value) || 0;
                    const gross = formData.grossSalary || 0;
                    setFormData({ 
                      ...formData, 
                      deductions: deductions,
                      netPay: gross - deductions,
                      amount: gross - deductions
                    });
                  }}
                  placeholder="PF, TDS, etc."
                  min="0"
                  step="0.01"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="netPay">Net Pay (₹)</Label>
                <Input
                  id="netPay"
                  type="number"
                  value={formData.netPay || ''}
                  disabled
                  className="bg-muted"
                />
              </div>
            </div>
          </>
        );

      case 'Rent & Utilities':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="vendorName">Vendor Name *</Label>
                <Input
                  id="vendorName"
                  value={formData.vendorName || ''}
                  onChange={(e) => setFormData({ ...formData, vendorName: e.target.value })}
                  placeholder="Enter vendor name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="billNo">Bill Number *</Label>
                <Input
                  id="billNo"
                  value={formData.billNo || ''}
                  onChange={(e) => setFormData({ ...formData, billNo: e.target.value })}
                  placeholder="Enter bill number"
                />
              </div>
              <div className="space-y-2">
                <Label>Due Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dueDate ? format(dueDate, 'PPP') : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={dueDate}
                      onSelect={setDueDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-2">
                <Label>Paid Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {paidDate ? format(paidDate, 'PPP') : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={paidDate}
                      onSelect={setPaidDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </>
        );

      case 'Purchases':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="itemName">Item Name *</Label>
                <Input
                  id="itemName"
                  value={formData.itemName || ''}
                  onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                  placeholder="Enter item name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="vendorName">Vendor Name *</Label>
                <Input
                  id="vendorName"
                  value={formData.vendorName || ''}
                  onChange={(e) => setFormData({ ...formData, vendorName: e.target.value })}
                  placeholder="Enter vendor name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity *</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={formData.quantity || ''}
                  onChange={(e) => {
                    const qty = parseFloat(e.target.value);
                    const rate = formData.rate || 0;
                    setFormData({ 
                      ...formData, 
                      quantity: qty,
                      amount: qty * rate
                    });
                  }}
                  placeholder="Enter quantity"
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rate">Rate (₹) *</Label>
                <Input
                  id="rate"
                  type="number"
                  value={formData.rate || ''}
                  onChange={(e) => {
                    const rate = parseFloat(e.target.value);
                    const qty = formData.quantity || 0;
                    setFormData({ 
                      ...formData, 
                      rate: rate,
                      amount: qty * rate
                    });
                  }}
                  placeholder="Enter rate per unit"
                  min="0"
                  step="0.01"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="invoiceNo">Invoice Number *</Label>
                <Input
                  id="invoiceNo"
                  value={formData.invoiceNo || ''}
                  onChange={(e) => setFormData({ ...formData, invoiceNo: e.target.value })}
                  placeholder="Enter invoice number"
                />
              </div>
            </div>
          </>
        );

      case 'Maintenance':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="serviceType">Service Type *</Label>
                <Select value={formData.serviceType} onValueChange={(value) => setFormData({ ...formData, serviceType: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select service type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Building Maintenance">Building Maintenance</SelectItem>
                    <SelectItem value="Electrical Work">Electrical Work</SelectItem>
                    <SelectItem value="Plumbing">Plumbing</SelectItem>
                    <SelectItem value="Painting">Painting</SelectItem>
                    <SelectItem value="Cleaning">Cleaning</SelectItem>
                    <SelectItem value="Equipment Repair">Equipment Repair</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="vendorName">Vendor Name *</Label>
                <Input
                  id="vendorName"
                  value={formData.vendorName || ''}
                  onChange={(e) => setFormData({ ...formData, vendorName: e.target.value })}
                  placeholder="Enter vendor name"
                />
              </div>
            </div>
          </>
        );

      case 'Events & Activities':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="eventName">Event Name *</Label>
                <Input
                  id="eventName"
                  value={formData.eventName || ''}
                  onChange={(e) => setFormData({ ...formData, eventName: e.target.value })}
                  placeholder="Enter event name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="budgetAllocated">Budget Allocated (₹)</Label>
                <Input
                  id="budgetAllocated"
                  type="number"
                  value={formData.budgetAllocated || ''}
                  onChange={(e) => setFormData({ ...formData, budgetAllocated: parseFloat(e.target.value) })}
                  placeholder="Enter budget"
                  min="0"
                  step="0.01"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="actualSpend">Actual Spend (₹) *</Label>
                <Input
                  id="actualSpend"
                  type="number"
                  value={formData.actualSpend || ''}
                  onChange={(e) => setFormData({ ...formData, actualSpend: parseFloat(e.target.value), amount: parseFloat(e.target.value) })}
                  placeholder="Enter actual spend"
                  min="0"
                  step="0.01"
                />
              </div>
            </div>
            {formData.budgetAllocated && formData.actualSpend && formData.actualSpend > formData.budgetAllocated && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Warning: Actual spend exceeds allocated budget by ₹{(formData.actualSpend - formData.budgetAllocated).toLocaleString('en-IN')}
                </AlertDescription>
              </Alert>
            )}
          </>
        );

      case 'Loan Repayments':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="loanId">Loan ID *</Label>
                <Input
                  id="loanId"
                  value={formData.loanId || ''}
                  onChange={(e) => setFormData({ ...formData, loanId: e.target.value })}
                  placeholder="Enter loan ID"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="emiAmount">EMI Amount (₹) *</Label>
                <Input
                  id="emiAmount"
                  type="number"
                  value={formData.emiAmount || ''}
                  onChange={(e) => setFormData({ ...formData, emiAmount: parseFloat(e.target.value), amount: parseFloat(e.target.value) })}
                  placeholder="Enter EMI amount"
                  min="0"
                  step="0.01"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="balanceAmount">Balance Amount (₹)</Label>
                <Input
                  id="balanceAmount"
                  type="number"
                  value={formData.balanceAmount || ''}
                  onChange={(e) => setFormData({ ...formData, balanceAmount: parseFloat(e.target.value) })}
                  placeholder="Enter balance"
                  min="0"
                  step="0.01"
                />
              </div>
            </div>
          </>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* User Login Info */}
      <UserLoginInfo className="bg-blue-50 p-3 rounded-lg border border-blue-200" />
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Expenditure</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">₹{totalExpenditure.toLocaleString('en-IN')}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">This Month</CardTitle>
            <CalendarIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">₹{monthlyExpenditure.toLocaleString('en-IN')}</div>
            <p className="text-xs text-muted-foreground">{format(new Date(), 'MMMM yyyy')}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Pending Approvals</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{pendingApprovals}</div>
            <p className="text-xs text-muted-foreground">Awaiting approval</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Entries</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{expenditures.length}</div>
            <p className="text-xs text-muted-foreground">Expenditure records</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Card>
        <CardHeader>
          <CardTitle>Expenditure Management</CardTitle>
          <CardDescription>Track all outgoing payments including salaries, purchases, and other expenses</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="add">
                <Plus className="w-4 h-4 mr-2" />
                Add Expenditure
              </TabsTrigger>
              <TabsTrigger value="list">
                <Filter className="w-4 h-4 mr-2" />
                View Records
              </TabsTrigger>
            </TabsList>

            <TabsContent value="add" className="space-y-4">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Category Selection */}
                <div className="space-y-2">
                  <Label htmlFor="category">Expenditure Category *</Label>
                  <Select value={formData.category} onValueChange={(value: ExpenditureEntry['category']) => setFormData({ ...formData, category: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Salaries">
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4" />
                          Salaries
                        </div>
                      </SelectItem>
                      <SelectItem value="Rent & Utilities">
                        <div className="flex items-center gap-2">
                          <Building className="w-4 h-4" />
                          Rent & Utilities
                        </div>
                      </SelectItem>
                      <SelectItem value="Purchases">
                        <div className="flex items-center gap-2">
                          <ShoppingCart className="w-4 h-4" />
                          Purchases
                        </div>
                      </SelectItem>
                      <SelectItem value="Maintenance">
                        <div className="flex items-center gap-2">
                          <Wrench className="w-4 h-4" />
                          Maintenance
                        </div>
                      </SelectItem>
                      <SelectItem value="Events & Activities">
                        <div className="flex items-center gap-2">
                          <PartyPopper className="w-4 h-4" />
                          Events & Activities
                        </div>
                      </SelectItem>
                      <SelectItem value="Loan Repayments">
                        <div className="flex items-center gap-2">
                          <CreditCard className="w-4 h-4" />
                          Loan Repayments
                        </div>
                      </SelectItem>
                      <SelectItem value="Miscellaneous">Miscellaneous</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Dynamic Fields Based on Category */}
                {renderFormFields()}

                {/* Common Fields */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (₹) *</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={formData.amount || ''}
                      onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) })}
                      placeholder="Enter amount"
                      min="0"
                      step="0.01"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="paymentMode">Payment Mode *</Label>
                    <Select value={formData.paymentMode} onValueChange={(value: ExpenditureEntry['paymentMode']) => setFormData({ ...formData, paymentMode: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select payment mode" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Cash">Cash</SelectItem>
                        <SelectItem value="Online">Online Transfer</SelectItem>
                        <SelectItem value="Cheque">Cheque</SelectItem>
                        <SelectItem value="DD">Demand Draft</SelectItem>
                        <SelectItem value="UPI">UPI</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Transaction Date *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={setSelectedDate}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="status">Payment Status *</Label>
                    <Select value={formData.status} onValueChange={(value: ExpenditureEntry['status']) => setFormData({ ...formData, status: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Paid">Paid</SelectItem>
                        <SelectItem value="Pending">Pending</SelectItem>
                        <SelectItem value="Approved">Approved</SelectItem>
                        <SelectItem value="Rejected">Rejected</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* TDS and GST */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="tdsApplicable"
                        checked={formData.tdsApplicable}
                        onChange={(e) => setFormData({ ...formData, tdsApplicable: e.target.checked })}
                        className="h-4 w-4 rounded border-gray-300"
                      />
                      <Label htmlFor="tdsApplicable" className="cursor-pointer">TDS Applicable</Label>
                    </div>
                    {formData.tdsApplicable && (
                      <Input
                        type="number"
                        placeholder="TDS Amount (₹)"
                        value={formData.tdsAmount || ''}
                        onChange={(e) => setFormData({ ...formData, tdsAmount: parseFloat(e.target.value) })}
                        min="0"
                        step="0.01"
                      />
                    )}
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="gstApplicable"
                        checked={formData.gstApplicable}
                        onChange={(e) => setFormData({ ...formData, gstApplicable: e.target.checked })}
                        className="h-4 w-4 rounded border-gray-300"
                      />
                      <Label htmlFor="gstApplicable" className="cursor-pointer">GST Applicable</Label>
                    </div>
                    {formData.gstApplicable && (
                      <Input
                        type="number"
                        placeholder="GST Amount (₹)"
                        value={formData.gstAmount || ''}
                        onChange={(e) => setFormData({ ...formData, gstAmount: parseFloat(e.target.value) })}
                        min="0"
                        step="0.01"
                      />
                    )}
                  </div>
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    value={formData.description || ''}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Enter detailed description"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="remarks">Remarks (Optional)</Label>
                  <Textarea
                    id="remarks"
                    value={formData.remarks || ''}
                    onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                    placeholder="Additional remarks"
                    rows={2}
                  />
                </div>

                {/* File Upload */}
                <div className="space-y-2">
                  <Label htmlFor="attachments">Supporting Documents</Label>
                  <div className="flex items-center gap-2">
                    <Button type="button" variant="outline" className="w-full">
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Invoice/Bill
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">Upload invoices, receipts, or other supporting documents (PDF, JPG, PNG)</p>
                </div>

                <div className="flex gap-4">
                  <Button type="submit" className="flex-1">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Expenditure Entry
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setFormData({
                        category: 'Salaries',
                        date: new Date(),
                        paymentMode: 'Cash',
                        status: 'Pending',
                        approvalStatus: 'Pending',
                        tdsApplicable: false,
                        gstApplicable: false
                      });
                      setSelectedDate(new Date());
                      setDueDate(undefined);
                      setPaidDate(undefined);
                    }}
                  >
                    Reset
                  </Button>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="list" className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by staff/vendor name, ID..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Payee/Vendor</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Payment Mode</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Approval</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredExpenditures.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-muted-foreground">
                          No expenditure records found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredExpenditures.map((expenditure) => (
                        <TableRow key={expenditure.id}>
                          <TableCell className="font-mono text-xs">{expenditure.id}</TableCell>
                          <TableCell>{format(expenditure.date, 'dd/MM/yyyy')}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{expenditure.category}</Badge>
                          </TableCell>
                          <TableCell>
                            {expenditure.staffName || expenditure.vendorName || '-'}
                          </TableCell>
                          <TableCell>₹{expenditure.amount.toLocaleString('en-IN')}</TableCell>
                          <TableCell>{expenditure.paymentMode}</TableCell>
                          <TableCell>
                            <Badge variant={
                              expenditure.status === 'Paid' ? 'default' :
                              expenditure.status === 'Pending' ? 'secondary' :
                              expenditure.status === 'Approved' ? 'default' :
                              'destructive'
                            }>
                              {expenditure.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={
                              expenditure.approvalStatus === 'Approved' ? 'default' :
                              expenditure.approvalStatus === 'Pending' ? 'secondary' :
                              'destructive'
                            }>
                              {expenditure.approvalStatus}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
