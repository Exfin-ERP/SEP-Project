import { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'Admin' | 'Management' | 'Accountant' | 'Viewer';
export type Organization = 'Pragyana Educational Society' | 'Sriven Educational Society' | 'Sri Venkateswara Enterprises';
export type BranchType = 'School' | 'College';

export interface Branch {
  id: string;
  name: string;
  type: BranchType;
  code: string;
  location: string;
  accountantId?: string;
}

export interface User {
  id: string;
  email: string;
  phone?: string;
  role: UserRole;
  organization?: Organization;
  name: string;
  branchId?: string;
  branch?: Branch;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, phone?: string, role?: UserRole, organization?: Organization) => Promise<void>;
  verifyOTP: (otp: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
  otpSent: boolean;
  pendingCredentials: { email: string; phone?: string; role?: UserRole; organization?: Organization } | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Predefined accountant credentials - SRIVISWA 2025 Master Data
const accountantCredentials = {
  // College Accountants
  '9059037007': { name: 'SK NAGOOR SIR', branch: 'DC-2', type: 'College' },
  '9676971116': { name: 'SURESH SIR', branch: 'CHANDRAPALEM', type: 'College' },
  '9704201809': { name: 'SATYANARAYANA SIR', branch: 'DC-1', type: 'College' },
  '8297632185': { name: 'M V GANESH SIR', branch: 'REVOLT', type: 'College' },
  '9640314659': { name: 'SATYAVENI MADAM', branch: 'LT', type: 'College' },
  '8106662336': { name: 'SRIDEVI MADAM', branch: 'GH-1,2,3,4,5', type: 'College' },
  '7095355390': { name: 'CHAKRADHAR SIR', branch: 'INDIAN BULLS', type: 'College' },
  '9493989799': { name: 'SRIRAM SIR', branch: 'PM PALEM', type: 'College' },
  '8464968380': { name: 'NAGU SIR', branch: 'YENDADA', type: 'College' },
  '9110382520': { name: 'MANITEJA SIR', branch: 'MAX', type: 'College' },
  '7989451125': { name: 'RAMAKRISHNA SIR', branch: 'SIVA SIVANI', type: 'College' },
  
  // School Accountants
  '9573737184': { name: 'DURGA MADAM', branch: 'DAY CAMPUS', type: 'School' },
  '8499035618': { name: 'DURGA MADAM', branch: 'THAGARAPUVALASA', type: 'School' },
  '9666762056': { name: 'SATYAVATHI MADAM', branch: 'BOYAPALEM', type: 'School' },
  '9494918171': { name: 'ANANTH SIR', branch: 'SONTYAM', type: 'School' },
  
  // Admin Users
  'admin@sriviswa.com': { name: 'Manikanta', branch: 'Central Office', type: 'Admin' },
  
  // Management Users
  'management@sriviswa.com': { name: 'Chairman Sir', branch: 'Head Office', type: 'Management' }
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [pendingCredentials, setPendingCredentials] = useState<{ email: string; phone?: string; role?: UserRole; organization?: Organization } | null>(null);

  const login = async (email: string, phone?: string, role?: UserRole, organization?: Organization) => {
    setIsLoading(true);
    try {
      // Simulate API call for sending OTP
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setPendingCredentials({ email, phone, role, organization });
      setOtpSent(true);
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const verifyOTP = async (otp: string) => {
    setIsLoading(true);
    try {
      // Simulate API call for OTP verification
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (otp !== '123456') {
        throw new Error('Invalid OTP');
      }

      if (!pendingCredentials) {
        throw new Error('No pending credentials');
      }

      // Check credentials by email or phone
      const emailKey = pendingCredentials.email as keyof typeof accountantCredentials;
      const phoneKey = pendingCredentials.phone as keyof typeof accountantCredentials;
      const accountantInfo = accountantCredentials[emailKey] || accountantCredentials[phoneKey];
      
      // Determine role and name
      let userRole: UserRole = pendingCredentials.role || 'Viewer';
      let userName = 'User';
      
      if (accountantInfo) {
        if (accountantInfo.type === 'Admin') {
          userRole = 'Admin';
        } else if (accountantInfo.type === 'Management') {
          userRole = 'Management';
        } else {
          userRole = 'Accountant';
        }
        userName = accountantInfo.name;
      } else if (pendingCredentials.role) {
        userRole = pendingCredentials.role;
        userName = pendingCredentials.role === 'Admin' ? 'Admin User' : 
                   pendingCredentials.role === 'Management' ? 'Management User' :
                   pendingCredentials.role === 'Accountant' ? 'Accountant User' : 'Viewer User';
      }
      
      const newUser: User = {
        id: Date.now().toString(),
        email: pendingCredentials.email,
        phone: pendingCredentials.phone,
        role: userRole,
        organization: pendingCredentials.organization,
        name: userName
      };

      setUser(newUser);
      setPendingCredentials(null);
      setOtpSent(false);
    } catch (error) {
      console.error('OTP verification error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setPendingCredentials(null);
    setOtpSent(false);
  };

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      login,
      verifyOTP,
      logout,
      isLoading,
      otpSent,
      pendingCredentials
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}