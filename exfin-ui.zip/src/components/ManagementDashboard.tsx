import { RealTimeManagementDashboard } from './RealTimeManagementDashboard';

export function ManagementDashboard() {
  return <RealTimeManagementDashboard />;
}