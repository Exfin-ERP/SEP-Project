import { useState, useCallback, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "./ui/dialog";
import { 
  Search, 
  CalendarDays, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Banknote,
  Phone,
  Mail,
  Eye,
  History
} from 'lucide-react';
import { toast } from "sonner@2.0.3";
import { useAuth } from './AuthContext';
import { VendorData } from './VendorRegistration';

// Simple date formatter
const formatDate = (date: Date) => {
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
};

interface PaymentRecord {
  id: string;
  vendorId: string;
  vendorName: string;
  institution: string;
  invoiceNumber: string;
  invoiceDate: Date;
  amount: number;
  description: string;
  paymentMethod: string;
  transactionId: string;
  paymentDate: Date;
  status: 'Completed' | 'Pending' | 'Failed';
  processedBy: string;
}

// All Sriviswa institutions
const institutions = [
  'SONTYAM', 'THAGARAPUVALASA', 'BOYAPALEM', 'DAY SCHOOL',
  'SRIVEN BC-1', 'SRIVEN BC-2', 'SRIVEN DC-1', 'SRIVEN DC-2', 'SRIVEN GC-1',
  'SRIVEN LTG', 'SRIVEN LT SPARK', 'SRIVEN BC-4', 'SRIVEN SIVASIVANI',
  'SRIVEN MESS', 'SRIVEN BHAVISHYA', 'SRIVEN GCON', 'SRIVEN HAPPY LIFE',
  'SRIVEN NETWORK OFFICE', 'SRIVEN GC4(HOSTEL BLOCK)', 'SRIVEN GC4(CLASS BLOCK)',
  'SRIVEN MAX(BC-6)', 'SRI VENKATESWARA ENTERPRISES', 'CENTRAL OFFICE'
];

const paymentMethods = ['NEFT', 'RTGS', 'UPI', 'Cheque'];

// Sample data
const sampleVendors: VendorData[] = [
  {
    id: 'VEN-001',
    vendorName: 'ABC Catering Services',
    vendorType: 'Mess & Catering',
    contactPersonName: 'Rajesh Kumar',
    mobileNumber: '9876543210',
    emailId: 'rajesh@abccatering.com',
    fullAddress: 'Shop No. 15, Food Street, Visakhapatnam, AP - 530001',
    panCardNumber: 'ABCDE1234F',
    gstinNumber: '37ABCDE1234F1Z5',
    bankAccountHolderName: 'ABC Catering Services',
    bankName: 'State Bank of India',
    bankAccountNumber: '12345678901',
    ifscCode: 'SBIN0001234',
    accountType: 'Current',
    contractStartDate: new Date('2024-01-01'),
    paymentDueDates: '5th of every month',
    status: 'approved',
    registeredDate: new Date('2024-01-15')
  },
  {
    id: 'VEN-002',
    vendorName: 'Power Grid Corporation',
    vendorType: 'Electricity Provider',
    contactPersonName: 'Srinivas Rao',
    mobileNumber: '9123456789',
    emailId: 'srinivas@powergrid.gov.in',
    fullAddress: 'Electricity Board, Power House Road, Visakhapatnam, AP - 530002',
    panCardNumber: 'PGCOR5678H',
    gstinNumber: '37PGCOR5678H1Z3',
    bankAccountHolderName: 'Power Grid Corporation',
    bankName: 'Canara Bank',
    bankAccountNumber: '98765432101',
    ifscCode: 'CNRB0005678',
    accountType: 'Current',
    contractStartDate: new Date('2024-01-01'),
    paymentDueDates: '10th of every month',
    status: 'approved',
    registeredDate: new Date('2024-01-10')
  }
];

const samplePaymentHistory: PaymentRecord[] = [
  {
    id: 'PAY-001',
    vendorId: 'VEN-001',
    vendorName: 'ABC Catering Services',
    institution: 'SRIVEN BC-1',
    invoiceNumber: 'INV-2024-001',
    invoiceDate: new Date('2024-12-01'),
    amount: 85000,
    description: 'December 2024 Mess Bill',
    paymentMethod: 'NEFT',
    transactionId: 'NEFT123456789',
    paymentDate: new Date('2024-12-05'),
    status: 'Completed',
    processedBy: 'Admin User'
  }
];

interface VendorPaymentProps {
  vendors?: VendorData[];
  paymentHistory?: PaymentRecord[];
  onMakePayment?: (payment: Omit<PaymentRecord, 'id' | 'status' | 'processedBy'>) => void;
}

export function VendorPayment({ vendors, paymentHistory, onMakePayment }: VendorPaymentProps) {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVendor, setSelectedVendor] = useState<VendorData | null>(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [showVendorDetails, setShowVendorDetails] = useState(false);
  const [showPaymentHistory, setShowPaymentHistory] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  
  const displayVendors = vendors || sampleVendors;
  const displayPaymentHistory = paymentHistory || samplePaymentHistory;

  const [paymentData, setPaymentData] = useState({
    institution: '',
    invoiceNumber: '',
    amount: '',
    description: '',
    paymentMethod: 'NEFT',
    transactionId: ''
  });

  const [invoiceDate, setInvoiceDate] = useState<Date>(new Date());
  const [paymentDate, setPaymentDate] = useState<Date>(new Date());
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isProcessing, setIsProcessing] = useState(false);

  // Filter vendors based on search
  const filteredVendors = useMemo(() => 
    displayVendors.filter(vendor =>
      vendor.status === 'approved' && (
        vendor.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        vendor.vendorType.toLowerCase().includes(searchTerm.toLowerCase()) ||
        vendor.mobileNumber.includes(searchTerm) ||
        vendor.contactPersonName.toLowerCase().includes(searchTerm.toLowerCase())
      )
    ), [displayVendors, searchTerm]
  );

  const validatePaymentForm = useCallback(() => {
    const errors: Record<string, string> = {};

    if (!paymentData.institution) errors.institution = 'Institution selection is required';
    if (!paymentData.invoiceNumber.trim()) errors.invoiceNumber = 'Invoice number is required';
    
    const amount = parseFloat(paymentData.amount);
    if (!paymentData.amount || isNaN(amount) || amount <= 0) {
      errors.amount = 'Valid amount is required';
    }
    
    if (!paymentData.description.trim()) errors.description = 'Description is required';
    if (!paymentData.transactionId.trim()) {
      errors.transactionId = `${paymentData.paymentMethod} transaction ID is required`;
    }

    return errors;
  }, [paymentData]);

  const isFormValid = useMemo(() => {
    const formErrors = validatePaymentForm();
    return Object.keys(formErrors).length === 0;
  }, [validatePaymentForm]);

  const handleInputChange = useCallback((field: string, value: string) => {
    setPaymentData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  }, [errors]);

  const handleSelectVendor = useCallback((vendor: VendorData) => {
    setSelectedVendor(vendor);
    setShowPaymentForm(true);
  }, []);

  const handleMakePayment = async () => {
    const formErrors = validatePaymentForm();
    if (Object.keys(formErrors).length > 0 || !selectedVendor) {
      setErrors(formErrors);
      return;
    }

    setIsProcessing(true);
    try {
      const payment: Omit<PaymentRecord, 'id' | 'status' | 'processedBy'> = {
        vendorId: selectedVendor.id,
        vendorName: selectedVendor.vendorName,
        institution: paymentData.institution,
        invoiceNumber: paymentData.invoiceNumber.trim(),
        invoiceDate,
        amount: parseFloat(paymentData.amount),
        description: paymentData.description.trim(),
        paymentMethod: paymentData.paymentMethod,
        transactionId: paymentData.transactionId.trim(),
        paymentDate
      };

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));

      if (onMakePayment) {
        onMakePayment(payment);
      }

      toast.success(`Payment of ₹${payment.amount.toLocaleString()} made successfully to ${selectedVendor.vendorName}`);

      // Reset form
      setPaymentData({
        institution: '',
        invoiceNumber: '',
        amount: '',
        description: '',
        paymentMethod: 'NEFT',
        transactionId: ''
      });
      setInvoiceDate(new Date());
      setPaymentDate(new Date());
      setSelectedVendor(null);
      setShowPaymentForm(false);
      setShowConfirmDialog(false);

    } catch (error) {
      toast.error('Payment processing failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const getStatusBadge = (status: PaymentRecord['status']) => {
    switch (status) {
      case 'Completed':
        return <Badge variant="secondary" className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'Pending':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'Failed':
        return <Badge variant="destructive"><AlertCircle className="w-3 h-3 mr-1" />Failed</Badge>;
      default:
        return null;
    }
  };

  const handleConfirmPayment = () => {
    const formErrors = validatePaymentForm();
    if (Object.keys(formErrors).length === 0) {
      setShowConfirmDialog(true);
    } else {
      setErrors(formErrors);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Vendor Payment Portal</h1>
          <p className="text-muted-foreground">
            Make secure payments to registered vendors across all Sriviswa institutions
          </p>
        </div>
        <Button onClick={() => setShowPaymentHistory(true)} variant="outline" className="gap-2">
          <History className="w-4 h-4" />
          View Payment History
        </Button>
      </div>

      {!showPaymentForm ? (
        <>
          {/* Vendor Search */}
          <Card>
            <CardHeader>
              <CardTitle>A. Vendor Selection</CardTitle>
              <CardDescription>
                Search and select from registered vendors
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search vendors by name, type, mobile number..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8"
                  />
                </div>

                {filteredVendors.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    {searchTerm ? 'No vendors found matching your search.' : 'No approved vendors available.'}
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Vendor Name</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Contact</TableHead>
                          <TableHead>Payment Due</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredVendors.map((vendor) => (
                          <TableRow key={vendor.id}>
                            <TableCell>
                              <div>
                                <div className="font-medium">{vendor.vendorName}</div>
                                <div className="text-sm text-muted-foreground">{vendor.contactPersonName}</div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{vendor.vendorType}</Badge>
                            </TableCell>
                            <TableCell>
                              <div className="text-sm">
                                <div className="flex items-center gap-1">
                                  <Phone className="w-3 h-3" />
                                  {vendor.mobileNumber}
                                </div>
                                <div className="flex items-center gap-1">
                                  <Mail className="w-3 h-3" />
                                  {vendor.emailId}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell className="text-sm">{vendor.paymentDueDates}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedVendor(vendor);
                                    setShowVendorDetails(true);
                                  }}
                                >
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="default"
                                  size="sm"
                                  onClick={() => handleSelectVendor(vendor)}
                                >
                                  <Banknote className="w-4 h-4 mr-1" />
                                  Pay
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        <>
          {/* Payment Form */}
          <Card>
            <CardHeader>
              <CardTitle>B. Payment Details</CardTitle>
              <CardDescription>
                Making payment to: <strong>{selectedVendor?.vendorName}</strong>
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Vendor Bank Details */}
              <div className="mb-6 p-4 bg-muted rounded-lg">
                <h3 className="font-medium mb-2">Vendor Bank Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><strong>Account Holder:</strong> {selectedVendor?.bankAccountHolderName}</p>
                    <p><strong>Bank Name:</strong> {selectedVendor?.bankName}</p>
                  </div>
                  <div>
                    <p><strong>Account Number:</strong> {selectedVendor?.bankAccountNumber}</p>
                    <p><strong>IFSC Code:</strong> {selectedVendor?.ifscCode}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                {/* Institution Selection */}
                <div className="space-y-2">
                  <Label htmlFor="institution">Select Institution *</Label>
                  <Select value={paymentData.institution} onValueChange={(value) => handleInputChange('institution', value)}>
                    <SelectTrigger className={errors.institution ? 'border-red-500' : ''}>
                      <SelectValue placeholder="Select institution" />
                    </SelectTrigger>
                    <SelectContent>
                      {institutions.map((institution) => (
                        <SelectItem key={institution} value={institution}>
                          {institution}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.institution && <p className="text-sm text-red-500">{errors.institution}</p>}
                </div>

                {/* Invoice Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="invoiceNumber">Invoice Number *</Label>
                    <Input
                      id="invoiceNumber"
                      placeholder="Enter invoice number"
                      value={paymentData.invoiceNumber}
                      onChange={(e) => handleInputChange('invoiceNumber', e.target.value)}
                      className={errors.invoiceNumber ? 'border-red-500' : ''}
                    />
                    {errors.invoiceNumber && <p className="text-sm text-red-500">{errors.invoiceNumber}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label>Invoice Date *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <CalendarDays className="mr-2 h-4 w-4" />
                          {formatDate(invoiceDate)}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={invoiceDate}
                          onSelect={(date) => date && setInvoiceDate(date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                {/* Amount */}
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount to be Paid (₹) *</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="Enter amount"
                    value={paymentData.amount}
                    onChange={(e) => handleInputChange('amount', e.target.value)}
                    className={errors.amount ? 'border-red-500' : ''}
                  />
                  {errors.amount && <p className="text-sm text-red-500">{errors.amount}</p>}
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description">Description / Remarks *</Label>
                  <Textarea
                    id="description"
                    placeholder="e.g., December 2024 Mess Bill"
                    value={paymentData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    className={errors.description ? 'border-red-500' : ''}
                    rows={3}
                  />
                  {errors.description && <p className="text-sm text-red-500">{errors.description}</p>}
                </div>

                {/* Payment Process */}
                <div className="border-t pt-6">
                  <h3 className="text-lg font-medium mb-4">C. Payment Process</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="paymentMethod">Payment Method *</Label>
                      <Select value={paymentData.paymentMethod} onValueChange={(value) => handleInputChange('paymentMethod', value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {paymentMethods.map((method) => (
                            <SelectItem key={method} value={method}>
                              {method}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="transactionId">
                        {paymentData.paymentMethod === 'Cheque' ? 'Cheque Number' : 'Transaction ID'} *
                      </Label>
                      <Input
                        id="transactionId"
                        placeholder={paymentData.paymentMethod === 'Cheque' ? 'Enter cheque number' : 'Enter transaction ID'}
                        value={paymentData.transactionId}
                        onChange={(e) => handleInputChange('transactionId', e.target.value)}
                        className={errors.transactionId ? 'border-red-500' : ''}
                      />
                      {errors.transactionId && <p className="text-sm text-red-500">{errors.transactionId}</p>}
                    </div>
                  </div>

                  <div className="mt-4 space-y-2">
                    <Label>Payment Date *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full md:w-auto justify-start text-left font-normal"
                        >
                          <CalendarDays className="mr-2 h-4 w-4" />
                          {formatDate(paymentDate)}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={paymentDate}
                          onSelect={(date) => date && setPaymentDate(date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowPaymentForm(false);
                      setSelectedVendor(null);
                      setPaymentData({
                        institution: '',
                        invoiceNumber: '',
                        amount: '',
                        description: '',
                        paymentMethod: 'NEFT',
                        transactionId: ''
                      });
                      setErrors({});
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="button"
                    onClick={handleConfirmPayment}
                    disabled={!isFormValid}
                  >
                    Make Payment
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* Vendor Details Dialog */}
      {selectedVendor && showVendorDetails && (
        <Dialog open={showVendorDetails} onOpenChange={setShowVendorDetails}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Vendor Details</DialogTitle>
              <DialogDescription>
                Complete information for {selectedVendor.vendorName}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-medium mb-2">Basic Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><strong>Vendor Name:</strong> {selectedVendor.vendorName}</p>
                    <p><strong>Type:</strong> {selectedVendor.vendorType}</p>
                    <p><strong>Contact Person:</strong> {selectedVendor.contactPersonName}</p>
                  </div>
                  <div>
                    <p><strong>Mobile:</strong> {selectedVendor.mobileNumber}</p>
                    <p><strong>Email:</strong> {selectedVendor.emailId}</p>
                    <p><strong>Payment Due:</strong> {selectedVendor.paymentDueDates}</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-2">Financial Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><strong>PAN:</strong> {selectedVendor.panCardNumber}</p>
                    <p><strong>GSTIN:</strong> {selectedVendor.gstinNumber}</p>
                  </div>
                  <div>
                    <p><strong>Bank:</strong> {selectedVendor.bankName}</p>
                    <p><strong>Account:</strong> {selectedVendor.bankAccountNumber}</p>
                  </div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Payment Confirmation Dialog */}
      {showConfirmDialog && selectedVendor && (
        <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Payment</DialogTitle>
              <DialogDescription>
                Please verify the payment details before proceeding
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-lg">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><strong>Vendor:</strong> {selectedVendor.vendorName}</p>
                    <p><strong>Institution:</strong> {paymentData.institution}</p>
                    <p><strong>Invoice:</strong> {paymentData.invoiceNumber}</p>
                  </div>
                  <div>
                    <p><strong>Amount:</strong> ₹{parseFloat(paymentData.amount || '0').toLocaleString()}</p>
                    <p><strong>Method:</strong> {paymentData.paymentMethod}</p>
                    <p><strong>Transaction ID:</strong> {paymentData.transactionId}</p>
                  </div>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleMakePayment} disabled={isProcessing}>
                {isProcessing ? 'Processing...' : 'Confirm Payment'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Payment History Dialog */}
      {showPaymentHistory && (
        <Dialog open={showPaymentHistory} onOpenChange={setShowPaymentHistory}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Payment History</DialogTitle>
              <DialogDescription>
                All payments made to vendors
              </DialogDescription>
            </DialogHeader>
            
            <div className="overflow-x-auto max-h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Vendor</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {displayPaymentHistory.map((payment) => (
                    <TableRow key={payment.id}>
                      <TableCell>{formatDate(payment.paymentDate)}</TableCell>
                      <TableCell>{payment.vendorName}</TableCell>
                      <TableCell>₹{payment.amount.toLocaleString()}</TableCell>
                      <TableCell>{getStatusBadge(payment.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}