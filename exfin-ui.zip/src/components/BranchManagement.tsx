import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { UserLoginInfo } from './UserLoginInfo';
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  School, 
  GraduationCap, 
  MapPin, 
  Users, 
  Phone, 
  Mail,
  Building2,
  DollarSign,
  TrendingUp,
  ArrowRight,
  Plus
} from 'lucide-react';
import type { Branch, BranchType } from './AuthContext';

interface BranchWithStats extends Branch {
  accountant: {
    name: string;
    email: string;
    phone: string;
  } | null;
  monthlyCollection: number;
  monthlyExpenditure: number;
  studentCount: number;
  status: 'active' | 'inactive';
}

const mockBranches: BranchWithStats[] = [
  // Schools
  {
    id: 'SCH001',
    name: 'Sri Venkateshwara High School',
    type: 'School',
    code: 'SVHS',
    location: 'Hyderabad',
    accountant: {
      name: 'Priya Sharma',
      email: 'priya@sventerprises.edu',
      phone: '+91 9876543210'
    },
    monthlyCollection: 85000,
    monthlyExpenditure: 45000,
    studentCount: 450,
    status: 'active'
  },
  {
    id: 'SCH002',
    name: 'Pragyana Primary School',
    type: 'School',
    code: 'PPS',
    location: 'Secunderabad',
    accountant: {
      name: 'Rajesh Kumar',
      email: 'rajesh@sventerprises.edu',
      phone: '+91 9876543211'
    },
    monthlyCollection: 62000,
    monthlyExpenditure: 38000,
    studentCount: 320,
    status: 'active'
  },
  {
    id: 'SCH003',
    name: 'Sriven Elementary School',
    type: 'School',
    code: 'SES',
    location: 'Kukatpally',
    accountant: {
      name: 'Lakshmi Devi',
      email: 'lakshmi@sventerprises.edu',
      phone: '+91 9876543212'
    },
    monthlyCollection: 58000,
    monthlyExpenditure: 35000,
    studentCount: 290,
    status: 'active'
  },
  {
    id: 'SCH004',
    name: 'Apex International School',
    type: 'School',
    code: 'AIS',
    location: 'Gachibowli',
    accountant: {
      name: 'Venkata Rao',
      email: 'venkat@sventerprises.edu',
      phone: '+91 9876543213'
    },
    monthlyCollection: 125000,
    monthlyExpenditure: 65000,
    studentCount: 580,
    status: 'active'
  },
  {
    id: 'SCH005',
    name: 'Venkateshwara Public School',
    type: 'School',
    code: 'VPS',
    location: 'Madhapur',
    accountant: null,
    monthlyCollection: 95000,
    monthlyExpenditure: 52000,
    studentCount: 425,
    status: 'inactive'
  },
  
  // Colleges (showing first 6 out of 12)
  {
    id: 'COL001',
    name: 'Sri Venkateshwara Engineering College',
    type: 'College',
    code: 'SVEC',
    location: 'Hyderabad',
    accountant: {
      name: 'Dr. Suresh Babu',
      email: 'suresh@sventerprises.edu',
      phone: '+91 9876543214'
    },
    monthlyCollection: 450000,
    monthlyExpenditure: 280000,
    studentCount: 1200,
    status: 'active'
  },
  {
    id: 'COL002',
    name: 'Pragyana Medical College',
    type: 'College',
    code: 'PMC',
    location: 'Secunderabad',
    accountant: {
      name: 'Dr. Anitha Reddy',
      email: 'anitha@sventerprises.edu',
      phone: '+91 9876543215'
    },
    monthlyCollection: 680000,
    monthlyExpenditure: 420000,
    studentCount: 800,
    status: 'active'
  },
  {
    id: 'COL003',
    name: 'Sriven Business School',
    type: 'College',
    code: 'SBS',
    location: 'Kukatpally',
    accountant: {
      name: 'Prof. Ramesh Kumar',
      email: 'ramesh@sventerprises.edu',
      phone: '+91 9876543216'
    },
    monthlyCollection: 350000,
    monthlyExpenditure: 195000,
    studentCount: 600,
    status: 'active'
  },
  {
    id: 'COL004',
    name: 'Apex Law College',
    type: 'College',
    code: 'ALC',
    location: 'Gachibowli',
    accountant: {
      name: 'Advocate Sita Devi',
      email: 'sita@sventerprises.edu',
      phone: '+91 9876543217'
    },
    monthlyCollection: 285000,
    monthlyExpenditure: 165000,
    studentCount: 450,
    status: 'active'
  },
  {
    id: 'COL005',
    name: 'Venkateshwara Arts College',
    type: 'College',
    code: 'VAC',
    location: 'Madhapur',
    accountant: {
      name: 'Prof. Gayatri Sharma',
      email: 'gayatri@sventerprises.edu',
      phone: '+91 9876543218'
    },
    monthlyCollection: 220000,
    monthlyExpenditure: 135000,
    studentCount: 380,
    status: 'active'
  },
  {
    id: 'COL006',
    name: 'Sri Venkateshwara Pharmacy College',
    type: 'College',
    code: 'SVPC',
    location: 'Nizampet',
    accountant: null,
    monthlyCollection: 195000,
    monthlyExpenditure: 125000,
    studentCount: 320,
    status: 'inactive'
  }
];

export function BranchManagement() {
  const [branches] = useState<BranchWithStats[]>(mockBranches);
  const [selectedBranch, setSelectedBranch] = useState<BranchWithStats | null>(null);
  const [activeTab, setActiveTab] = useState('overview');

  const schools = branches.filter(b => b.type === 'School');
  const colleges = branches.filter(b => b.type === 'College');
  
  const totalCollection = branches.reduce((sum, b) => sum + b.monthlyCollection, 0);
  const totalExpenditure = branches.reduce((sum, b) => sum + b.monthlyExpenditure, 0);
  const totalStudents = branches.reduce((sum, b) => sum + b.studentCount, 0);
  const activeBranches = branches.filter(b => b.status === 'active').length;

  const getBranchIcon = (type: BranchType) => {
    return type === 'School' ? School : GraduationCap;
  };

  const getBranchTypeColor = (type: BranchType) => {
    return type === 'School' 
      ? 'bg-blue-100 text-blue-800 border-blue-200'
      : 'bg-purple-100 text-purple-800 border-purple-200';
  };

  if (selectedBranch) {
    const Icon = getBranchIcon(selectedBranch.type);
    
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={() => setSelectedBranch(null)}>
            ← Back to Branches
          </Button>
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${getBranchTypeColor(selectedBranch.type)}`}>
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <h1>{selectedBranch.name}</h1>
              <p className="text-muted-foreground">
                {selectedBranch.code} • {selectedBranch.location}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monthly Collection</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{selectedBranch.monthlyCollection.toLocaleString()}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monthly Expenditure</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{selectedBranch.monthlyExpenditure.toLocaleString()}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Students</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{selectedBranch.studentCount}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Net Balance</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                ₹{(selectedBranch.monthlyCollection - selectedBranch.monthlyExpenditure).toLocaleString()}
              </div>
            </CardContent>
          </Card>
        </div>

        {selectedBranch.accountant && (
          <Card>
            <CardHeader>
              <CardTitle>Assigned Accountant</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                  <Users className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{selectedBranch.accountant.name}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Mail className="w-4 h-4" />
                      {selectedBranch.accountant.email}
                    </span>
                    <span className="flex items-center gap-1">
                      <Phone className="w-4 h-4" />
                      {selectedBranch.accountant.phone}
                    </span>
                  </div>
                </div>
                <Button variant="outline">Contact</Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* User Login Info */}
      <UserLoginInfo className="bg-blue-50 p-3 rounded-lg border border-blue-200" />
      
      <div className="flex items-center justify-between">
        <div>
          <h1>Branch Management</h1>
          <p className="text-muted-foreground">
            Manage all 17 branches across Sri Venkateshwara Enterprises
          </p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Add Branch
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Collection</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totalCollection.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Monthly across all branches</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expenditure</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totalExpenditure.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Monthly operational costs</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStudents.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Across all institutions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Branches</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeBranches}</div>
            <p className="text-xs text-muted-foreground">Out of {branches.length} total</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">All Branches</TabsTrigger>
          <TabsTrigger value="schools">Schools ({schools.length})</TabsTrigger>
          <TabsTrigger value="colleges">Colleges ({colleges.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Branch</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Accountant</TableHead>
                    <TableHead>Students</TableHead>
                    <TableHead>Monthly Collection</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {branches.map(branch => {
                    const Icon = getBranchIcon(branch.type);
                    return (
                      <TableRow key={branch.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className={`p-2 rounded-lg ${getBranchTypeColor(branch.type)}`}>
                              <Icon className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="font-medium">{branch.name}</p>
                              <p className="text-sm text-muted-foreground">{branch.code}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {branch.type}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <MapPin className="w-4 h-4 text-muted-foreground" />
                            {branch.location}
                          </div>
                        </TableCell>
                        <TableCell>
                          {branch.accountant ? (
                            <div>
                              <p className="font-medium">{branch.accountant.name}</p>
                              <p className="text-sm text-muted-foreground">{branch.accountant.phone}</p>
                            </div>
                          ) : (
                            <Badge variant="outline" className="text-orange-600">
                              Not Assigned
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{branch.studentCount}</TableCell>
                        <TableCell>₹{branch.monthlyCollection.toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={branch.status === 'active' 
                              ? 'text-green-600 border-green-200' 
                              : 'text-red-600 border-red-200'
                            }
                          >
                            {branch.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => setSelectedBranch(branch)}
                          >
                            <ArrowRight className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schools">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {schools.map(school => (
              <Card key={school.id} className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setSelectedBranch(school)}>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${getBranchTypeColor(school.type)}`}>
                      <School className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-base">{school.name}</CardTitle>
                      <CardDescription>{school.code} • {school.location}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Students:</span>
                      <span className="font-medium">{school.studentCount}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Monthly Collection:</span>
                      <span className="font-medium">₹{school.monthlyCollection.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Accountant:</span>
                      <span className="font-medium">
                        {school.accountant ? school.accountant.name : 'Not Assigned'}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="colleges">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {colleges.map(college => (
              <Card key={college.id} className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setSelectedBranch(college)}>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${getBranchTypeColor(college.type)}`}>
                      <GraduationCap className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-base">{college.name}</CardTitle>
                      <CardDescription>{college.code} • {college.location}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Students:</span>
                      <span className="font-medium">{college.studentCount}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Monthly Collection:</span>
                      <span className="font-medium">₹{college.monthlyCollection.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Accountant:</span>
                      <span className="font-medium">
                        {college.accountant ? college.accountant.name : 'Not Assigned'}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}