import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Alert, AlertDescription } from "./ui/alert";
import { Badge } from "./ui/badge";
import { Loader2, ArrowLeft, Shield, Building } from 'lucide-react';
import { useAuth } from './AuthContext';
import { toast } from "sonner@2.0.3";

export function OTPVerification() {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [error, setError] = useState('');
  const { verifyOTP, isLoading, pendingCredentials, login } = useAuth();

  const handleOtpChange = (index: number, value: string) => {
    if (value.length <= 1 && /^\d*$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // Auto focus next input
      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-${index + 1}`);
        nextInput?.focus();
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      prevInput?.focus();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const otpString = otp.join('');
    if (otpString.length !== 6) {
      setError('Please enter the complete OTP');
      return;
    }

    try {
      await verifyOTP(otpString);
      toast.success('Login successful!');
    } catch (error) {
      setError('Invalid OTP. Please try again.');
      toast.error('Invalid OTP');
    }
  };

  const handleResendOTP = async () => {
    if (pendingCredentials) {
      try {
        await login(
          pendingCredentials.email || '', 
          pendingCredentials.phone, 
          pendingCredentials.role, 
          pendingCredentials.organization
        );
        toast.success('OTP resent successfully!');
      } catch (error) {
        toast.error('Failed to resend OTP');
      }
    }
  };

  const getRoleDescription = (role: string) => {
    switch (role) {
      case 'Admin': return 'Full system access with organization management';
      case 'Management': return 'View and manage financial reports and analytics';
      case 'Accountant': return 'Create and manage expense transactions';
      case 'Viewer': return 'View-only access to financial data';
      default: return '';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'Admin': return 'bg-red-100 text-red-800';
      case 'Management': return 'bg-blue-100 text-blue-800';
      case 'Accountant': return 'bg-green-100 text-green-800';
      case 'Viewer': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="w-full max-w-md">
        <Card className="shadow-lg">
          <CardHeader className="space-y-1">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => window.location.reload()}
                className="p-1 h-8 w-8"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <CardTitle>Verify OTP</CardTitle>
                <CardDescription>
                  Enter the 6-digit code sent to {pendingCredentials?.email || pendingCredentials?.phone}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Role and Organization Summary */}
            {pendingCredentials && (
              <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-gray-600" />
                    <span className="text-sm font-medium">Role:</span>
                  </div>
                  <Badge className={getRoleColor(pendingCredentials.role || 'Viewer')}>
                    {pendingCredentials.role}
                  </Badge>
                </div>
                {pendingCredentials.role === 'Admin' && pendingCredentials.organization && (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Building className="w-4 h-4 text-gray-600" />
                      <span className="text-sm font-medium">Organization:</span>
                    </div>
                    <span className="text-sm text-gray-700 font-medium">
                      {pendingCredentials.organization}
                    </span>
                  </div>
                )}
                <p className="text-xs text-gray-500">
                  {getRoleDescription(pendingCredentials.role || 'Viewer')}
                </p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* OTP Input */}
              <div className="space-y-2">
                <Label>Enter OTP</Label>
                <div className="flex gap-2 justify-center">
                  {otp.map((digit, index) => (
                    <Input
                      key={index}
                      id={`otp-${index}`}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(index, e.target.value)}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      className="w-12 h-12 text-center text-lg font-semibold"
                      disabled={isLoading}
                    />
                  ))}
                </div>
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button 
                type="submit" 
                className="w-full" 
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  'Verify & Login'
                )}
              </Button>
            </form>

            <div className="text-center space-y-2">
              <p className="text-sm text-gray-500">Didn't receive the code?</p>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleResendOTP}
                disabled={isLoading}
              >
                Resend OTP
              </Button>
            </div>

            <div className="text-center text-xs text-gray-400">
              <p>Use OTP: <span className="font-mono font-semibold">123456</span> for demo</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}