import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Alert, AlertDescription } from "./ui/alert";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "./ui/alert-dialog";
import { 
  ArrowRightLeft, 
  Send, 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertCircle,
  Eye,
  DollarSign,
  User,
  Calendar,
  MessageSquare,
  History,
  TrendingDown,
  TrendingUp,
  RefreshCw,
  Bell,
  FileText,
  Shield
} from 'lucide-react';
import { toast } from "sonner@2.0.3";
import { useAuth } from './AuthContext';

// Cash Transfer interface
export interface CashTransfer {
  id: string;
  fromAccountant: string;
  toAccountant: string;
  amount: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  initiatedDate: Date;
  respondedDate?: Date;
  notes?: string;
  rejectionReason?: string;
  transactionRef: string;
}

// Accountant balance interface
interface AccountantBalance {
  accountantName: string;
  cashInHand: number;
  lastUpdated: Date;
  pendingOutgoing: number;
  pendingIncoming: number;
}

// Mock accountants data
const mockAccountants = [
  { name: 'Manikantha Kumar', branch: 'Main Branch', email: 'manikantha@sriviswa.edu.in' },
  { name: 'Prasad Rao', branch: 'BC-1 Branch', email: 'prasad@sriviswa.edu.in' },
  { name: 'Rajesh Babu', branch: 'DC-1 Branch', email: 'rajesh@sriviswa.edu.in' },
  { name: 'Priya Sharma', branch: 'Sontyam Branch', email: 'priya@sriviswa.edu.in' },
  { name: 'Suresh Kumar', branch: 'Central Office', email: 'suresh@sriviswa.edu.in' }
];

// Mock initial data
const mockBalances: AccountantBalance[] = [
  { accountantName: 'Manikantha Kumar', cashInHand: 25000, lastUpdated: new Date(), pendingOutgoing: 0, pendingIncoming: 0 },
  { accountantName: 'Prasad Rao', cashInHand: 18500, lastUpdated: new Date(), pendingOutgoing: 0, pendingIncoming: 0 },
  { accountantName: 'Rajesh Babu', cashInHand: 22750, lastUpdated: new Date(), pendingOutgoing: 0, pendingIncoming: 0 },
  { accountantName: 'Priya Sharma', cashInHand: 15000, lastUpdated: new Date(), pendingOutgoing: 0, pendingIncoming: 0 },
  { accountantName: 'Suresh Kumar', cashInHand: 30000, lastUpdated: new Date(), pendingOutgoing: 0, pendingIncoming: 0 }
];

const mockTransfers: CashTransfer[] = [
  {
    id: 'CT001',
    fromAccountant: 'Manikantha Kumar',
    toAccountant: 'Prasad Rao',
    amount: 10000,
    reason: 'Urgent bill payment for XYZ vendor',
    status: 'pending',
    initiatedDate: new Date('2024-12-20T10:30:00'),
    transactionRef: 'CT-20241220-001'
  },
  {
    id: 'CT002',
    fromAccountant: 'Rajesh Babu',
    toAccountant: 'Priya Sharma',
    amount: 5000,
    reason: 'Emergency maintenance fund',
    status: 'completed',
    initiatedDate: new Date('2024-12-19T14:20:00'),
    respondedDate: new Date('2024-12-19T14:45:00'),
    transactionRef: 'CT-20241219-002'
  }
];

interface CashHandoverProps {
  onBalanceUpdate?: (accountant: string, newBalance: number) => void;
}

export function CashHandover({ onBalanceUpdate }: CashHandoverProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('initiate');
  const [accountantBalances, setAccountantBalances] = useState<AccountantBalance[]>(mockBalances);
  const [cashTransfers, setCashTransfers] = useState<CashTransfer[]>(mockTransfers);
  const [selectedTransfer, setSelectedTransfer] = useState<CashTransfer | null>(null);
  
  // Form state for initiating transfer
  const [transferForm, setTransferForm] = useState({
    toAccountant: '',
    amount: '',
    reason: '',
    notes: ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Get current user's balance
  const currentUserBalance = accountantBalances.find(b => b.accountantName === user?.name);
  
  // Get available accountants (excluding current user)
  const availableAccountants = mockAccountants.filter(acc => acc.name !== user?.name);
  
  // Get pending incoming transfers for current user
  const pendingIncoming = cashTransfers.filter(t => 
    t.toAccountant === user?.name && t.status === 'pending'
  );
  
  // Get all transfers involving current user
  const userTransfers = cashTransfers.filter(t => 
    t.fromAccountant === user?.name || t.toAccountant === user?.name
  ).sort((a, b) => new Date(b.initiatedDate).getTime() - new Date(a.initiatedDate).getTime());

  // Update pending amounts when transfers change
  useEffect(() => {
    const updatedBalances = accountantBalances.map(balance => {
      const outgoing = cashTransfers
        .filter(t => t.fromAccountant === balance.accountantName && t.status === 'pending')
        .reduce((sum, t) => sum + t.amount, 0);
      
      const incoming = cashTransfers
        .filter(t => t.toAccountant === balance.accountantName && t.status === 'pending')
        .reduce((sum, t) => sum + t.amount, 0);
      
      return {
        ...balance,
        pendingOutgoing: outgoing,
        pendingIncoming: incoming
      };
    });
    
    setAccountantBalances(updatedBalances);
  }, [cashTransfers]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!transferForm.toAccountant) {
      newErrors.toAccountant = 'Please select receiving accountant';
    }
    
    if (!transferForm.amount) {
      newErrors.amount = 'Please enter transfer amount';
    } else {
      const amount = parseFloat(transferForm.amount);
      if (isNaN(amount) || amount <= 0) {
        newErrors.amount = 'Please enter a valid amount';
      } else if (currentUserBalance && amount > currentUserBalance.cashInHand) {
        newErrors.amount = `Insufficient balance. Available: ₹${currentUserBalance.cashInHand.toLocaleString('en-IN')}`;
      }
    }
    
    if (!transferForm.reason.trim()) {
      newErrors.reason = 'Please provide reason for transfer';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (field: string, value: string) => {
    setTransferForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const generateTransactionRef = () => {
    const date = new Date();
    const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
    const timeStr = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `CT-${dateStr}-${timeStr}`;
  };

  const handleInitiateTransfer = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      const transferAmount = parseFloat(transferForm.amount);
      
      const newTransfer: CashTransfer = {
        id: `CT${Date.now()}`,
        fromAccountant: user?.name || '',
        toAccountant: transferForm.toAccountant,
        amount: transferAmount,
        reason: transferForm.reason.trim(),
        status: 'pending',
        initiatedDate: new Date(),
        notes: transferForm.notes.trim() || undefined,
        transactionRef: generateTransactionRef()
      };

      // Add new transfer
      setCashTransfers(prev => [newTransfer, ...prev]);
      
      // Update sender's balance (temporarily reduce by transfer amount)
      setAccountantBalances(prev => prev.map(balance => 
        balance.accountantName === user?.name 
          ? { ...balance, cashInHand: balance.cashInHand - transferAmount, lastUpdated: new Date() }
          : balance
      ));

      // Reset form
      setTransferForm({
        toAccountant: '',
        amount: '',
        reason: '',
        notes: ''
      });

      toast.success(`Cash transfer initiated successfully! Reference: ${newTransfer.transactionRef}`);
      setActiveTab('history');
      
    } catch (error) {
      toast.error('Failed to initiate transfer. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTransferResponse = async (transferId: string, action: 'approve' | 'reject', rejectionReason?: string) => {
    const transfer = cashTransfers.find(t => t.id === transferId);
    if (!transfer) return;

    try {
      if (action === 'approve') {
        // Update transfer status
        setCashTransfers(prev => prev.map(t => 
          t.id === transferId 
            ? { ...t, status: 'completed', respondedDate: new Date() }
            : t
        ));

        // Add amount to receiver's balance
        setAccountantBalances(prev => prev.map(balance => 
          balance.accountantName === transfer.toAccountant 
            ? { ...balance, cashInHand: balance.cashInHand + transfer.amount, lastUpdated: new Date() }
            : balance
        ));

        toast.success(`Cash transfer approved! ₹${transfer.amount.toLocaleString('en-IN')} added to your balance.`);
        
      } else {
        // Update transfer status to rejected
        setCashTransfers(prev => prev.map(t => 
          t.id === transferId 
            ? { ...t, status: 'rejected', respondedDate: new Date(), rejectionReason }
            : t
        ));

        // Restore sender's balance
        setAccountantBalances(prev => prev.map(balance => 
          balance.accountantName === transfer.fromAccountant 
            ? { ...balance, cashInHand: balance.cashInHand + transfer.amount, lastUpdated: new Date() }
            : balance
        ));

        toast.success('Cash transfer rejected. Sender\'s balance has been restored.');
      }
      
    } catch (error) {
      toast.error('Failed to process transfer response. Please try again.');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'rejected': return <XCircle className="w-4 h-4" />;
      default: return null;
    }
  };

  const formatDateTime = (date: Date) => {
    return new Intl.DateTimeFormat('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    }).format(date);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <ArrowRightLeft className="w-6 h-6" />
            Cash Handover System
          </h2>
          <p className="text-muted-foreground">
            Secure and transparent cash transfers between accountants
          </p>
        </div>
        
        {/* Current Balance Card */}
        <Card className="w-80">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Your Cash in Hand</p>
                <div className="text-2xl font-bold">
                  ₹{currentUserBalance?.cashInHand.toLocaleString('en-IN') || '0'}
                </div>
                {currentUserBalance?.pendingOutgoing > 0 && (
                  <p className="text-sm text-red-600">
                    Pending Outgoing: ₹{currentUserBalance.pendingOutgoing.toLocaleString('en-IN')}
                  </p>
                )}
                {currentUserBalance?.pendingIncoming > 0 && (
                  <p className="text-sm text-green-600">
                    Pending Incoming: ₹{currentUserBalance.pendingIncoming.toLocaleString('en-IN')}
                  </p>
                )}
              </div>
              <DollarSign className="w-8 h-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Incoming Notifications */}
      {pendingIncoming.length > 0 && (
        <Alert>
          <Bell className="h-4 w-4" />
          <AlertDescription>
            <strong>You have {pendingIncoming.length} pending cash transfer request(s)!</strong>
            <div className="mt-2 space-y-1">
              {pendingIncoming.map((transfer) => (
                <div key={`notification-${transfer.id}`} className="text-sm">
                  ₹{transfer.amount.toLocaleString('en-IN')} from {transfer.fromAccountant} - {transfer.reason}
                </div>
              ))}
            </div>
          </AlertDescription>
        </Alert>
      )}

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="initiate" className="flex items-center gap-2">
            <Send className="w-4 h-4" />
            Initiate Transfer
          </TabsTrigger>
          <TabsTrigger value="approve" className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            Approve Transfers ({pendingIncoming.length})
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <History className="w-4 h-4" />
            Transfer History
          </TabsTrigger>
          <TabsTrigger value="balances" className="flex items-center gap-2">
            <DollarSign className="w-4 h-4" />
            All Balances
          </TabsTrigger>
        </TabsList>

        {/* Initiate Transfer Tab */}
        <TabsContent value="initiate" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Send className="w-5 h-5" />
                Initiate Cash Transfer
              </CardTitle>
              <CardDescription>
                Transfer cash from your account to another accountant
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="toAccountant">To Accountant *</Label>
                  <Select value={transferForm.toAccountant} onValueChange={(value) => handleInputChange('toAccountant', value)}>
                    <SelectTrigger className={errors.toAccountant ? 'border-red-500' : ''}>
                      <SelectValue placeholder="Select receiving accountant" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableAccountants.map((accountant, index) => (
                        <SelectItem key={`select-accountant-${index}`} value={accountant.name}>
                          <div className="flex flex-col">
                            <span>{accountant.name}</span>
                            <span className="text-sm text-muted-foreground">{accountant.branch}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.toAccountant && <p className="text-sm text-red-500">{errors.toAccountant}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="amount">Transfer Amount (₹) *</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="Enter amount"
                    value={transferForm.amount}
                    onChange={(e) => handleInputChange('amount', e.target.value)}
                    className={errors.amount ? 'border-red-500' : ''}
                  />
                  {errors.amount && <p className="text-sm text-red-500">{errors.amount}</p>}
                  {currentUserBalance && (
                    <p className="text-sm text-muted-foreground">
                      Available balance: ₹{currentUserBalance.cashInHand.toLocaleString('en-IN')}
                    </p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="reason">Reason for Transfer *</Label>
                <Textarea
                  id="reason"
                  placeholder="Brief explanation of why this transfer is needed"
                  value={transferForm.reason}
                  onChange={(e) => handleInputChange('reason', e.target.value)}
                  className={errors.reason ? 'border-red-500' : ''}
                  rows={3}
                />
                {errors.reason && <p className="text-sm text-red-500">{errors.reason}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Additional Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Any additional information or instructions"
                  value={transferForm.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  rows={2}
                />
              </div>

              {/* Transfer Summary */}
              {transferForm.amount && transferForm.toAccountant && (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Transfer Summary:</strong><br />
                    From: {user?.name} → To: {transferForm.toAccountant}<br />
                    Amount: ₹{parseFloat(transferForm.amount || '0').toLocaleString('en-IN')}<br />
                    Your balance after transfer: ₹{((currentUserBalance?.cashInHand || 0) - parseFloat(transferForm.amount || '0')).toLocaleString('en-IN')}
                  </AlertDescription>
                </Alert>
              )}

              <div className="flex justify-end">
                <Button 
                  onClick={handleInitiateTransfer} 
                  disabled={isSubmitting}
                  className="flex items-center gap-2"
                >
                  {isSubmitting ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  {isSubmitting ? 'Processing...' : 'Initiate Transfer'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Approve Transfers Tab */}
        <TabsContent value="approve" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Pending Transfer Approvals
              </CardTitle>
              <CardDescription>
                Review and respond to incoming cash transfer requests
              </CardDescription>
            </CardHeader>
            <CardContent>
              {pendingIncoming.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No pending transfer requests</p>
                  <p className="text-sm">All caught up! New requests will appear here.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingIncoming.map((transfer) => (
                    <Card key={`pending-transfer-${transfer.id}`} className="border-yellow-200 bg-yellow-50">
                      <CardContent className="pt-6">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <User className="w-4 h-4" />
                              <span className="font-medium">From: {transfer.fromAccountant}</span>
                              <Badge className="bg-yellow-100 text-yellow-800">
                                <Clock className="w-3 h-3 mr-1" />
                                Pending
                              </Badge>
                            </div>
                            <div className="space-y-1 text-sm text-muted-foreground">
                              <div className="flex items-center gap-2">
                                <DollarSign className="w-3 h-3" />
                                <span className="font-bold text-lg text-foreground">
                                  ₹{transfer.amount.toLocaleString('en-IN')}
                                </span>
                              </div>
                              <div className="flex items-center gap-2">
                                <MessageSquare className="w-3 h-3" />
                                <span>{transfer.reason}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Calendar className="w-3 h-3" />
                                <span>{formatDateTime(transfer.initiatedDate)}</span>
                              </div>
                              {transfer.notes && (
                                <div className="flex items-center gap-2">
                                  <FileText className="w-3 h-3" />
                                  <span>Notes: {transfer.notes}</span>
                                </div>
                              )}
                              <div className="flex items-center gap-2">
                                <Shield className="w-3 h-3" />
                                <span>Ref: {transfer.transactionRef}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="outline" size="sm" className="text-red-600 border-red-200">
                                  <XCircle className="w-4 h-4 mr-1" />
                                  Reject
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Reject Cash Transfer</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Are you sure you want to reject this transfer of ₹{transfer.amount.toLocaleString('en-IN')} from {transfer.fromAccountant}?
                                    The sender's balance will be restored.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    className="bg-red-600 hover:bg-red-700"
                                    onClick={() => handleTransferResponse(transfer.id, 'reject', 'Rejected by recipient')}
                                  >
                                    Reject Transfer
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                            
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button size="sm" className="bg-green-600 hover:bg-green-700">
                                  <CheckCircle className="w-4 h-4 mr-1" />
                                  Accept
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Accept Cash Transfer</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Confirm that you want to accept ₹{transfer.amount.toLocaleString('en-IN')} from {transfer.fromAccountant}.
                                    This amount will be added to your cash balance.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    className="bg-green-600 hover:bg-green-700"
                                    onClick={() => handleTransferResponse(transfer.id, 'approve')}
                                  >
                                    Accept Transfer
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Transfer History Tab */}
        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="w-5 h-5" />
                Transfer History
              </CardTitle>
              <CardDescription>
                All cash transfers involving your account
              </CardDescription>
            </CardHeader>
            <CardContent>
              {userTransfers.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No transfer history found</p>
                  <p className="text-sm">Your transfer history will appear here</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Reference</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Counterpart</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {userTransfers.map((transfer) => {
                      const isOutgoing = transfer.fromAccountant === user?.name;
                      const counterpart = isOutgoing ? transfer.toAccountant : transfer.fromAccountant;
                      
                      return (
                        <TableRow key={`history-transfer-${transfer.id}`}>
                          <TableCell className="font-mono text-sm">
                            {transfer.transactionRef}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {isOutgoing ? (
                                <>
                                  <TrendingDown className="w-4 h-4 text-red-500" />
                                  <span className="text-red-600">Outgoing</span>
                                </>
                              ) : (
                                <>
                                  <TrendingUp className="w-4 h-4 text-green-500" />
                                  <span className="text-green-600">Incoming</span>
                                </>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{counterpart}</TableCell>
                          <TableCell className="font-bold">
                            ₹{transfer.amount.toLocaleString('en-IN')}
                          </TableCell>
                          <TableCell className="max-w-xs truncate">
                            {transfer.reason}
                          </TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(transfer.status)}>
                              <div className="flex items-center gap-1">
                                {getStatusIcon(transfer.status)}
                                {transfer.status.charAt(0).toUpperCase() + transfer.status.slice(1)}
                              </div>
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <div>{formatDateTime(transfer.initiatedDate)}</div>
                              {transfer.respondedDate && (
                                <div className="text-muted-foreground">
                                  Responded: {formatDateTime(transfer.respondedDate)}
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => setSelectedTransfer(transfer)}
                                >
                                  <Eye className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Transfer Details</DialogTitle>
                                  <DialogDescription>
                                    Complete information about this cash transfer
                                  </DialogDescription>
                                </DialogHeader>
                                {selectedTransfer && (
                                  <div className="space-y-4">
                                    <div className="grid grid-cols-2 gap-4">
                                      <div>
                                        <Label>Reference Number</Label>
                                        <p className="font-mono text-sm">{selectedTransfer.transactionRef}</p>
                                      </div>
                                      <div>
                                        <Label>Status</Label>
                                        <Badge className={getStatusColor(selectedTransfer.status)}>
                                          {selectedTransfer.status.charAt(0).toUpperCase() + selectedTransfer.status.slice(1)}
                                        </Badge>
                                      </div>
                                      <div>
                                        <Label>From</Label>
                                        <p>{selectedTransfer.fromAccountant}</p>
                                      </div>
                                      <div>
                                        <Label>To</Label>
                                        <p>{selectedTransfer.toAccountant}</p>
                                      </div>
                                      <div>
                                        <Label>Amount</Label>
                                        <p className="font-bold text-lg">₹{selectedTransfer.amount.toLocaleString('en-IN')}</p>
                                      </div>
                                      <div>
                                        <Label>Initiated Date</Label>
                                        <p>{formatDateTime(selectedTransfer.initiatedDate)}</p>
                                      </div>
                                    </div>
                                    
                                    <div>
                                      <Label>Reason</Label>
                                      <p>{selectedTransfer.reason}</p>
                                    </div>
                                    
                                    {selectedTransfer.notes && (
                                      <div>
                                        <Label>Additional Notes</Label>
                                        <p>{selectedTransfer.notes}</p>
                                      </div>
                                    )}
                                    
                                    {selectedTransfer.rejectionReason && (
                                      <div>
                                        <Label>Rejection Reason</Label>
                                        <p className="text-red-600">{selectedTransfer.rejectionReason}</p>
                                      </div>
                                    )}
                                    
                                    {selectedTransfer.respondedDate && (
                                      <div>
                                        <Label>Response Date</Label>
                                        <p>{formatDateTime(selectedTransfer.respondedDate)}</p>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </DialogContent>
                            </Dialog>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* All Balances Tab */}
        <TabsContent value="balances" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                All Accountant Balances
              </CardTitle>
              <CardDescription>
                Real-time view of all accountants' cash balances (Read-only)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Accountant</TableHead>
                    <TableHead>Branch</TableHead>
                    <TableHead>Cash in Hand</TableHead>
                    <TableHead>Pending Outgoing</TableHead>
                    <TableHead>Pending Incoming</TableHead>
                    <TableHead>Effective Balance</TableHead>
                    <TableHead>Last Updated</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {accountantBalances.map((balance) => {
                    const accountant = mockAccountants.find(a => a.name === balance.accountantName);
                    const effectiveBalance = balance.cashInHand - balance.pendingOutgoing + balance.pendingIncoming;
                    
                    return (
                      <TableRow key={`balance-${balance.accountantName}`}>
                        <TableCell className="font-medium">
                          {balance.accountantName}
                          {balance.accountantName === user?.name && (
                            <Badge variant="outline" className="ml-2">You</Badge>
                          )}
                        </TableCell>
                        <TableCell>{accountant?.branch || 'N/A'}</TableCell>
                        <TableCell className="font-bold">
                          ₹{balance.cashInHand.toLocaleString('en-IN')}
                        </TableCell>
                        <TableCell className="text-red-600">
                          {balance.pendingOutgoing > 0 ? (
                            `₹${balance.pendingOutgoing.toLocaleString('en-IN')}`
                          ) : (
                            '₹0'
                          )}
                        </TableCell>
                        <TableCell className="text-green-600">
                          {balance.pendingIncoming > 0 ? (
                            `₹${balance.pendingIncoming.toLocaleString('en-IN')}`
                          ) : (
                            '₹0'
                          )}
                        </TableCell>
                        <TableCell className="font-bold">
                          ₹{effectiveBalance.toLocaleString('en-IN')}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {formatDateTime(balance.lastUpdated)}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}