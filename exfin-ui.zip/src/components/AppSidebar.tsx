import image_f68c1a989952b7d595b5240d001cf19fbcd31fed from 'figma:asset/f68c1a989952b7d595b5240d001cf19fbcd31fed.png';
import { 
  Home, Settings, Users, Building, DollarSign, TrendingUp, 
  ArrowDownToLine, ArrowUpFromLine, Receipt, HandCoins, Heart, 
  GraduationCap, BookOpen, Bus, Home as HomeBuilding, ClipboardCheck,
  UserCheck, Banknote, BarChart3, FileText, Clock, CheckCircle
} from "lucide-react";
import { 
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, 
  SidebarGroupContent, SidebarGroupLabel, SidebarHeader, 
  SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarRail 
} from "./ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "./ui/collapsible";
import { ChevronRight } from "lucide-react";
import { useAuth } from './AuthContext';
import { ImageWithFallback } from './figma/ImageWithFallback';

// Restructured menu with 2 main modules
const getMenuStructure = (role: string) => {
  const baseStructure = {
    adminAndBranch: {
      title: "Admin & Branch Management",
      icon: Building,
      items: [] as Array<{ title: string; url: string; icon: any; roles: string[] }>
    },
    financeAndOps: {
      title: "Finance & Operations", 
      icon: DollarSign,
      items: [] as Array<{ title: string; url: string; icon: any; roles: string[] }>
    }
  };

  // Admin & Branch Management Module
  baseStructure.adminAndBranch.items = [
    { title: "Admin Portal", url: "admin", icon: Building, roles: ["Admin"] },
    { title: "Branch Management", url: "branch-management", icon: Building, roles: ["Admin"] },
    { title: "User Management", url: "user-management", icon: Users, roles: ["Admin"] },
    { title: "Vendor Registration", url: "vendor-registration", icon: UserCheck, roles: ["Admin"] },
    { title: "Student Management", url: "student-management", icon: GraduationCap, roles: ["Admin", "Management"] },
    { title: "Staff Management", url: "staff-management", icon: Users, roles: ["Admin", "Management"] },
    { title: "Examination", url: "examination", icon: ClipboardCheck, roles: ["Admin", "Management"] },
    { title: "Library", url: "library", icon: BookOpen, roles: ["Admin", "Management"] },
    { title: "Transport", url: "transport", icon: Bus, roles: ["Admin", "Management"] },
    { title: "Hostel & Mess", url: "hostel-mess", icon: HomeBuilding, roles: ["Admin", "Management"] },
  ];

  // Finance & Operations Module
  baseStructure.financeAndOps.items = [
    { title: "Dashboard", url: "dashboard", icon: Home, roles: ["Accountant", "Management", "Viewer"] },
    { title: "Revenue Entry", url: "revenue-management", icon: ArrowDownToLine, roles: ["Accountant", "Admin", "Management"] },
    { title: "Expenditure Entry", url: "expenditure-management", icon: ArrowUpFromLine, roles: ["Accountant", "Admin", "Management"] },
    { title: "Receipts", url: "receipts", icon: Receipt, roles: ["Accountant", "Admin", "Management"] },
    { title: "Money Request", url: "money-request", icon: HandCoins, roles: ["Accountant", "Admin", "Management"] },
    { title: "Employee Welfare", url: "employee-welfare", icon: Heart, roles: ["Accountant", "Admin", "Management"] },
    { title: "Vendor Payments", url: "vendor-payments", icon: Banknote, roles: ["Admin"] },
    { title: "Analytics", url: "analytics", icon: TrendingUp, roles: ["Accountant", "Management", "Admin"] },
    { title: "All Transactions", url: "transactions", icon: FileText, roles: ["Accountant", "Management", "Viewer"] },
    { title: "Pending Approvals", url: "pending-approvals", icon: Clock, roles: ["Accountant", "Management"] },
    { title: "Balance Tracker", url: "balance-tracker", icon: DollarSign, roles: ["Accountant"] },
  ];

  // Filter based on role
  baseStructure.adminAndBranch.items = baseStructure.adminAndBranch.items.filter(
    item => item.roles.includes(role)
  );
  baseStructure.financeAndOps.items = baseStructure.financeAndOps.items.filter(
    item => item.roles.includes(role)
  );

  return baseStructure;
};

interface AppSidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
}

export function AppSidebar({ activeView, onViewChange }: AppSidebarProps) {
  const { user, logout } = useAuth();
  
  const menuStructure = user ? getMenuStructure(user.role) : null;

  const handleLogout = () => {
    logout();
  };

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <div className="flex items-center gap-2 px-4 py-2">
          <ImageWithFallback 
            src={image_f68c1a989952b7d595b5240d001cf19fbcd31fed}
            alt="Sri Venkateswara Enterprises Logo"
            className="w-8 h-8 object-contain"
          />
          <div className="flex flex-col">
            <span className="text-sidebar-foreground truncate group-data-[collapsible=icon]:hidden">SRIVISWA-2025</span>
            <span className="text-sidebar-foreground/70 truncate group-data-[collapsible=icon]:hidden text-xs">Educational ERP</span>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent>
        {/* Home Dashboard */}
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton 
                  onClick={() => {
                    if (user?.role === 'Admin') onViewChange('admin');
                    else if (user?.role === 'Accountant') onViewChange('accountant-dashboard');
                    else if (user?.role === 'Management') onViewChange('management-dashboard');
                    else onViewChange('dashboard');
                  }}
                  isActive={
                    activeView === 'admin' || 
                    activeView === 'accountant-dashboard' || 
                    activeView === 'management-dashboard' ||
                    activeView === 'dashboard'
                  }
                >
                  <Home />
                  <span>Home Dashboard</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Module 1: Admin & Branch Management */}
        {menuStructure && menuStructure.adminAndBranch.items.length > 0 && (
          <Collapsible defaultOpen className="group/collapsible">
            <SidebarGroup>
              <SidebarGroupLabel asChild>
                <CollapsibleTrigger className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4" />
                    <span>Admin & Branch</span>
                  </div>
                  <ChevronRight className="h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-90" />
                </CollapsibleTrigger>
              </SidebarGroupLabel>
              <CollapsibleContent>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {menuStructure.adminAndBranch.items.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          onClick={() => onViewChange(item.url)}
                          isActive={activeView === item.url}
                        >
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {/* Module 2: Finance & Operations */}
        {menuStructure && menuStructure.financeAndOps.items.length > 0 && (
          <Collapsible defaultOpen className="group/collapsible">
            <SidebarGroup>
              <SidebarGroupLabel asChild>
                <CollapsibleTrigger className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4" />
                    <span>Finance & Operations</span>
                  </div>
                  <ChevronRight className="h-4 w-4 transition-transform group-data-[state=open]/collapsible:rotate-90" />
                </CollapsibleTrigger>
              </SidebarGroupLabel>
              <CollapsibleContent>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {menuStructure.financeAndOps.items.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          onClick={() => onViewChange(item.url)}
                          isActive={activeView === item.url}
                        >
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </CollapsibleContent>
            </SidebarGroup>
          </Collapsible>
        )}

        {/* User Profile Section */}
        {user && (
          <SidebarGroup>
            <SidebarGroupLabel>User Profile</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton className="h-auto py-2">
                    <Avatar className="h-8 w-8 shrink-0">
                      <AvatarImage src={user.profilePicture} alt={user.name} />
                      <AvatarFallback>
                        {user.name?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col items-start min-w-0 flex-1">
                      <span className="truncate w-full" title={user.name}>{user.name}</span>
                      <span className="text-muted-foreground truncate w-full text-xs" title={user.role}>{user.role}</span>
                    </div>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={handleLogout}>
              <Settings />
              <span>Logout</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      
      <SidebarRail />
    </Sidebar>
  );
}
