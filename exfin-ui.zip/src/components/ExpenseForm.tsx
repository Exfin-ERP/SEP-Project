import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Alert, AlertDescription } from "./ui/alert";
import { Badge } from "./ui/badge";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { CalendarDays, Save, X, Building, CreditCard, FileText, User, AlertCircle, Paperclip, Receipt } from 'lucide-react';
import { format } from "date-fns";
import { useAuth } from './AuthContext';
import { toast } from "sonner@2.0.3";

export interface Expense {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: Date;
  notes?: string;
  // Enhanced fields from Excel structure
  campus?: string;
  natureOfWork?: string;
  paymentMode?: string;
  utilityType?: string;
  billStatus?: boolean;
  paymentStatus?: 'Paid' | 'Unpaid' | 'Advance';
  authorizedBy?: string;
  accountantName?: string;
  status?: 'Pending' | 'Approved' | 'Rejected';
  teamAssigned?: string;
  attachment?: File | string;
}

interface ExpenseFormProps {
  expense?: Expense | null;
  categories: string[];
  onSave: (expense: Omit<Expense, 'id'>) => void;
  onCancel: () => void;
}

// Campus options based on actual branch structure
const campusOptions = [
  // Schools (Pragyana Team)
  { value: 'SONTYAM', label: 'Sontyam', type: 'school', team: 'Pragyana Team' },
  { value: 'THAGARAPUVALASA', label: 'Thagarapuvalasa', type: 'school', team: 'Pragyana Team' },
  { value: 'BOYAPALEM', label: 'Boyapalem', type: 'school', team: 'Pragyana Team' },
  { value: 'DAY-SCHOOL', label: 'Day School', type: 'school', team: 'Pragyana Team' },
  
  // Colleges (Sriven Team)
  { value: 'SRIVEN-BC-1', label: 'SRIVEN BC-1', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-BC-2', label: 'SRIVEN BC-2', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-DC-1', label: 'SRIVEN DC-1', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-DC-2', label: 'SRIVEN DC-2', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-GC-1', label: 'SRIVEN GC-1', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-LTG', label: 'SRIVEN LTG', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-LT-SPARK', label: 'SRIVEN LT SPARK', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-BC-4', label: 'SRIVEN BC-4', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-SIVASIVANI', label: 'SRIVEN SIVASIVANI', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-MESS', label: 'SRIVEN MESS', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-BHAVISHYA', label: 'SRIVEN BHAVISHYA', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-GCON', label: 'SRIVEN GCON', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-HAPPY-LIFE', label: 'SRIVEN HAPPY LIFE', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-NETWORK-OFFICE', label: 'SRIVEN NETWORK OFFICE', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-GC4-HOSTEL', label: 'SRIVEN GC4(HOSTEL BLOCK)', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-GC4-CLASS', label: 'SRIVEN GC4(CLASS BLOCK)', type: 'college', team: 'Sriven Team' },
  { value: 'SRIVEN-MAX-BC-6', label: 'SRIVEN MAX(BC-6)', type: 'college', team: 'Sriven Team' },

  // Business & Others
  { value: 'SRI-VENKATESWARA-ENTERPRISES', label: 'SRI VENKATESWARA ENTERPRISES', type: 'business', team: 'Business Team' },
  { value: 'CENTRAL-OFFICE', label: 'CENTRAL OFFICE', type: 'office', team: 'Central Team' },
  { value: 'SSNR-PROJECTS-REVOLT', label: 'SSNR PROJECTS PVT LTD -REVOLT', type: 'project', team: 'Projects Team' },
  { value: 'G-CON-CORP', label: 'G CON CORP', type: 'corporate', team: 'Corporate Team' },
  { value: 'BIJAI-SINGH-BHANSALI-GC-2', label: 'BIJAI SINGH BHANSALI-GC-2', type: 'partner', team: 'Partners Team' }
];

const paymentModes = [
  'CASH', 'CHEQUE', 'ONLINE', 'SWIPE', 'UPI', 'ADVANCE', 'OTHER MODE'
];

const utilityTypes = [
  'MAINTENANCE',
  'MESS EXPENSES', 
  'SALARY PAYABLE',
  'RENTALS',
  'SERVICE VENDOR',
  'STUDENT FEE REFUND',
  'TRAVELLING EXPENSES',
  'OTHER EXPENSES',
  'FIXED ASSET',
  'INTEREST ON LOAN',
  'STATIONARY',
  'WATER EXPENSES',
  'ELECTRICITY EXPENSES',
  'LOANS',
  'RENOVATION',
  'MISCELLANEOUS'
];

const authorizedPersons = [
  'PSN SIR', 'SRIDHAR SIR', 'MANAGEMENT', 'PRINCIPAL', 'DIRECTOR', 'ADMIN'
];

export function ExpenseForm({ expense, categories, onSave, onCancel }: ExpenseFormProps) {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    amount: '',
    category: '',
    description: '',
    notes: '',
    campus: '',
    natureOfWork: '',
    paymentMode: 'CASH',
    utilityType: '',
    billStatus: false,
    paymentStatus: 'Unpaid' as 'Paid' | 'Unpaid' | 'Advance',
    authorizedBy: '',
    accountantName: user?.name || '',
    teamAssigned: ''
  });
  
  const [date, setDate] = useState<Date>(new Date());
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [attachment, setAttachment] = useState<File | null>(null);

  useEffect(() => {
    if (expense) {
      setFormData({
        amount: expense.amount.toString(),
        category: expense.category,
        description: expense.description,
        notes: expense.notes || '',
        campus: expense.campus || '',
        natureOfWork: expense.natureOfWork || '',
        paymentMode: expense.paymentMode || 'CASH',
        utilityType: expense.utilityType || '',
        billStatus: expense.billStatus || false,
        paymentStatus: expense.paymentStatus || 'Unpaid',
        authorizedBy: expense.authorizedBy || '',
        accountantName: expense.accountantName || user?.name || '',
        teamAssigned: expense.teamAssigned || ''
      });
      setDate(new Date(expense.date));
    }
  }, [expense, user?.name]);

  // Auto-assign team based on campus selection
  useEffect(() => {
    const selectedCampus = campusOptions.find(campus => campus.value === formData.campus);
    if (selectedCampus) {
      setFormData(prev => ({
        ...prev,
        teamAssigned: selectedCampus.team
      }));
    }
  }, [formData.campus]);

  const handleAttachmentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setAttachment(e.target.files[0]);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      newErrors.amount = 'Please enter a valid amount';
    }

    if (!formData.campus) {
      newErrors.campus = 'Please select a campus';
    }

    if (!formData.natureOfWork.trim()) {
      newErrors.natureOfWork = 'Please describe the nature of work';
    }

    if (!formData.utilityType) {
      newErrors.utilityType = 'Please select an expense type';
    }

    if (!formData.authorizedBy) {
      newErrors.authorizedBy = 'Please select who authorized this expense';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form');
      return;
    }

    setIsSubmitting(true);

    try {
      const expenseData: Omit<Expense, 'id'> = {
        amount: parseFloat(formData.amount),
        category: formData.utilityType, // Using utilityType as category
        description: formData.natureOfWork,
        date,
        notes: formData.notes,
        campus: formData.campus,
        natureOfWork: formData.natureOfWork,
        paymentMode: formData.paymentMode,
        utilityType: formData.utilityType,
        billStatus: formData.billStatus,
        paymentStatus: formData.paymentStatus,
        authorizedBy: formData.authorizedBy,
        accountantName: formData.accountantName,
        status: 'Pending',
        teamAssigned: formData.teamAssigned,
        attachment: attachment ? attachment.name : undefined
      };

      await onSave(expenseData);
      
      // Show success message with team assignment
      toast.success(`Expenditure booked successfully! Assigned to ${formData.teamAssigned} for approval.`);
      
    } catch (error) {
      toast.error('Failed to save expense. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear error for this field
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const selectedCampus = campusOptions.find(campus => campus.value === formData.campus);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            {expense ? 'Edit Expenditure' : 'Book New Expenditure'}
          </CardTitle>
          <CardDescription>
            Enter all expenditure details carefully. This will be sent to {formData.teamAssigned} for approval.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Campus and Team Assignment */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="campus" className="flex items-center gap-2">
                  <Building className="w-4 h-4" />
                  Campus <span className="text-red-500">*</span>
                </Label>
                <Select 
                  value={formData.campus} 
                  onValueChange={(value) => handleInputChange('campus', value)}
                >
                  <SelectTrigger className={errors.campus ? 'border-red-500' : ''}>
                    <SelectValue placeholder="Select campus" />
                  </SelectTrigger>
                  <SelectContent>
                    <div className="px-2 py-1 text-sm font-medium text-green-600">Schools (Pragyana Team)</div>
                    {campusOptions.filter(c => c.type === 'school').map((campus) => (
                      <SelectItem key={campus.value} value={campus.value}>
                        {campus.label}
                      </SelectItem>
                    ))}
                    <div className="px-2 py-1 text-sm font-medium text-blue-600 mt-2">Colleges (Sriven Team)</div>
                    {campusOptions.filter(c => c.type === 'college').map((campus) => (
                      <SelectItem key={campus.value} value={campus.value}>
                        {campus.label}
                      </SelectItem>
                    ))}
                    <div className="px-2 py-1 text-sm font-medium text-purple-600 mt-2">Business & Others</div>
                    {campusOptions.filter(c => ['business', 'office', 'project', 'corporate', 'partner'].includes(c.type)).map((campus) => (
                      <SelectItem key={campus.value} value={campus.value}>
                        {campus.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.campus && <p className="text-sm text-red-500">{errors.campus}</p>}
              </div>

              {formData.teamAssigned && (
                <div className="space-y-2">
                  <Label>Assigned Team</Label>
                  <div className="p-2 bg-gray-50 rounded-md border">
                    <Badge className={selectedCampus?.type === 'school' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}>
                      {formData.teamAssigned}
                    </Badge>
                  </div>
                </div>
              )}
            </div>

            {/* Nature of Work and Amount */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="natureOfWork">
                  Nature of Work / Description <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="natureOfWork"
                  placeholder="e.g., Purchase of milk packets, Mess van diesel, Salary advance"
                  value={formData.natureOfWork}
                  onChange={(e) => handleInputChange('natureOfWork', e.target.value)}
                  className={errors.natureOfWork ? 'border-red-500' : ''}
                  rows={3}
                />
                {errors.natureOfWork && <p className="text-sm text-red-500">{errors.natureOfWork}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">
                  Amount (₹) <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={formData.amount}
                  onChange={(e) => handleInputChange('amount', e.target.value)}
                  className={errors.amount ? 'border-red-500' : ''}
                />
                {errors.amount && <p className="text-sm text-red-500">{errors.amount}</p>}
                {formData.amount && (
                  <p className="text-sm text-muted-foreground">
                    Amount in words: ₹{parseFloat(formData.amount || '0').toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </p>
                )}
              </div>
            </div>

            {/* Payment Mode and Utility Type */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  Payment Mode
                </Label>
                <Select 
                  value={formData.paymentMode} 
                  onValueChange={(value) => handleInputChange('paymentMode', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentModes.map((mode) => (
                      <SelectItem key={mode} value={mode}>
                        {mode}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="utilityType">
                  Expense Type <span className="text-red-500">*</span>
                </Label>
                <Select 
                  value={formData.utilityType} 
                  onValueChange={(value) => handleInputChange('utilityType', value)}
                >
                  <SelectTrigger className={errors.utilityType ? 'border-red-500' : ''}>
                    <SelectValue placeholder="Select expense type" />
                  </SelectTrigger>
                  <SelectContent>
                    {utilityTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.utilityType && <p className="text-sm text-red-500">{errors.utilityType}</p>}
              </div>
            </div>

            {/* Payment Status and Date */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Payment Status</Label>
                <div className="flex items-center space-x-2">
                  {(['Paid', 'Unpaid', 'Advance'] as const).map((status) => (
                    <button
                      key={status}
                      type="button"
                      onClick={() => handleInputChange('paymentStatus', status)}
                      className={`px-4 py-2 rounded-md border text-sm ${
                        formData.paymentStatus === status
                          ? status === 'Paid' 
                            ? 'bg-green-100 border-green-300 text-green-800'
                            : status === 'Advance'
                            ? 'bg-orange-100 border-orange-300 text-orange-800'
                            : 'bg-red-100 border-red-300 text-red-800'
                          : 'bg-gray-50 border-gray-300'
                      }`}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Transaction Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarDays className="mr-2 h-4 w-4" />
                      {format(date, "dd-MM-yyyy")}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={(date) => date && setDate(date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Authorized By and Attachment */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Authorized By <span className="text-red-500">*</span>
                </Label>
                <Select 
                  value={formData.authorizedBy} 
                  onValueChange={(value) => handleInputChange('authorizedBy', value)}
                >
                  <SelectTrigger className={errors.authorizedBy ? 'border-red-500' : ''}>
                    <SelectValue placeholder="Select authorizing person" />
                  </SelectTrigger>
                  <SelectContent>
                    {authorizedPersons.map((person) => (
                      <SelectItem key={person} value={person}>
                        {person}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.authorizedBy && <p className="text-sm text-red-500">{errors.authorizedBy}</p>}
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Paperclip className="w-4 h-4" />
                  Bill Attachment
                </Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="file"
                    accept="image/*,.pdf,.doc,.docx"
                    onChange={handleAttachmentChange}
                    className="flex-1"
                  />
                  {attachment && (
                    <div className="flex items-center gap-1 text-green-600">
                      <Receipt className="w-4 h-4" />
                      <span className="text-sm">{attachment.name}</span>
                    </div>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Upload bill/receipt (PDF, Image, DOC)
                </p>
              </div>
            </div>

            {/* Bill Status and Notes */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Receipt className="w-4 h-4" />
                  Bill Status
                </Label>
                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    onClick={() => handleInputChange('billStatus', true)}
                    className={`px-4 py-2 rounded-md border ${
                      formData.billStatus 
                        ? 'bg-green-100 border-green-300 text-green-800' 
                        : 'bg-gray-50 border-gray-300'
                    }`}
                  >
                    <Receipt className="w-4 h-4 inline mr-1" />
                    YES - Bill Received
                  </button>
                  <button
                    type="button"
                    onClick={() => handleInputChange('billStatus', false)}
                    className={`px-4 py-2 rounded-md border ${
                      !formData.billStatus 
                        ? 'bg-red-100 border-red-300 text-red-800' 
                        : 'bg-gray-50 border-gray-300'
                    }`}
                  >
                    NO - Bill Pending
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Additional Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Any additional information..."
                  value={formData.notes}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  rows={3}
                />
              </div>
            </div>

            {/* Accountant Information */}
            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium mb-2">Accountant Information</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Accountant Name</Label>
                  <Input 
                    value={formData.accountantName} 
                    disabled 
                    className="bg-gray-100"
                  />
                </div>
                <div>
                  <Label>Entry Status</Label>
                  <Badge className="bg-yellow-100 text-yellow-800">
                    Pending {formData.teamAssigned} Approval
                  </Badge>
                </div>
              </div>
            </div>

            {/* Important Notice */}
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Important:</strong> This expenditure will be sent to <strong>{formData.teamAssigned || 'the appropriate team'}</strong> for approval. Once submitted with payment status <strong>{formData.paymentStatus}</strong>, it will require admin team approval before processing.
              </AlertDescription>
            </Alert>

            {/* Form Actions */}
            <div className="flex items-center gap-4 pt-4">
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="flex items-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    {expense ? 'Update Expenditure' : 'Book Expenditure'}
                  </>
                )}
              </Button>
              
              <Button 
                type="button" 
                variant="outline" 
                onClick={onCancel}
                disabled={isSubmitting}
                className="flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}