import image_f68c1a989952b7d595b5240d001cf19fbcd31fed from 'figma:asset/f68c1a989952b7d595b5240d001cf19fbcd31fed.png';
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  UserPlus, 
  Building2, 
  Users, 
  FileText, 
  TrendingUp,
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  Edit,
  Trash2,
  Download,
  DollarSign,
  AlertCircle
} from 'lucide-react';
import { VendorRegistration, type VendorData } from './VendorRegistration';
import { BranchManagement } from './BranchManagement';
import { AccountantReports } from './AccountantReports';
import { useAuth } from './AuthContext';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { UserLoginInfo } from './UserLoginInfo';

interface AdminDashboardProps {
  onNavigate: (view: string) => void;
}

const mockVendors: VendorData[] = [
  {
    id: '1',
    type: 'electricity',
    name: 'Telangana State Electricity Board',
    contactPerson: 'Rajesh Kumar',
    email: 'rajesh@tseb.gov.in',
    phone: '+91 9876543210',
    address: 'Vidyut Bhavan, Hyderabad, Telangana',
    gstNumber: '36ABCDE1234F1Z5',
    bankDetails: {
      accountNumber: '123456789012',
      ifscCode: 'SBIN0001234',
      bankName: 'State Bank of India',
      accountHolder: 'TSEB Collections'
    },
    services: 'Electricity supply and maintenance for educational institutions',
    status: 'approved',
    registeredDate: new Date('2024-01-15')
  },
  {
    id: '2',
    type: 'rental_owners',
    name: 'Sri Lakshmi Properties',
    contactPerson: 'Venkata Rao',
    email: 'venkat@srilakshmi.com',
    phone: '+91 9876543211',
    address: 'Banjara Hills, Hyderabad, Telangana',
    gstNumber: '36FGHIJ5678K2L3',
    bankDetails: {
      accountNumber: '987654321098',
      ifscCode: 'HDFC0001234',
      bankName: 'HDFC Bank',
      accountHolder: 'Sri Lakshmi Properties'
    },
    services: 'Commercial property rental for educational institutions',
    status: 'pending',
    registeredDate: new Date('2024-01-20')
  },
  {
    id: '3',
    type: 'mess',
    name: 'Annapurna Catering Services',
    contactPerson: 'Sita Devi',
    email: 'sita@annapurna.com',
    phone: '+91 9876543212',
    address: 'Kukatpally, Hyderabad, Telangana',
    bankDetails: {
      accountNumber: '456789123456',
      ifscCode: 'ICIC0001234',
      bankName: 'ICICI Bank',
      accountHolder: 'Annapurna Catering Services'
    },
    services: 'Food catering and mess services for hostels and institutions',
    status: 'rejected',
    registeredDate: new Date('2024-01-18')
  }
];

const branchStats = {
  totalBranches: 17,
  schools: 5,
  colleges: 12,
  totalAccountants: 14,
  adminTeam: 6
};

// Mock balance data for admin team
const balanceData = {
  openingBalance: 2456780.50,
  closingBalance: 2398450.25,
  totalTransactions: 47,
  totalDebits: 127584.75,
  totalCredits: 69254.50
};

// Mock pending approvals from accountants
const mockPendingApprovals = [
  {
    id: '1',
    accountantName: 'Rajesh Kumar',
    campus: 'SRIVEN-MAIN',
    amount: 25000,
    description: 'Mess expenses for December',
    paymentStatus: 'Unpaid',
    teamAssigned: 'Sriven Team',
    date: new Date(),
    attachment: 'bill_001.pdf'
  },
  {
    id: '2',
    accountantName: 'Priya Sharma',
    campus: 'PRAGYANA-A1',
    amount: 15000,
    description: 'Electricity bill payment',
    paymentStatus: 'Paid',
    teamAssigned: 'Pragyana Team',
    date: new Date(),
    attachment: 'electricity_bill.pdf'
  }
];

export function AdminDashboard({ onNavigate }: AdminDashboardProps) {
  const { user } = useAuth();
  const [showRegistration, setShowRegistration] = useState(false);
  const [showBranchManagement, setShowBranchManagement] = useState(false);
  const [vendors, setVendors] = useState<VendorData[]>(mockVendors);
  const [activeTab, setActiveTab] = useState('overview');

  const handleVendorRegistrationComplete = (vendor: VendorData) => {
    setVendors(prev => [...prev, vendor]);
    setShowRegistration(false);
  };

  const handleApproveVendor = (vendorId: string) => {
    setVendors(prev => prev.map(vendor => 
      vendor.id === vendorId 
        ? { ...vendor, status: 'approved' as const }
        : vendor
    ));
  };

  const handleRejectVendor = (vendorId: string) => {
    setVendors(prev => prev.map(vendor => 
      vendor.id === vendorId 
        ? { ...vendor, status: 'rejected' as const }
        : vendor
    ));
  };

  const getStatusBadge = (status: VendorData['status']) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
    }
  };

  const getVendorTypeLabel = (type: VendorData['type']) => {
    const labels = {
      vendors: 'General Vendor',
      rental_owners: 'Rental Owner',
      electricity: 'Electricity',
      salaries: 'Salary Management',
      mess: 'Mess & Catering',
      transport: 'Transportation',
      supplies: 'Office Supplies',
      maintenance: 'Maintenance'
    };
    return labels[type];
  };

  if (showRegistration) {
    return (
      <VendorRegistration
        onClose={() => setShowRegistration(false)}
        onComplete={handleVendorRegistrationComplete}
      />
    );
  }

  if (showBranchManagement) {
    return <BranchManagement />;
  }

  return (
    <div className="space-y-6">
      {/* User Login Info */}
      <UserLoginInfo className="bg-blue-50 p-3 rounded-lg border border-blue-200" />
      
      {/* Admin Profile Header */}
      <div className="flex items-center justify-between p-6 rounded-lg border">
        <div className="flex items-center gap-4">
          <div className="relative">
            <ImageWithFallback
              src={image_f68c1a989952b7d595b5240d001cf19fbcd31fed}
              alt="Admin Profile"
              className="w-16 h-16 rounded-full object-cover border-2 border-blue-200 rounded-[15px]"
            />
            <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-white"></div>
          </div>
          <div>
            <h1 className="text-xl font-semibold text-blue-800">Welcome, {user?.name || 'Admin'}</h1>
            <p className="text-blue-600">Sri Venkateswara Enterprises - Admin Portal</p>
            {user?.organization && (
              <p className="text-sm text-blue-500">
                Organization: {user.organization}
              </p>
            )}
          </div>
        </div>
        
        {/* Balance Summary for Admin */}
        <div className="flex gap-4">
          <Card className="min-w-[150px]">
            <CardContent className="p-3">
              <div className="text-xs text-muted-foreground">Opening Balance</div>
              <div className="text-lg font-semibold text-green-600">
                ₹{balanceData.openingBalance.toLocaleString('en-IN')}
              </div>
            </CardContent>
          </Card>
          <Card className="min-w-[150px]">
            <CardContent className="p-3">
              <div className="text-xs text-muted-foreground">Closing Balance</div>
              <div className="text-lg font-semibold text-blue-600">
                ₹{balanceData.closingBalance.toLocaleString('en-IN')}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="approvals">Pending Approvals</TabsTrigger>
          <TabsTrigger value="vendors">Vendor Management</TabsTrigger>
          <TabsTrigger value="branches">Branch Management</TabsTrigger>
          <TabsTrigger value="accountant-reports">Accountant Reports</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Balance Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Financial Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    ₹{balanceData.openingBalance.toLocaleString('en-IN')}
                  </div>
                  <div className="text-sm text-green-700">Opening Balance</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    ₹{balanceData.closingBalance.toLocaleString('en-IN')}
                  </div>
                  <div className="text-sm text-blue-700">Closing Balance</div>
                </div>
                <div className="text-center p-4 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">
                    ₹{balanceData.totalDebits.toLocaleString('en-IN')}
                  </div>
                  <div className="text-sm text-red-700">Total Debits</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">
                    ₹{balanceData.totalCredits.toLocaleString('en-IN')}
                  </div>
                  <div className="text-sm text-orange-700">Total Credits</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Main Registration Card */}
          <Card className="border-2 border-primary/20 bg-gradient-to-r from-primary/5 to-primary/10">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <div className="p-4 rounded-full bg-primary/10">
                  <UserPlus className="w-12 h-12 text-primary" />
                </div>
              </div>
              <CardTitle className="text-2xl">Vendor Registration Portal</CardTitle>
              <CardDescription className="text-base">
                Register new vendors, suppliers, and service providers for Sri Venkateswara Enterprises
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <Button 
                size="lg" 
                onClick={() => setShowRegistration(true)}
                className="px-8 py-3"
              >
                <UserPlus className="w-5 h-5 mr-2" />
                Start Registration Process
              </Button>
            </CardContent>
          </Card>

          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Branches</CardTitle>
                <Building2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{branchStats.totalBranches}</div>
                <p className="text-xs text-muted-foreground">
                  {branchStats.schools} Schools • {branchStats.colleges} Colleges
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Vendors</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {vendors.filter(v => v.status === 'approved').length}
                </div>
                <p className="text-xs text-muted-foreground">
                  {vendors.filter(v => v.status === 'pending').length} pending approval
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Accountants</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{branchStats.totalAccountants}</div>
                <p className="text-xs text-muted-foreground">
                  Branch accountants + {branchStats.adminTeam} admin team
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Recent Vendor Registrations */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Vendor Registrations</CardTitle>
              <CardDescription>Latest vendor registration requests</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {vendors.slice(0, 3).map(vendor => (
                  <div key={vendor.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                        <Building2 className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-medium">{vendor.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {getVendorTypeLabel(vendor.type)} • {vendor.contactPerson}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(vendor.status)}
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="approvals" className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2>Pending Approvals</h2>
              <p className="text-muted-foreground">Expenditure requests from accountants awaiting approval</p>
            </div>
            <Badge className="bg-orange-100 text-orange-800">
              <AlertCircle className="w-3 h-3 mr-1" />
              {mockPendingApprovals.length} Pending
            </Badge>
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Accountant</TableHead>
                    <TableHead>Campus / Team</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Payment Status</TableHead>
                    <TableHead>Attachment</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockPendingApprovals.map(approval => (
                    <TableRow key={approval.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{approval.accountantName}</p>
                          <p className="text-sm text-muted-foreground">
                            {approval.date.toLocaleDateString()}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm">{approval.campus}</p>
                          <Badge variant="outline" className="text-xs">
                            {approval.teamAssigned}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell className="max-w-[200px]">
                        <p className="text-sm truncate">{approval.description}</p>
                      </TableCell>
                      <TableCell>
                        <span className="font-medium">
                          ₹{approval.amount.toLocaleString('en-IN')}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          approval.paymentStatus === 'Paid' 
                            ? 'bg-green-100 text-green-800'
                            : approval.paymentStatus === 'Advance'
                            ? 'bg-orange-100 text-orange-800'
                            : 'bg-red-100 text-red-800'
                        }>
                          {approval.paymentStatus}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {approval.attachment && (
                          <Button variant="outline" size="sm">
                            <FileText className="w-4 h-4 mr-1" />
                            View
                          </Button>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="text-green-600 hover:text-green-700"
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="text-red-600 hover:text-red-700"
                          >
                            <XCircle className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="vendors" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2>Vendor Management</h2>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button onClick={() => setShowRegistration(true)}>
                <UserPlus className="w-4 h-4 mr-2" />
                Add Vendor
              </Button>
            </div>
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vendor Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Registered</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vendors.map(vendor => (
                    <TableRow key={vendor.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{vendor.name}</p>
                          <p className="text-sm text-muted-foreground">{vendor.contactPerson}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {getVendorTypeLabel(vendor.type)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm">{vendor.phone}</p>
                          <p className="text-sm text-muted-foreground">{vendor.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(vendor.status)}</TableCell>
                      <TableCell>
                        {vendor.registeredDate.toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          {vendor.status === 'pending' && (
                            <>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleApproveVendor(vendor.id)}
                              >
                                <CheckCircle className="w-4 h-4 text-green-600" />
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleRejectVendor(vendor.id)}
                              >
                                <XCircle className="w-4 h-4 text-red-600" />
                              </Button>
                            </>
                          )}
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="branches" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2>Branch Management</h2>
            <Button onClick={() => setShowBranchManagement(true)}>
              <Building2 className="w-4 h-4 mr-2" />
              Manage Branches
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => setShowBranchManagement(true)}>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-blue-600" />
                  Schools (5)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Primary and secondary education branches
                </p>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Total Students:</span>
                    <span className="font-medium">2,065</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Monthly Collection:</span>
                    <span className="font-medium">₹4,25,000</span>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-3 w-full">
                  View All Schools
                </Button>
              </CardContent>
            </Card>
            
            <Card className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => setShowBranchManagement(true)}>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-purple-600" />
                  Colleges (12)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Higher education and professional colleges
                </p>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Total Students:</span>
                    <span className="font-medium">8,750</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Monthly Collection:</span>
                    <span className="font-medium">₹32,80,000</span>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-3 w-full">
                  View All Colleges
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="w-5 h-5 text-green-600" />
                  Accountants (14)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Branch accountants managing finances
                </p>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Assigned:</span>
                    <span className="font-medium">12</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Unassigned:</span>
                    <span className="font-medium text-orange-600">2</span>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="mt-3 w-full">
                  Manage Assignments
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="accountant-reports">
          <AccountantReports />
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <h2>Reports & Analytics</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Daily Summary Report</CardTitle>
                <CardDescription>Generate daily financial summary</CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={() => onNavigate('reports')}>
                  <FileText className="w-4 h-4 mr-2" />
                  Generate Report
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Vendor Analytics</CardTitle>
                <CardDescription>Vendor performance and analytics</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  View Analytics
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}