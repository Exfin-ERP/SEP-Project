import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Badge } from "./ui/badge";
import { Textarea } from "./ui/textarea";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { toast } from "sonner@2.0.3";
import { 
  DollarSign, 
  GraduationCap, 
  FileText, 
  Utensils, 
  Gift, 
  TrendingUp,
  CalendarIcon,
  Download,
  Search,
  Filter,
  Plus
} from 'lucide-react';
import { format } from 'date-fns';
import { UserLoginInfo } from './UserLoginInfo';

interface RevenueEntry {
  id: string;
  type: 'Student Fee' | 'Examination Fee' | 'Mess Fee' | 'Institution Fee' | 'Donation/Grant' | 'Other Income';
  studentId?: string;
  studentName?: string;
  class?: string;
  feeType?: string;
  amount: number;
  date: Date;
  paymentMode: 'Cash' | 'Online' | 'Cheque' | 'DD' | 'UPI';
  receiptNo: string;
  status: 'Paid' | 'Pending' | 'Partial';
  description: string;
  academicYear: string;
  month?: string;
  donorName?: string;
  purpose?: string;
  gstNumber?: string;
  remarks?: string;
}

export function RevenueManagement() {
  const [activeTab, setActiveTab] = useState('add');
  const [revenues, setRevenues] = useState<RevenueEntry[]>([]);
  const [formData, setFormData] = useState<Partial<RevenueEntry>>({
    type: 'Student Fee',
    date: new Date(),
    paymentMode: 'Cash',
    status: 'Paid',
    academicYear: '2024-25'
  });
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [searchTerm, setSearchTerm] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.amount || !formData.receiptNo || !formData.description) {
      toast.error('Please fill all required fields');
      return;
    }

    const newRevenue: RevenueEntry = {
      id: `REV${Date.now()}`,
      type: formData.type as RevenueEntry['type'],
      studentId: formData.studentId,
      studentName: formData.studentName,
      class: formData.class,
      feeType: formData.feeType,
      amount: Number(formData.amount),
      date: selectedDate || new Date(),
      paymentMode: formData.paymentMode as RevenueEntry['paymentMode'],
      receiptNo: formData.receiptNo,
      status: formData.status as RevenueEntry['status'],
      description: formData.description,
      academicYear: formData.academicYear || '2024-25',
      month: formData.month,
      donorName: formData.donorName,
      purpose: formData.purpose,
      gstNumber: formData.gstNumber,
      remarks: formData.remarks
    };

    setRevenues([newRevenue, ...revenues]);
    toast.success(`Revenue entry added successfully - Receipt #${newRevenue.receiptNo}`);
    
    // Reset form
    setFormData({
      type: 'Student Fee',
      date: new Date(),
      paymentMode: 'Cash',
      status: 'Paid',
      academicYear: '2024-25'
    });
    setSelectedDate(new Date());
  };

  const filteredRevenues = revenues.filter(rev => 
    rev.studentName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    rev.receiptNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    rev.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalRevenue = revenues.reduce((sum, rev) => sum + rev.amount, 0);
  const monthlyRevenue = revenues
    .filter(rev => {
      const revDate = new Date(rev.date);
      const now = new Date();
      return revDate.getMonth() === now.getMonth() && revDate.getFullYear() === now.getFullYear();
    })
    .reduce((sum, rev) => sum + rev.amount, 0);

  const renderFormFields = () => {
    switch (formData.type) {
      case 'Student Fee':
      case 'Examination Fee':
      case 'Mess Fee':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="studentId">Student ID *</Label>
                <Input
                  id="studentId"
                  value={formData.studentId || ''}
                  onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                  placeholder="Enter student ID"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="studentName">Student Name *</Label>
                <Input
                  id="studentName"
                  value={formData.studentName || ''}
                  onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                  placeholder="Enter student name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="class">Class/Course *</Label>
                <Select value={formData.class} onValueChange={(value) => setFormData({ ...formData, class: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Class 1">Class 1</SelectItem>
                    <SelectItem value="Class 2">Class 2</SelectItem>
                    <SelectItem value="Class 3">Class 3</SelectItem>
                    <SelectItem value="Class 4">Class 4</SelectItem>
                    <SelectItem value="Class 5">Class 5</SelectItem>
                    <SelectItem value="Class 6">Class 6</SelectItem>
                    <SelectItem value="Class 7">Class 7</SelectItem>
                    <SelectItem value="Class 8">Class 8</SelectItem>
                    <SelectItem value="Class 9">Class 9</SelectItem>
                    <SelectItem value="Class 10">Class 10</SelectItem>
                    <SelectItem value="B.Tech">B.Tech</SelectItem>
                    <SelectItem value="MBA">MBA</SelectItem>
                    <SelectItem value="Pharmacy">Pharmacy</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="feeType">Fee Type *</Label>
                <Select value={formData.feeType} onValueChange={(value) => setFormData({ ...formData, feeType: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select fee type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Tuition Fee">Tuition Fee</SelectItem>
                    <SelectItem value="Admission Fee">Admission Fee</SelectItem>
                    <SelectItem value="Library Fee">Library Fee</SelectItem>
                    <SelectItem value="Lab Fee">Lab Fee</SelectItem>
                    <SelectItem value="Transport Fee">Transport Fee</SelectItem>
                    <SelectItem value="Sports Fee">Sports Fee</SelectItem>
                    <SelectItem value="Annual Fee">Annual Fee</SelectItem>
                    <SelectItem value="Exam Fee">Exam Fee</SelectItem>
                    <SelectItem value="Mess Fee">Mess Fee</SelectItem>
                    <SelectItem value="Hostel Fee">Hostel Fee</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {formData.type === 'Mess Fee' && (
                <div className="space-y-2">
                  <Label htmlFor="month">Month</Label>
                  <Select value={formData.month} onValueChange={(value) => setFormData({ ...formData, month: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select month" />
                    </SelectTrigger>
                    <SelectContent>
                      {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(month => (
                        <SelectItem key={month} value={month}>{month}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </>
        );

      case 'Donation/Grant':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="donorName">Donor Name *</Label>
                <Input
                  id="donorName"
                  value={formData.donorName || ''}
                  onChange={(e) => setFormData({ ...formData, donorName: e.target.value })}
                  placeholder="Enter donor name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="purpose">Purpose *</Label>
                <Input
                  id="purpose"
                  value={formData.purpose || ''}
                  onChange={(e) => setFormData({ ...formData, purpose: e.target.value })}
                  placeholder="Purpose of donation"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gstNumber">GST Number (Optional)</Label>
                <Input
                  id="gstNumber"
                  value={formData.gstNumber || ''}
                  onChange={(e) => setFormData({ ...formData, gstNumber: e.target.value })}
                  placeholder="Enter GST number"
                />
              </div>
            </div>
          </>
        );

      case 'Other Income':
        return (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="purpose">Income Source *</Label>
                <Select value={formData.purpose} onValueChange={(value) => setFormData({ ...formData, purpose: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select income source" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Rental Income">Rental Income</SelectItem>
                    <SelectItem value="Event Income">Event Income</SelectItem>
                    <SelectItem value="Sponsorship">Sponsorship</SelectItem>
                    <SelectItem value="Canteen">Canteen</SelectItem>
                    <SelectItem value="Stationery">Stationery Sales</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">₹{totalRevenue.toLocaleString('en-IN')}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">This Month</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">₹{monthlyRevenue.toLocaleString('en-IN')}</div>
            <p className="text-xs text-muted-foreground">{format(new Date(), 'MMMM yyyy')}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Entries</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{revenues.length}</div>
            <p className="text-xs text-muted-foreground">Revenue records</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Card>
        <CardHeader>
          <CardTitle>Revenue Management</CardTitle>
          <CardDescription>Track all incoming funds including fees, donations, and other income</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="add">
                <Plus className="w-4 h-4 mr-2" />
                Add Revenue
              </TabsTrigger>
              <TabsTrigger value="list">
                <FileText className="w-4 h-4 mr-2" />
                View Records
              </TabsTrigger>
            </TabsList>

            <TabsContent value="add" className="space-y-4">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Basic Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Revenue Type *</Label>
                    <Select value={formData.type} onValueChange={(value: RevenueEntry['type']) => setFormData({ ...formData, type: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select revenue type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Student Fee">
                          <div className="flex items-center gap-2">
                            <GraduationCap className="w-4 h-4" />
                            Student Fee
                          </div>
                        </SelectItem>
                        <SelectItem value="Examination Fee">
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4" />
                            Examination Fee
                          </div>
                        </SelectItem>
                        <SelectItem value="Mess Fee">
                          <div className="flex items-center gap-2">
                            <Utensils className="w-4 h-4" />
                            Mess Fee
                          </div>
                        </SelectItem>
                        <SelectItem value="Institution Fee">Institution Fee</SelectItem>
                        <SelectItem value="Donation/Grant">
                          <div className="flex items-center gap-2">
                            <Gift className="w-4 h-4" />
                            Donation/Grant
                          </div>
                        </SelectItem>
                        <SelectItem value="Other Income">Other Income</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="academicYear">Academic Year *</Label>
                    <Select value={formData.academicYear} onValueChange={(value) => setFormData({ ...formData, academicYear: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select academic year" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2023-24">2023-24</SelectItem>
                        <SelectItem value="2024-25">2024-25</SelectItem>
                        <SelectItem value="2025-26">2025-26</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Dynamic Fields Based on Type */}
                {renderFormFields()}

                {/* Payment Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (₹) *</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={formData.amount || ''}
                      onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) })}
                      placeholder="Enter amount"
                      min="0"
                      step="0.01"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="receiptNo">Receipt Number *</Label>
                    <Input
                      id="receiptNo"
                      value={formData.receiptNo || ''}
                      onChange={(e) => setFormData({ ...formData, receiptNo: e.target.value })}
                      placeholder="Enter receipt number"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="paymentMode">Payment Mode *</Label>
                    <Select value={formData.paymentMode} onValueChange={(value: RevenueEntry['paymentMode']) => setFormData({ ...formData, paymentMode: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select payment mode" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Cash">Cash</SelectItem>
                        <SelectItem value="Online">Online Transfer</SelectItem>
                        <SelectItem value="Cheque">Cheque</SelectItem>
                        <SelectItem value="DD">Demand Draft</SelectItem>
                        <SelectItem value="UPI">UPI</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="status">Payment Status *</Label>
                    <Select value={formData.status} onValueChange={(value: RevenueEntry['status']) => setFormData({ ...formData, status: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Paid">Paid</SelectItem>
                        <SelectItem value="Pending">Pending</SelectItem>
                        <SelectItem value="Partial">Partial Payment</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Date *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={setSelectedDate}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    value={formData.description || ''}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Enter payment description or notes"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="remarks">Remarks (Optional)</Label>
                  <Textarea
                    id="remarks"
                    value={formData.remarks || ''}
                    onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                    placeholder="Additional remarks"
                    rows={2}
                  />
                </div>

                <div className="flex gap-4">
                  <Button type="submit" className="flex-1">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Revenue Entry
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setFormData({
                        type: 'Student Fee',
                        date: new Date(),
                        paymentMode: 'Cash',
                        status: 'Paid',
                        academicYear: '2024-25'
                      });
                      setSelectedDate(new Date());
                    }}
                  >
                    Reset
                  </Button>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="list" className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by student name, receipt number..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  Filter
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Receipt No</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Student/Source</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Payment Mode</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRevenues.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground">
                          No revenue records found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredRevenues.map((revenue) => (
                        <TableRow key={revenue.id}>
                          <TableCell>{revenue.receiptNo}</TableCell>
                          <TableCell>{format(revenue.date, 'dd/MM/yyyy')}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{revenue.type}</Badge>
                          </TableCell>
                          <TableCell>
                            {revenue.studentName || revenue.donorName || revenue.purpose || '-'}
                          </TableCell>
                          <TableCell>₹{revenue.amount.toLocaleString('en-IN')}</TableCell>
                          <TableCell>{revenue.paymentMode}</TableCell>
                          <TableCell>
                            <Badge variant={
                              revenue.status === 'Paid' ? 'default' :
                              revenue.status === 'Pending' ? 'destructive' :
                              'secondary'
                            }>
                              {revenue.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
