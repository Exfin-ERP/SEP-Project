import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { CalendarDays, Plus, DollarSign, TrendingUp, TrendingDown, Receipt, Clock, CheckCircle, XCircle, FileText, Calculator, BookOpen, ArrowRightLeft } from 'lucide-react';
import { useAuth } from './AuthContext';
import { DailyTransactionEntry } from './DailyTransactionEntry';
import { CashHandover } from './CashHandover';
import { UserLoginInfo } from './UserLoginInfo';

interface AccountantDashboardProps {
  onNavigate: (view: string) => void;
  expenses: any[];
  onAddExpense: () => void;
}

export function AccountantDashboard({ onNavigate, expenses, onAddExpense }: AccountantDashboardProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  
  // Mock data for accountant balances - in real app, this would come from backend
  const [accountantData] = useState({
    openingBalance: 25000.00,
    currentBalance: 22350.75,
    totalExpenditure: 2649.25,
    pendingApprovals: 5,
    approvedTransactions: 18,
    rejectedTransactions: 1
  });

  // Get last 10 transactions for this accountant
  const recentTransactions = useMemo(() => {
    return expenses
      .filter(expense => expense.accountantName === user?.name)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 10);
  }, [expenses, user?.name]);

  const balanceChange = accountantData.currentBalance - accountantData.openingBalance;
  const isPositiveChange = balanceChange >= 0;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Approved': return 'bg-green-100 text-green-800';
      case 'Pending': return 'bg-yellow-100 text-yellow-800';
      case 'Rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Approved': return <CheckCircle className="w-3 h-3" />;
      case 'Pending': return <Clock className="w-3 h-3" />;
      case 'Rejected': return <XCircle className="w-3 h-3" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* User Login Info */}
      <UserLoginInfo className="bg-blue-50 p-3 rounded-lg border border-blue-200" />
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Accountant Dashboard</h2>
          <p className="text-muted-foreground">Welcome back, {user?.name}</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={onAddExpense} variant="outline" className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Book Expenditure
          </Button>
          <Button onClick={() => setActiveTab('cash-handover')} variant="outline" className="flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4" />
            Cash Handover
          </Button>
          <Button onClick={() => setActiveTab('daily-entry')} className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Daily Transaction Entry
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="daily-entry">Daily Entry</TabsTrigger>
          <TabsTrigger value="cash-handover">Cash Handover</TabsTrigger>
          <TabsTrigger value="balance-tracker">Balance Tracker</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">

      {/* Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Opening Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{accountantData.openingBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
            <p className="text-xs text-muted-foreground">Monthly starting amount</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{accountantData.currentBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
            <div className={`flex items-center text-xs ${isPositiveChange ? 'text-green-600' : 'text-red-600'}`}>
              {isPositiveChange ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
              {isPositiveChange ? '+' : ''}₹{Math.abs(balanceChange).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expenditure</CardTitle>
            <Receipt className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{accountantData.totalExpenditure.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{accountantData.pendingApprovals}</div>
            <p className="text-xs text-muted-foreground">Awaiting management approval</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={onAddExpense}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5" />
              Book New Expenditure
            </CardTitle>
            <CardDescription>Record a new expense transaction</CardDescription>
          </CardHeader>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('cash-handover')}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ArrowRightLeft className="w-5 h-5" />
              Cash Handover
            </CardTitle>
            <CardDescription>Transfer cash between accountants</CardDescription>
          </CardHeader>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onNavigate('transactions')}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Receipt className="w-5 h-5" />
              View All Transactions
            </CardTitle>
            <CardDescription>Browse all expenditure records</CardDescription>
          </CardHeader>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onNavigate('analytics')}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Expenditure Analytics
            </CardTitle>
            <CardDescription>View spending patterns and reports</CardDescription>
          </CardHeader>
        </Card>
      </div>

      {/* Recent Transactions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarDays className="w-5 h-5" />
            Last 10 Transactions
          </CardTitle>
          <CardDescription>Your recent expenditure entries</CardDescription>
        </CardHeader>
        <CardContent>
          {recentTransactions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Receipt className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No recent transactions found</p>
              <Button onClick={onAddExpense} variant="outline" className="mt-4">
                Book Your First Expenditure
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {recentTransactions.map((transaction, index) => (
                <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium">{transaction.description || transaction.natureOfWork}</p>
                      <Badge className={getStatusColor(transaction.status || 'Pending')}>
                        <div className="flex items-center gap-1">
                          {getStatusIcon(transaction.status || 'Pending')}
                          {transaction.status || 'Pending'}
                        </div>
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>{transaction.campus || 'N/A'}</span>
                      <span>{transaction.utilityType || transaction.category}</span>
                      <span>{transaction.paymentMode || 'Cash'}</span>
                      <span>{new Date(transaction.date).toLocaleDateString('en-IN')}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-lg">₹{transaction.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</p>
                    <p className="text-xs text-muted-foreground">{transaction.billStatus ? 'Bill Submitted' : 'Bill Pending'}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transaction Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600">Approved Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{accountantData.approvedTransactions}</div>
            <p className="text-sm text-muted-foreground">Ready for printing</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-yellow-600">Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-600">{accountantData.pendingApprovals}</div>
            <p className="text-sm text-muted-foreground">Awaiting management review</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-red-600">Rejected Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-600">{accountantData.rejectedTransactions}</div>
            <p className="text-sm text-muted-foreground">Need revision</p>
          </CardContent>
        </Card>
      </div>
        </TabsContent>

        <TabsContent value="daily-entry">
          <DailyTransactionEntry />
        </TabsContent>

        <TabsContent value="cash-handover">
          <CashHandover />
        </TabsContent>

        <TabsContent value="balance-tracker" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="w-5 h-5" />
                Balance Tracker
              </CardTitle>
              <CardDescription>Track your daily opening and closing balances</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                <Calculator className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Balance tracking feature coming soon...</p>
                <p className="text-sm">This will show historical balance data and trends</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                Accountant Reports
              </CardTitle>
              <CardDescription>Generate and view various financial reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Daily Transaction Report</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-3">
                      Detailed report of all daily transactions
                    </p>
                    <Button variant="outline" size="sm" className="w-full">
                      Generate Report
                    </Button>
                  </CardContent>
                </Card>

                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Monthly Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-3">
                      Monthly collection and expenditure summary
                    </p>
                    <Button variant="outline" size="sm" className="w-full">
                      View Summary
                    </Button>
                  </CardContent>
                </Card>

                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Balance History</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-3">
                      Historical balance tracking and trends
                    </p>
                    <Button variant="outline" size="sm" className="w-full">
                      View History
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}