import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { GraduationCap, IdCard, FileText, Receipt, PartyPopper, ArrowRight } from "lucide-react";

interface ReceiptsHubProps {
  onNavigate: (view: string) => void;
}

const receiptOptions = [
  {
    id: 'school-fee-receipt',
    title: 'School Fee Receipt',
    description: 'Generate receipts for school fees, tuition, and academic charges',
    icon: GraduationCap,
    color: 'text-primary',
    bgColor: 'bg-primary/10'
  },
  {
    id: 'id-card-fee-receipt',
    title: 'ID Card Fee Receipt',
    description: 'Issue receipts for student ID cards and smart card fees',
    icon: IdCard,
    color: 'text-primary',
    bgColor: 'bg-primary/10'
  },
  {
    id: 'fee-cancellation-request',
    title: 'Fee Cancellation Request Form',
    description: 'Submit and manage fee cancellation and refund requests',
    icon: FileText,
    color: 'text-primary',
    bgColor: 'bg-primary/10'
  },
  {
    id: 'exam-fee-receipt',
    title: 'Exam Fee Receipt',
    description: 'Generate receipts for examination fees and assessment charges',
    icon: Receipt,
    color: 'text-primary',
    bgColor: 'bg-primary/10'
  },
  {
    id: 'event-management-receipt',
    title: 'Event Management Receipt',
    description: 'Issue receipts for cultural events, workshops, and activities',
    icon: PartyPopper,
    color: 'text-primary',
    bgColor: 'bg-primary/10'
  }
];

export function ReceiptsHub({ onNavigate }: ReceiptsHubProps) {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1>Receipts Management</h1>
        <p>Select a receipt type to generate or manage receipts for students and participants</p>
      </div>

      {/* Receipt Options Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {receiptOptions.map((option) => {
          const IconComponent = option.icon;
          return (
            <Card key={option.id} className="hover:shadow-lg transition-all duration-200 cursor-pointer group border-0 shadow-sm">
              <CardHeader>
                <div className="flex items-start justify-between mb-3">
                  <div className={`p-3 rounded-lg ${option.bgColor} ${option.color}`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all" />
                </div>
                <CardTitle>{option.title}</CardTitle>
                <CardDescription>
                  {option.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <Button 
                  onClick={() => onNavigate(option.id)}
                  className="w-full"
                  variant="outline"
                >
                  Open Form
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-12">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Total Receipts Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">47</div>
            <p className="text-muted-foreground">Across all categories</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Revenue Today</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">₹1,24,500</div>
            <p className="text-muted-foreground">From all receipt types</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Pending Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">12</div>
            <p className="text-muted-foreground">Awaiting approval</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Receipt Activity</CardTitle>
          <CardDescription>Latest receipts generated across all categories</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between py-3 border-b border-border/50">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded bg-primary/10 text-primary">
                  <GraduationCap className="w-4 h-4" />
                </div>
                <div>
                  <p>School Fee - Arjun Kumar</p>
                  <p className="text-muted-foreground">SRIVEN BC-1 • 5th Class A</p>
                </div>
              </div>
              <div className="text-right">
                <p>₹8,500</p>
                <p className="text-muted-foreground">2 min ago</p>
              </div>
            </div>

            <div className="flex items-center justify-between py-3 border-b border-border/50">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded bg-primary/10 text-primary">
                  <IdCard className="w-4 h-4" />
                </div>
                <div>
                  <p>ID Card Fee - Meera Reddy</p>
                  <p className="text-muted-foreground">SRIVEN DC-1 • MBA 1st Year</p>
                </div>
              </div>
              <div className="text-right">
                <p>₹750</p>
                <p className="text-muted-foreground">15 min ago</p>
              </div>
            </div>

            <div className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded bg-primary/10 text-primary">
                  <Receipt className="w-4 h-4" />
                </div>
                <div>
                  <p>Exam Fee - Ravi Kumar</p>
                  <p className="text-muted-foreground">SRIVEN BC-1 • B.Tech 3rd Year</p>
                </div>
              </div>
              <div className="text-right">
                <p>₹2,500</p>
                <p className="text-muted-foreground">1 hour ago</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}