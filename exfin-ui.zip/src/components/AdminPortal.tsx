import image_f68c1a989952b7d595b5240d001cf19fbcd31fed from 'figma:asset/f68c1a989952b7d595b5240d001cf19fbcd31fed.png';
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  UserPlus, Building2, Users, FileText, TrendingUp, CheckCircle,
  XCircle, Clock, Eye, Edit, Trash2, Download, DollarSign, AlertCircle
} from 'lucide-react';
import { VendorRegistration, type VendorData } from './VendorRegistration';
import { useAuth } from './AuthContext';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { UserLoginInfo } from './UserLoginInfo';

interface AdminPortalProps {
  onNavigate: (view: string) => void;
}

const mockVendors: VendorData[] = [
  {
    id: '1',
    type: 'electricity',
    name: 'Telangana State Electricity Board',
    contactPerson: 'Rajesh Kumar',
    email: 'rajesh@tseb.gov.in',
    phone: '+91 9876543210',
    address: 'Vidyut Bhavan, Hyderabad, Telangana',
    gstNumber: '36ABCDE1234F1Z5',
    bankDetails: {
      accountNumber: '123456789012',
      ifscCode: 'SBIN0001234',
      bankName: 'State Bank of India',
      accountHolder: 'TSEB Collections'
    },
    services: 'Electricity supply and maintenance for educational institutions',
    status: 'approved',
    registeredDate: new Date('2024-01-15')
  },
  {
    id: '2',
    type: 'rental_owners',
    name: 'Sri Lakshmi Properties',
    contactPerson: 'Venkata Rao',
    email: 'venkat@srilakshmi.com',
    phone: '+91 9876543211',
    address: 'Banjara Hills, Hyderabad, Telangana',
    gstNumber: '36FGHIJ5678K2L3',
    bankDetails: {
      accountNumber: '987654321098',
      ifscCode: 'HDFC0001234',
      bankName: 'HDFC Bank',
      accountHolder: 'Sri Lakshmi Properties'
    },
    services: 'Commercial property rental for educational institutions',
    status: 'pending',
    registeredDate: new Date('2024-01-20')
  },
  {
    id: '3',
    type: 'mess',
    name: 'Annapurna Catering Services',
    contactPerson: 'Sita Devi',
    email: 'sita@annapurna.com',
    phone: '+91 9876543212',
    address: 'Kukatpally, Hyderabad, Telangana',
    bankDetails: {
      accountNumber: '456789123456',
      ifscCode: 'ICIC0001234',
      bankName: 'ICICI Bank',
      accountHolder: 'Annapurna Catering Services'
    },
    services: 'Food catering and mess services for hostels and institutions',
    status: 'rejected',
    registeredDate: new Date('2024-01-18')
  }
];

// System-wide statistics
const systemStats = {
  totalUsers: 42,
  activeUsers: 38,
  totalBranches: 17,
  totalVendors: 127,
  pendingApprovals: 8,
  monthlyTransactions: 1247
};

// Mock pending approvals
const mockPendingApprovals = [
  {
    id: '1',
    type: 'Vendor',
    name: 'ABC Suppliers',
    requestedBy: 'Admin Team',
    date: new Date('2024-12-01'),
    status: 'Pending'
  },
  {
    id: '2',
    type: 'User Access',
    name: 'New Accountant - Ramesh',
    requestedBy: 'HR Department',
    date: new Date('2024-12-03'),
    status: 'Pending'
  }
];

export function AdminPortal({ onNavigate }: AdminPortalProps) {
  const { user } = useAuth();
  const [showRegistration, setShowRegistration] = useState(false);
  const [vendors, setVendors] = useState<VendorData[]>(mockVendors);
  const [activeTab, setActiveTab] = useState('overview');

  const handleVendorRegistrationComplete = (vendor: VendorData) => {
    setVendors(prev => [...prev, vendor]);
    setShowRegistration(false);
  };

  const handleApproveVendor = (vendorId: string) => {
    setVendors(prev => prev.map(vendor => 
      vendor.id === vendorId 
        ? { ...vendor, status: 'approved' as const }
        : vendor
    ));
  };

  const handleRejectVendor = (vendorId: string) => {
    setVendors(prev => prev.map(vendor => 
      vendor.id === vendorId 
        ? { ...vendor, status: 'rejected' as const }
        : vendor
    ));
  };

  const getStatusBadge = (status: VendorData['status']) => {
    const variants = {
      approved: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      rejected: 'bg-red-100 text-red-800'
    };
    return <Badge className={variants[status]}>{status}</Badge>;
  };

  const getVendorTypeLabel = (type: VendorData['type']) => {
    const labels = {
      vendors: 'General Vendor',
      rental_owners: 'Rental Owner',
      electricity: 'Electricity',
      salaries: 'Salary Management',
      mess: 'Mess & Catering',
      transport: 'Transportation',
      supplies: 'Office Supplies',
      maintenance: 'Maintenance'
    };
    return labels[type];
  };

  if (showRegistration) {
    return (
      <VendorRegistration
        onClose={() => setShowRegistration(false)}
        onComplete={handleVendorRegistrationComplete}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* User Login Info */}
      <UserLoginInfo className="bg-blue-50 p-3 rounded-lg border border-blue-200" />
      
      {/* Admin Profile Header */}
      <div className="flex items-center justify-between p-6 rounded-lg border">
        <div className="flex items-center gap-4">
          <div className="relative">
            <ImageWithFallback
              src={image_f68c1a989952b7d595b5240d001cf19fbcd31fed}
              alt="Admin Profile"
              className="w-16 h-16 rounded-full object-cover border-2 border-blue-200 rounded-[15px]"
            />
            <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-white"></div>
          </div>
          <div>
            <h1 className="text-xl font-semibold text-blue-800">Welcome, {user?.name || 'Admin'}</h1>
            <p className="text-blue-600">Sri Venkateswara Enterprises - Admin Portal</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setShowRegistration(true)} className="flex items-center gap-2">
            <UserPlus className="w-4 h-4" />
            Register Vendor
          </Button>
          <Button variant="outline" onClick={() => onNavigate('branch-management')} className="flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            Manage Branches
          </Button>
        </div>
      </div>

      {/* System Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{systemStats.totalUsers}</div>
            <p className="text-xs text-muted-foreground">
              {systemStats.activeUsers} active users
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Branches</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{systemStats.totalBranches}</div>
            <p className="text-xs text-muted-foreground">
              Across 3 organizations
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Registered Vendors</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{systemStats.totalVendors}</div>
            <p className="text-xs text-muted-foreground">
              {vendors.filter(v => v.status === 'pending').length} pending approval
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{systemStats.pendingApprovals}</div>
            <p className="text-xs text-muted-foreground">
              Requires immediate attention
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Transactions</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{systemStats.monthlyTransactions}</div>
            <p className="text-xs text-muted-foreground">
              +12% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Health</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">Excellent</div>
            <p className="text-xs text-muted-foreground">
              All systems operational
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs for Vendor Management and Approvals */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="vendors">Vendor Management</TabsTrigger>
          <TabsTrigger value="approvals">Pending Approvals</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Common administrative tasks</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button variant="outline" onClick={() => onNavigate('branch-management')} className="h-auto flex-col py-4">
                <Building2 className="h-8 w-8 mb-2" />
                <span>Branch Management</span>
              </Button>
              <Button variant="outline" onClick={() => onNavigate('user-management')} className="h-auto flex-col py-4">
                <Users className="h-8 w-8 mb-2" />
                <span>User Management</span>
              </Button>
              <Button variant="outline" onClick={() => setShowRegistration(true)} className="h-auto flex-col py-4">
                <UserPlus className="h-8 w-8 mb-2" />
                <span>Add Vendor</span>
              </Button>
              <Button variant="outline" onClick={() => onNavigate('analytics')} className="h-auto flex-col py-4">
                <TrendingUp className="h-8 w-8 mb-2" />
                <span>View Analytics</span>
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="vendors" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Vendor Management</CardTitle>
                  <CardDescription>Manage all registered vendors</CardDescription>
                </div>
                <Button onClick={() => setShowRegistration(true)}>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Register New Vendor
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vendor Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Contact Person</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vendors.map((vendor) => (
                    <TableRow key={vendor.id}>
                      <TableCell className="font-medium">{vendor.name}</TableCell>
                      <TableCell>{getVendorTypeLabel(vendor.type)}</TableCell>
                      <TableCell>{vendor.contactPerson}</TableCell>
                      <TableCell>{vendor.phone}</TableCell>
                      <TableCell>{getStatusBadge(vendor.status)}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          {vendor.status === 'pending' && (
                            <>
                              <Button size="sm" onClick={() => handleApproveVendor(vendor.id)}>
                                <CheckCircle className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => handleRejectVendor(vendor.id)}>
                                <XCircle className="w-4 h-4" />
                              </Button>
                            </>
                          )}
                          <Button size="sm" variant="outline">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="approvals" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pending Approvals</CardTitle>
              <CardDescription>Items requiring your approval</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Requested By</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockPendingApprovals.map((approval) => (
                    <TableRow key={approval.id}>
                      <TableCell>{approval.type}</TableCell>
                      <TableCell className="font-medium">{approval.name}</TableCell>
                      <TableCell>{approval.requestedBy}</TableCell>
                      <TableCell>{approval.date.toLocaleDateString()}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button size="sm">Approve</Button>
                          <Button size="sm" variant="destructive">Reject</Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
