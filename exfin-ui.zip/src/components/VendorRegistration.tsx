import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { Alert, AlertDescription } from "./ui/alert";
import { Badge } from "./ui/badge";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Switch } from "./ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { 
  Building2, 
  Zap, 
  Users, 
  Truck, 
  Home, 
  ShoppingCart, 
  Utensils,
  CheckCircle,
  Upload,
  CalendarDays,
  FileText,
  CreditCard,
  Monitor,
  PartyPopper,
  Settings,
  Search,
  Filter,
  Plus,
  Edit,
  Eye,
  UserCheck,
  UserX,
  Phone,
  Mail,
  MapPin,
  IndianRupee,
  Calendar as CalendarIcon,
  Building,
  Car,
  Wifi,
  Coffee,
  Wrench
} from 'lucide-react';
import { toast } from "sonner@2.0.3";

// Simple date formatter
const formatDate = (date: Date) => {
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
};

export interface VendorData {
  id: string;
  // Basic Information
  vendorName: string;
  vendorType: string;
  contactPersonName: string;
  mobileNumber: string;
  alternateNumber?: string;
  emailId: string;
  fullAddress: string;
  city: string;
  state: string;
  
  // Financial & Tax Details
  panCardNumber?: string;
  gstinNumber?: string;
  bankAccountHolderName: string;
  bankName: string;
  bankAccountNumber: string;
  ifscCode: string;
  branchName?: string;
  accountType: string;
  
  // Contract & Document Details
  contractStartDate: Date;
  contractEndDate?: Date;
  paymentTerms: string;
  uploadedDocuments?: File[];
  
  // Vendor Type Specific Fields
  specificFields?: {
    // Electricity Provider
    serviceProvider?: string;
    consumerNumber?: string;
    billingCycle?: string;
    
    // House Owners
    propertyAddress?: string;
    agreementStartDate?: Date;
    agreementEndDate?: Date;
    monthlyRent?: number;
    advanceAmount?: number;
    
    // Mess & Catering
    cuisineType?: string;
    capacity?: number;
    ratePerPlate?: number;
    
    // Transportation
    vehicleDetails?: string;
    driverName?: string;
    driverContact?: string;
    routeDetails?: string;
    monthlyCharges?: number;
    
    // Salary Management
    employeeCategory?: string;
    numberOfEmployees?: number;
    paymentCycle?: string;
    
    // IT & Software
    licenseDetails?: string;
    supportContact?: string;
    
    // Event Management
    eventTypes?: string;
    contractPeriod?: string;
    
    // AC Vendors
    serviceType?: string;
    warrantyPeriod?: string;
    
    // Maintenance Services
    maintenanceType?: string;
    responseTime?: string;
  };
  
  // System fields
  status: 'active' | 'inactive';
  approvalStatus: 'pending' | 'approved' | 'rejected';
  registeredDate: Date;
  lastUpdated?: Date;
  notes?: string;
}

const vendorTypes = [
  'General Vendor',
  'Electricity Bill Payment',
  'House Owners',
  'Mess & Catering',
  'AC Vendors',
  'Salary Management',
  'Transportation Services',
  'Office Supplies',
  'Maintenance Services',
  'IT & Software Services',
  'Event Management',
  'Other'
];

const accountTypes = ['Savings', 'Current'];

const paymentTermsOptions = [
  'Monthly',
  'Quarterly',
  'Half-yearly',
  'Annually',
  'On Demand',
  'Upon Completion',
  'Advance Payment',
  '15 Days Credit',
  '30 Days Credit',
  'Custom Terms'
];

const statesList = [
  'Andhra Pradesh', 'Telangana', 'Tamil Nadu', 'Karnataka', 'Kerala', 
  'Maharashtra', 'Delhi', 'Gujarat', 'Rajasthan', 'Other'
];

// Mock data for demonstration
const mockVendors: VendorData[] = [
  {
    id: 'VEN-001',
    vendorName: 'Sri Venkateshwara Catering Services',
    vendorType: 'Mess & Catering',
    contactPersonName: 'Rajesh Kumar',
    mobileNumber: '9876543210',
    emailId: 'rajesh@svcatering.com',
    fullAddress: 'Plot No. 45, Industrial Area, Visakhapatnam',
    city: 'Visakhapatnam',
    state: 'Andhra Pradesh',
    bankAccountHolderName: 'Sri Venkateshwara Catering Services',
    bankName: 'State Bank of India',
    bankAccountNumber: '12345678901',
    ifscCode: 'SBIN0001234',
    accountType: 'Current',
    contractStartDate: new Date('2024-01-01'),
    paymentTerms: 'Monthly',
    specificFields: {
      cuisineType: 'Veg & Non-Veg',
      capacity: 500,
      ratePerPlate: 45
    },
    status: 'active',
    approvalStatus: 'approved',
    registeredDate: new Date('2024-01-15'),
    notes: 'Excellent service quality, regular supplier'
  },
  {
    id: 'VEN-002',
    vendorName: 'APSPDCL Electricity Board',
    vendorType: 'Electricity Bill Payment',
    contactPersonName: 'Suresh Babu',
    mobileNumber: '9876543211',
    emailId: 'suresh@apspdcl.gov.in',
    fullAddress: 'Electricity Board Complex, Visakhapatnam',
    city: 'Visakhapatnam',
    state: 'Andhra Pradesh',
    bankAccountHolderName: 'APSPDCL',
    bankName: 'State Bank of India',
    bankAccountNumber: '98765432101',
    ifscCode: 'SBIN0001235',
    accountType: 'Current',
    contractStartDate: new Date('2024-01-01'),
    paymentTerms: 'Monthly',
    specificFields: {
      serviceProvider: 'APSPDCL',
      consumerNumber: 'AP12345678',
      billingCycle: 'Monthly'
    },
    status: 'active',
    approvalStatus: 'approved',
    registeredDate: new Date('2024-01-10')
  }
];

interface VendorRegistrationProps {
  onSubmit?: (vendor: VendorData) => void;
}

export function VendorRegistration({ onSubmit }: VendorRegistrationProps) {
  const [activeTab, setActiveTab] = useState('register');
  const [vendors, setVendors] = useState<VendorData[]>(mockVendors);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  
  // Registration form state
  const [formData, setFormData] = useState({
    // Basic Information
    vendorName: '',
    vendorType: '',
    contactPersonName: '',
    mobileNumber: '',
    alternateNumber: '',
    emailId: '',
    fullAddress: '',
    city: '',
    state: '',
    
    // Financial & Tax Details
    panCardNumber: '',
    gstinNumber: '',
    bankAccountHolderName: '',
    bankName: '',
    bankAccountNumber: '',
    ifscCode: '',
    branchName: '',
    accountType: 'Savings',
    
    // Contract & Document Details
    paymentTerms: '',
    notes: '',
    
    // Type-specific fields
    specificFields: {} as any
  });

  const [contractStartDate, setContractStartDate] = useState<Date>();
  const [contractEndDate, setContractEndDate] = useState<Date>();
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState(1); // 1: Basic, 2: Financial, 3: Contract, 4: Type-specific
  const [editingVendor, setEditingVendor] = useState<VendorData | null>(null);
  const [viewingVendor, setViewingVendor] = useState<VendorData | null>(null);

  // Filter vendors based on search and filters
  const filteredVendors = vendors.filter(vendor => {
    const matchesSearch = vendor.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         vendor.contactPersonName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         vendor.emailId.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = filterType === 'all' || vendor.vendorType === filterType;
    const matchesStatus = filterStatus === 'all' || vendor.status === filterStatus;
    
    return matchesSearch && matchesType && matchesStatus;
  });

  // Validation functions
  const validatePAN = (pan: string) => {
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    return panRegex.test(pan);
  };

  const validateGSTIN = (gstin: string) => {
    const gstinRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
    return gstinRegex.test(gstin);
  };

  const validateMobile = (mobile: string) => {
    const mobileRegex = /^[0-9]{10}$/;
    return mobileRegex.test(mobile);
  };

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validateStep = (stepNumber: number) => {
    const newErrors: Record<string, string> = {};

    if (stepNumber === 1) {
      if (!formData.vendorName.trim()) newErrors.vendorName = 'Vendor name is required';
      if (!formData.vendorType) newErrors.vendorType = 'Vendor type is required';
      if (!formData.contactPersonName.trim()) newErrors.contactPersonName = 'Contact person name is required';
      if (!formData.mobileNumber.trim()) {
        newErrors.mobileNumber = 'Mobile number is required';
      } else if (!validateMobile(formData.mobileNumber)) {
        newErrors.mobileNumber = 'Please enter a valid 10-digit mobile number';
      }
      if (!formData.emailId.trim()) {
        newErrors.emailId = 'Email ID is required';
      } else if (!validateEmail(formData.emailId)) {
        newErrors.emailId = 'Please enter a valid email address';
      }
      if (!formData.fullAddress.trim()) newErrors.fullAddress = 'Full address is required';
      if (!formData.city.trim()) newErrors.city = 'City is required';
      if (!formData.state) newErrors.state = 'State is required';
    }

    if (stepNumber === 2) {
      if (formData.panCardNumber && !validatePAN(formData.panCardNumber.toUpperCase())) {
        newErrors.panCardNumber = 'Please enter a valid PAN number';
      }
      if (formData.gstinNumber && !validateGSTIN(formData.gstinNumber.toUpperCase())) {
        newErrors.gstinNumber = 'Please enter a valid GSTIN number';
      }
      if (!formData.bankAccountHolderName.trim()) newErrors.bankAccountHolderName = 'Account holder name is required';
      if (!formData.bankName.trim()) newErrors.bankName = 'Bank name is required';
      if (!formData.bankAccountNumber.trim()) newErrors.bankAccountNumber = 'Account number is required';
      if (!formData.ifscCode.trim()) newErrors.ifscCode = 'IFSC code is required';
    }

    if (stepNumber === 3) {
      if (!contractStartDate) newErrors.contractStartDate = 'Contract start date is required';
      if (!formData.paymentTerms) newErrors.paymentTerms = 'Payment terms are required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleSpecificFieldChange = (field: string, value: string | number | Date) => {
    setFormData(prev => ({
      ...prev,
      specificFields: { ...prev.specificFields, [field]: value }
    }));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setUploadedFiles(prev => [...prev, ...files]);
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const resetForm = () => {
    setFormData({
      vendorName: '',
      vendorType: '',
      contactPersonName: '',
      mobileNumber: '',
      alternateNumber: '',
      emailId: '',
      fullAddress: '',
      city: '',
      state: '',
      panCardNumber: '',
      gstinNumber: '',
      bankAccountHolderName: '',
      bankName: '',
      bankAccountNumber: '',
      ifscCode: '',
      branchName: '',
      accountType: 'Savings',
      paymentTerms: '',
      notes: '',
      specificFields: {}
    });
    setContractStartDate(undefined);
    setContractEndDate(undefined);
    setUploadedFiles([]);
    setStep(1);
    setErrors({});
    setEditingVendor(null);
  };

  const handleNext = () => {
    if (validateStep(step)) {
      if (step < 4) {
        setStep(step + 1);
      } else {
        handleSubmit();
      }
    }
  };

  const handleSubmit = async () => {
    if (!validateStep(3) || !contractStartDate) return;

    setIsSubmitting(true);
    try {
      const vendorData: VendorData = {
        id: editingVendor ? editingVendor.id : `VEN-${Date.now()}`,
        vendorName: formData.vendorName.trim(),
        vendorType: formData.vendorType,
        contactPersonName: formData.contactPersonName.trim(),
        mobileNumber: formData.mobileNumber.trim(),
        alternateNumber: formData.alternateNumber?.trim(),
        emailId: formData.emailId.trim(),
        fullAddress: formData.fullAddress.trim(),
        city: formData.city.trim(),
        state: formData.state,
        panCardNumber: formData.panCardNumber?.toUpperCase(),
        gstinNumber: formData.gstinNumber?.toUpperCase(),
        bankAccountHolderName: formData.bankAccountHolderName.trim(),
        bankName: formData.bankName.trim(),
        bankAccountNumber: formData.bankAccountNumber.trim(),
        ifscCode: formData.ifscCode.toUpperCase(),
        branchName: formData.branchName?.trim(),
        accountType: formData.accountType,
        contractStartDate,
        contractEndDate,
        paymentTerms: formData.paymentTerms,
        uploadedDocuments: uploadedFiles,
        specificFields: formData.specificFields,
        status: editingVendor?.status || 'active',
        approvalStatus: editingVendor?.approvalStatus || 'pending',
        registeredDate: editingVendor?.registeredDate || new Date(),
        lastUpdated: new Date(),
        notes: formData.notes?.trim()
      };

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      if (editingVendor) {
        setVendors(prev => prev.map(v => v.id === editingVendor.id ? vendorData : v));
        toast.success('Vendor updated successfully!');
      } else {
        setVendors(prev => [...prev, vendorData]);
        toast.success('Vendor registered successfully!');
      }
      
      if (onSubmit) {
        onSubmit(vendorData);
      }
      
      resetForm();
      setActiveTab('manage');
      
    } catch (error) {
      toast.error('Failed to submit vendor registration. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (vendor: VendorData) => {
    setEditingVendor(vendor);
    setFormData({
      vendorName: vendor.vendorName,
      vendorType: vendor.vendorType,
      contactPersonName: vendor.contactPersonName,
      mobileNumber: vendor.mobileNumber,
      alternateNumber: vendor.alternateNumber || '',
      emailId: vendor.emailId,
      fullAddress: vendor.fullAddress,
      city: vendor.city,
      state: vendor.state,
      panCardNumber: vendor.panCardNumber || '',
      gstinNumber: vendor.gstinNumber || '',
      bankAccountHolderName: vendor.bankAccountHolderName,
      bankName: vendor.bankName,
      bankAccountNumber: vendor.bankAccountNumber,
      ifscCode: vendor.ifscCode,
      branchName: vendor.branchName || '',
      accountType: vendor.accountType,
      paymentTerms: vendor.paymentTerms,
      notes: vendor.notes || '',
      specificFields: vendor.specificFields || {}
    });
    setContractStartDate(vendor.contractStartDate);
    setContractEndDate(vendor.contractEndDate);
    setActiveTab('register');
  };

  const handleStatusToggle = (vendorId: string) => {
    setVendors(prev => prev.map(vendor => 
      vendor.id === vendorId 
        ? { ...vendor, status: vendor.status === 'active' ? 'inactive' : 'active', lastUpdated: new Date() }
        : vendor
    ));
    toast.success('Vendor status updated successfully!');
  };

  const getVendorTypeIcon = (type: string) => {
    switch (type) {
      case 'Electricity Bill Payment': return Zap;
      case 'House Owners': return Home;
      case 'Mess & Catering': return Utensils;
      case 'AC Vendors': return Monitor;
      case 'Transportation Services': return Truck;
      case 'Office Supplies': return ShoppingCart;
      case 'Maintenance Services': return Settings;
      case 'IT & Software Services': return Monitor;
      case 'Event Management': return PartyPopper;
      default: return Building2;
    }
  };

  const renderTypeSpecificFields = () => {
    if (!formData.vendorType) return null;

    switch (formData.vendorType) {
      case 'Electricity Bill Payment':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold">Electricity Provider Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Service Provider</Label>
                <Select onValueChange={(value) => handleSpecificFieldChange('serviceProvider', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select service provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="APSPDCL">APSPDCL</SelectItem>
                    <SelectItem value="TSSPDCL">TSSPDCL</SelectItem>
                    <SelectItem value="KSEB">KSEB</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Consumer/Service Number</Label>
                <Input
                  placeholder="Enter consumer number"
                  value={formData.specificFields.consumerNumber || ''}
                  onChange={(e) => handleSpecificFieldChange('consumerNumber', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Billing Cycle</Label>
                <Select onValueChange={(value) => handleSpecificFieldChange('billingCycle', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select billing cycle" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Monthly">Monthly</SelectItem>
                    <SelectItem value="Bi-Monthly">Bi-Monthly</SelectItem>
                    <SelectItem value="Quarterly">Quarterly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 'House Owners':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold">Property Rental Details</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Property Address</Label>
                <Textarea
                  placeholder="Enter property address"
                  value={formData.specificFields.propertyAddress || ''}
                  onChange={(e) => handleSpecificFieldChange('propertyAddress', e.target.value)}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Monthly Rent (₹)</Label>
                  <Input
                    type="number"
                    placeholder="Enter monthly rent"
                    value={formData.specificFields.monthlyRent || ''}
                    onChange={(e) => handleSpecificFieldChange('monthlyRent', parseFloat(e.target.value))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Advance Amount (₹)</Label>
                  <Input
                    type="number"
                    placeholder="Enter advance amount"
                    value={formData.specificFields.advanceAmount || ''}
                    onChange={(e) => handleSpecificFieldChange('advanceAmount', parseFloat(e.target.value))}
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 'Mess & Catering':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold">Catering Service Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Cuisine Type</Label>
                <Select onValueChange={(value) => handleSpecificFieldChange('cuisineType', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select cuisine type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Veg Only">Veg Only</SelectItem>
                    <SelectItem value="Non-Veg Only">Non-Veg Only</SelectItem>
                    <SelectItem value="Veg & Non-Veg">Veg & Non-Veg</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Serving Capacity</Label>
                <Input
                  type="number"
                  placeholder="Number of people"
                  value={formData.specificFields.capacity || ''}
                  onChange={(e) => handleSpecificFieldChange('capacity', parseInt(e.target.value))}
                />
              </div>
              <div className="space-y-2">
                <Label>Rate per Plate (₹)</Label>
                <Input
                  type="number"
                  placeholder="Rate per plate"
                  value={formData.specificFields.ratePerPlate || ''}
                  onChange={(e) => handleSpecificFieldChange('ratePerPlate', parseFloat(e.target.value))}
                />
              </div>
            </div>
          </div>
        );

      case 'Transportation Services':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold">Transportation Details</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Vehicle Details</Label>
                  <Input
                    placeholder="Vehicle type & number"
                    value={formData.specificFields.vehicleDetails || ''}
                    onChange={(e) => handleSpecificFieldChange('vehicleDetails', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Driver Name</Label>
                  <Input
                    placeholder="Driver name"
                    value={formData.specificFields.driverName || ''}
                    onChange={(e) => handleSpecificFieldChange('driverName', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Driver Contact</Label>
                  <Input
                    placeholder="Driver mobile number"
                    value={formData.specificFields.driverContact || ''}
                    onChange={(e) => handleSpecificFieldChange('driverContact', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Monthly Charges (₹)</Label>
                  <Input
                    type="number"
                    placeholder="Monthly charges"
                    value={formData.specificFields.monthlyCharges || ''}
                    onChange={(e) => handleSpecificFieldChange('monthlyCharges', parseFloat(e.target.value))}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Route Details</Label>
                <Textarea
                  placeholder="Route information"
                  value={formData.specificFields.routeDetails || ''}
                  onChange={(e) => handleSpecificFieldChange('routeDetails', e.target.value)}
                />
              </div>
            </div>
          </div>
        );

      case 'Salary Management':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold">Employee Management Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Employee Category</Label>
                <Select onValueChange={(value) => handleSpecificFieldChange('employeeCategory', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Teaching Staff">Teaching Staff</SelectItem>
                    <SelectItem value="Non-Teaching Staff">Non-Teaching Staff</SelectItem>
                    <SelectItem value="Contract Staff">Contract Staff</SelectItem>
                    <SelectItem value="All Categories">All Categories</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Number of Employees</Label>
                <Input
                  type="number"
                  placeholder="Employee count"
                  value={formData.specificFields.numberOfEmployees || ''}
                  onChange={(e) => handleSpecificFieldChange('numberOfEmployees', parseInt(e.target.value))}
                />
              </div>
              <div className="space-y-2">
                <Label>Payment Cycle</Label>
                <Select onValueChange={(value) => handleSpecificFieldChange('paymentCycle', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment cycle" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Monthly">Monthly</SelectItem>
                    <SelectItem value="Quarterly">Quarterly</SelectItem>
                    <SelectItem value="Half-yearly">Half-yearly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 'IT & Software Services':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold">IT Service Details</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>License/Service Details</Label>
                <Textarea
                  placeholder="Software licenses, services provided"
                  value={formData.specificFields.licenseDetails || ''}
                  onChange={(e) => handleSpecificFieldChange('licenseDetails', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Support Contact Person</Label>
                <Input
                  placeholder="Technical support contact"
                  value={formData.specificFields.supportContact || ''}
                  onChange={(e) => handleSpecificFieldChange('supportContact', e.target.value)}
                />
              </div>
            </div>
          </div>
        );

      case 'Event Management':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold">Event Management Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Event Types</Label>
                <Input
                  placeholder="Cultural, Sports, Annual Day, etc."
                  value={formData.specificFields.eventTypes || ''}
                  onChange={(e) => handleSpecificFieldChange('eventTypes', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Contract Period</Label>
                <Input
                  placeholder="Contract duration"
                  value={formData.specificFields.contractPeriod || ''}
                  onChange={(e) => handleSpecificFieldChange('contractPeriod', e.target.value)}
                />
              </div>
            </div>
          </div>
        );

      case 'AC Vendors':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold">AC Service Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Service Type</Label>
                <Select onValueChange={(value) => handleSpecificFieldChange('serviceType', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select service type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Installation">Installation</SelectItem>
                    <SelectItem value="Maintenance">Maintenance</SelectItem>
                    <SelectItem value="Repair">Repair</SelectItem>
                    <SelectItem value="AMC">AMC</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Warranty Period</Label>
                <Input
                  placeholder="Warranty duration"
                  value={formData.specificFields.warrantyPeriod || ''}
                  onChange={(e) => handleSpecificFieldChange('warrantyPeriod', e.target.value)}
                />
              </div>
            </div>
          </div>
        );

      case 'Maintenance Services':
        return (
          <div className="space-y-4">
            <h3 className="font-semibold">Maintenance Service Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Maintenance Type</Label>
                <Select onValueChange={(value) => handleSpecificFieldChange('maintenanceType', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select maintenance type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Building Maintenance">Building Maintenance</SelectItem>
                    <SelectItem value="Electrical">Electrical</SelectItem>
                    <SelectItem value="Plumbing">Plumbing</SelectItem>
                    <SelectItem value="Gardening">Gardening</SelectItem>
                    <SelectItem value="Cleaning">Cleaning</SelectItem>
                    <SelectItem value="General">General</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Response Time</Label>
                <Select onValueChange={(value) => handleSpecificFieldChange('responseTime', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select response time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Same Day">Same Day</SelectItem>
                    <SelectItem value="24 Hours">24 Hours</SelectItem>
                    <SelectItem value="48 Hours">48 Hours</SelectItem>
                    <SelectItem value="72 Hours">72 Hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const getStepIcon = (stepNumber: number) => {
    switch (stepNumber) {
      case 1: return Users;
      case 2: return CreditCard;
      case 3: return FileText;
      case 4: return Settings;
      default: return Users;
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Vendor Management System</h1>
        <p className="text-muted-foreground">
          Comprehensive vendor registration and management for Sriviswa Educational Institutions
        </p>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="register" className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            {editingVendor ? 'Edit Vendor' : 'Register Vendor'}
          </TabsTrigger>
          <TabsTrigger value="manage" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Manage Vendors ({vendors.length})
          </TabsTrigger>
        </TabsList>

        {/* Registration Tab */}
        <TabsContent value="register" className="space-y-6">
          {/* Progress Steps */}
          <div className="flex items-center justify-center space-x-8 mb-8">
            {[1, 2, 3, 4].map((stepNumber) => {
              const StepIcon = getStepIcon(stepNumber);
              const isActive = step === stepNumber;
              const isCompleted = step > stepNumber;
              
              return (
                <div key={stepNumber} className="flex items-center">
                  <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                    isCompleted 
                      ? 'bg-green-500 border-green-500 text-white' 
                      : isActive 
                        ? 'bg-primary border-primary text-white' 
                        : 'border-gray-300 text-gray-400'
                  }`}>
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5" />
                    ) : (
                      <StepIcon className="w-5 h-5" />
                    )}
                  </div>
                  <div className="ml-3 text-left">
                    <p className={`text-sm font-medium ${
                      isActive ? 'text-foreground' : 'text-muted-foreground'
                    }`}>
                      Step {stepNumber}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {stepNumber === 1 && 'Basic Info'}
                      {stepNumber === 2 && 'Financial'}
                      {stepNumber === 3 && 'Contract'}
                      {stepNumber === 4 && 'Type-specific'}
                    </p>
                  </div>
                  
                  {stepNumber < 4 && (
                    <div className={`w-16 h-0.5 ml-4 ${
                      step > stepNumber ? 'bg-green-500' : 'bg-gray-300'
                    }`} />
                  )}
                </div>
              );
            })}
          </div>

          {/* Form Card */}
          <Card className="mx-auto">
            <CardHeader>
              <CardTitle>
                {step === 1 && 'Basic Information'}
                {step === 2 && 'Financial & Tax Details'}
                {step === 3 && 'Contract & Payment Terms'}
                {step === 4 && 'Type-specific Details'}
              </CardTitle>
              <CardDescription>
                {step === 1 && 'Please provide basic vendor information'}
                {step === 2 && 'Financial details for payment processing'}
                {step === 3 && 'Contract terms and document uploads'}
                {step === 4 && 'Vendor type specific requirements'}
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Step 1: Basic Information */}
              {step === 1 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="vendorName">Vendor/Company Name *</Label>
                      <Input
                        id="vendorName"
                        placeholder="Enter vendor/company name"
                        value={formData.vendorName}
                        onChange={(e) => handleInputChange('vendorName', e.target.value)}
                        className={errors.vendorName ? 'border-red-500' : ''}
                      />
                      {errors.vendorName && <p className="text-sm text-red-500">{errors.vendorName}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="vendorType">Vendor Type *</Label>
                      <Select value={formData.vendorType} onValueChange={(value) => handleInputChange('vendorType', value)}>
                        <SelectTrigger className={errors.vendorType ? 'border-red-500' : ''}>
                          <SelectValue placeholder="Select vendor type" />
                        </SelectTrigger>
                        <SelectContent>
                          {vendorTypes.map((type) => {
                            const IconComponent = getVendorTypeIcon(type);
                            return (
                              <SelectItem key={type} value={type}>
                                <div className="flex items-center gap-2">
                                  <IconComponent className="w-4 h-4" />
                                  {type}
                                </div>
                              </SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>
                      {errors.vendorType && <p className="text-sm text-red-500">{errors.vendorType}</p>}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="contactPersonName">Contact Person Name *</Label>
                      <Input
                        id="contactPersonName"
                        placeholder="Enter contact person name"
                        value={formData.contactPersonName}
                        onChange={(e) => handleInputChange('contactPersonName', e.target.value)}
                        className={errors.contactPersonName ? 'border-red-500' : ''}
                      />
                      {errors.contactPersonName && <p className="text-sm text-red-500">{errors.contactPersonName}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="mobileNumber">Mobile Number *</Label>
                      <Input
                        id="mobileNumber"
                        placeholder="Enter 10-digit mobile number"
                        value={formData.mobileNumber}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '').slice(0, 10);
                          handleInputChange('mobileNumber', value);
                        }}
                        className={errors.mobileNumber ? 'border-red-500' : ''}
                      />
                      {errors.mobileNumber && <p className="text-sm text-red-500">{errors.mobileNumber}</p>}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="alternateNumber">Alternate Number</Label>
                      <Input
                        id="alternateNumber"
                        placeholder="Enter alternate number (optional)"
                        value={formData.alternateNumber}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '').slice(0, 10);
                          handleInputChange('alternateNumber', value);
                        }}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="emailId">Email ID *</Label>
                      <Input
                        id="emailId"
                        type="email"
                        placeholder="Enter email address"
                        value={formData.emailId}
                        onChange={(e) => handleInputChange('emailId', e.target.value)}
                        className={errors.emailId ? 'border-red-500' : ''}
                      />
                      {errors.emailId && <p className="text-sm text-red-500">{errors.emailId}</p>}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="fullAddress">Full Address *</Label>
                    <Textarea
                      id="fullAddress"
                      placeholder="Street, Area, Landmark"
                      value={formData.fullAddress}
                      onChange={(e) => handleInputChange('fullAddress', e.target.value)}
                      className={errors.fullAddress ? 'border-red-500' : ''}
                      rows={3}
                    />
                    {errors.fullAddress && <p className="text-sm text-red-500">{errors.fullAddress}</p>}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">City *</Label>
                      <Input
                        id="city"
                        placeholder="Enter city"
                        value={formData.city}
                        onChange={(e) => handleInputChange('city', e.target.value)}
                        className={errors.city ? 'border-red-500' : ''}
                      />
                      {errors.city && <p className="text-sm text-red-500">{errors.city}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="state">State *</Label>
                      <Select value={formData.state} onValueChange={(value) => handleInputChange('state', value)}>
                        <SelectTrigger className={errors.state ? 'border-red-500' : ''}>
                          <SelectValue placeholder="Select state" />
                        </SelectTrigger>
                        <SelectContent>
                          {statesList.map((state) => (
                            <SelectItem key={state} value={state}>
                              {state}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.state && <p className="text-sm text-red-500">{errors.state}</p>}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Financial & Tax Details */}
              {step === 2 && (
                <div className="space-y-4">
                  <Alert>
                    <CreditCard className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Important:</strong> Financial details are required for payment processing. PAN and GST are optional but recommended for business vendors.
                    </AlertDescription>
                  </Alert>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="panCardNumber">PAN Card Number</Label>
                      <Input
                        id="panCardNumber"
                        placeholder="e.g., ABCDE1234F (optional)"
                        value={formData.panCardNumber}
                        onChange={(e) => {
                          const value = e.target.value.toUpperCase().slice(0, 10);
                          handleInputChange('panCardNumber', value);
                        }}
                        className={errors.panCardNumber ? 'border-red-500' : ''}
                      />
                      {errors.panCardNumber && <p className="text-sm text-red-500">{errors.panCardNumber}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="gstinNumber">GSTIN Number</Label>
                      <Input
                        id="gstinNumber"
                        placeholder="15-digit GSTIN (optional)"
                        value={formData.gstinNumber}
                        onChange={(e) => {
                          const value = e.target.value.toUpperCase().slice(0, 15);
                          handleInputChange('gstinNumber', value);
                        }}
                        className={errors.gstinNumber ? 'border-red-500' : ''}
                      />
                      {errors.gstinNumber && <p className="text-sm text-red-500">{errors.gstinNumber}</p>}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bankAccountHolderName">Bank Account Holder Name *</Label>
                    <Input
                      id="bankAccountHolderName"
                      placeholder="Account holder name (as per bank records)"
                      value={formData.bankAccountHolderName}
                      onChange={(e) => handleInputChange('bankAccountHolderName', e.target.value)}
                      className={errors.bankAccountHolderName ? 'border-red-500' : ''}
                    />
                    {errors.bankAccountHolderName && <p className="text-sm text-red-500">{errors.bankAccountHolderName}</p>}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="bankName">Bank Name *</Label>
                      <Input
                        id="bankName"
                        placeholder="Enter bank name"
                        value={formData.bankName}
                        onChange={(e) => handleInputChange('bankName', e.target.value)}
                        className={errors.bankName ? 'border-red-500' : ''}
                      />
                      {errors.bankName && <p className="text-sm text-red-500">{errors.bankName}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="branchName">Branch Name</Label>
                      <Input
                        id="branchName"
                        placeholder="Branch name (optional)"
                        value={formData.branchName}
                        onChange={(e) => handleInputChange('branchName', e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="bankAccountNumber">Bank Account Number *</Label>
                      <Input
                        id="bankAccountNumber"
                        placeholder="Enter account number"
                        value={formData.bankAccountNumber}
                        onChange={(e) => handleInputChange('bankAccountNumber', e.target.value)}
                        className={errors.bankAccountNumber ? 'border-red-500' : ''}
                      />
                      {errors.bankAccountNumber && <p className="text-sm text-red-500">{errors.bankAccountNumber}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="ifscCode">IFSC Code *</Label>
                      <Input
                        id="ifscCode"
                        placeholder="Enter IFSC code"
                        value={formData.ifscCode}
                        onChange={(e) => {
                          const value = e.target.value.toUpperCase().slice(0, 11);
                          handleInputChange('ifscCode', value);
                        }}
                        className={errors.ifscCode ? 'border-red-500' : ''}
                      />
                      {errors.ifscCode && <p className="text-sm text-red-500">{errors.ifscCode}</p>}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="accountType">Account Type *</Label>
                    <Select value={formData.accountType} onValueChange={(value) => handleInputChange('accountType', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {accountTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}

              {/* Step 3: Contract & Document Details */}
              {step === 3 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Contract Start Date *</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={`w-full justify-start text-left font-normal ${
                              errors.contractStartDate ? 'border-red-500' : ''
                            }`}
                          >
                            <CalendarDays className="mr-2 h-4 w-4" />
                            {contractStartDate ? formatDate(contractStartDate) : "Select start date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={contractStartDate}
                            onSelect={setContractStartDate}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      {errors.contractStartDate && <p className="text-sm text-red-500">{errors.contractStartDate}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label>Contract End Date (Optional)</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-left font-normal"
                          >
                            <CalendarDays className="mr-2 h-4 w-4" />
                            {contractEndDate ? formatDate(contractEndDate) : "Select end date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={contractEndDate}
                            onSelect={setContractEndDate}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="paymentTerms">Payment Terms *</Label>
                    <Select value={formData.paymentTerms} onValueChange={(value) => handleInputChange('paymentTerms', value)}>
                      <SelectTrigger className={errors.paymentTerms ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Select payment terms" />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentTermsOptions.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.paymentTerms && <p className="text-sm text-red-500">{errors.paymentTerms}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Additional Notes</Label>
                    <Textarea
                      id="notes"
                      placeholder="Any additional information or special terms"
                      value={formData.notes}
                      onChange={(e) => handleInputChange('notes', e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="documents">Upload Documents</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                      <Upload className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="mt-4">
                        <Label htmlFor="file-upload" className="cursor-pointer">
                          <span className="mt-2 block text-sm font-medium text-gray-900">
                            Upload PAN, GST Certificate, Agreement, etc.
                          </span>
                          <Input
                            id="file-upload"
                            name="file-upload"
                            type="file"
                            className="sr-only"
                            multiple
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={handleFileUpload}
                          />
                        </Label>
                        <p className="mt-1 text-xs text-gray-500">
                          PDF, JPG, PNG up to 10MB each
                        </p>
                      </div>
                    </div>

                    {uploadedFiles.length > 0 && (
                      <div className="mt-4 space-y-2">
                        <Label>Uploaded Files:</Label>
                        {uploadedFiles.map((file, index) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span className="text-sm">{file.name}</span>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => removeFile(index)}
                            >
                              Remove
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Step 4: Type-specific Details */}
              {step === 4 && (
                <div className="space-y-4">
                  {renderTypeSpecificFields()}
                  {!formData.vendorType && (
                    <Alert>
                      <AlertDescription>
                        Please select a vendor type in Step 1 to see type-specific fields.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              )}

              {/* Navigation Buttons */}
              <div className="flex justify-between pt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    if (step > 1) {
                      setStep(step - 1);
                    } else {
                      resetForm();
                      setActiveTab('manage');
                    }
                  }}
                >
                  {step === 1 ? 'Cancel' : 'Previous'}
                </Button>

                <Button
                  type="button"
                  onClick={handleNext}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Submitting...' : step === 4 ? (editingVendor ? 'Update Vendor' : 'Register Vendor') : 'Next'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Management Tab */}
        <TabsContent value="manage" className="space-y-6">
          {/* Search and Filter Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Vendor Management
              </CardTitle>
              <CardDescription>
                Manage all registered vendors, search, filter, and update their status
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search vendors by name, contact person, or email..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-48">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      {vendorTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Vendors Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vendor Details</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Payment Terms</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredVendors.map((vendor) => {
                    const VendorIcon = getVendorTypeIcon(vendor.vendorType);
                    return (
                      <TableRow key={vendor.id}>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="font-medium">{vendor.vendorName}</div>
                            <div className="text-sm text-muted-foreground">
                              ID: {vendor.id}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              Contact: {vendor.contactPersonName}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <VendorIcon className="w-4 h-4" />
                            <span className="text-sm">{vendor.vendorType}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="flex items-center gap-1 text-sm">
                              <Phone className="w-3 h-3" />
                              {vendor.mobileNumber}
                            </div>
                            <div className="flex items-center gap-1 text-sm">
                              <Mail className="w-3 h-3" />
                              {vendor.emailId}
                            </div>
                            <div className="flex items-center gap-1 text-sm">
                              <MapPin className="w-3 h-3" />
                              {vendor.city}, {vendor.state}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="text-sm">{vendor.paymentTerms}</div>
                            <div className="text-xs text-muted-foreground">
                              Since: {formatDate(vendor.contractStartDate)}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <Switch
                                checked={vendor.status === 'active'}
                                onCheckedChange={() => handleStatusToggle(vendor.id)}
                              />
                              <Badge variant={vendor.status === 'active' ? 'default' : 'secondary'}>
                                {vendor.status}
                              </Badge>
                            </div>
                            <Badge 
                              variant={
                                vendor.approvalStatus === 'approved' ? 'default' : 
                                vendor.approvalStatus === 'rejected' ? 'destructive' : 'secondary'
                              }
                              className="text-xs"
                            >
                              {vendor.approvalStatus}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setViewingVendor(vendor)}
                                >
                                  <Eye className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                                <DialogHeader>
                                  <DialogTitle>Vendor Details</DialogTitle>
                                  <DialogDescription>
                                    Complete information for {vendor.vendorName}
                                  </DialogDescription>
                                </DialogHeader>
                                {viewingVendor && (
                                  <div className="space-y-6">
                                    <div className="grid grid-cols-2 gap-4">
                                      <div>
                                        <Label>Vendor Name</Label>
                                        <p className="text-sm">{viewingVendor.vendorName}</p>
                                      </div>
                                      <div>
                                        <Label>Vendor Type</Label>
                                        <p className="text-sm">{viewingVendor.vendorType}</p>
                                      </div>
                                      <div>
                                        <Label>Contact Person</Label>
                                        <p className="text-sm">{viewingVendor.contactPersonName}</p>
                                      </div>
                                      <div>
                                        <Label>Mobile Number</Label>
                                        <p className="text-sm">{viewingVendor.mobileNumber}</p>
                                      </div>
                                      <div>
                                        <Label>Email</Label>
                                        <p className="text-sm">{viewingVendor.emailId}</p>
                                      </div>
                                      <div>
                                        <Label>Status</Label>
                                        <Badge variant={viewingVendor.status === 'active' ? 'default' : 'secondary'}>
                                          {viewingVendor.status}
                                        </Badge>
                                      </div>
                                    </div>
                                    <div>
                                      <Label>Address</Label>
                                      <p className="text-sm">{viewingVendor.fullAddress}</p>
                                      <p className="text-sm">{viewingVendor.city}, {viewingVendor.state}</p>
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                      <div>
                                        <Label>Bank Details</Label>
                                        <div className="text-sm space-y-1">
                                          <p>{viewingVendor.bankName}</p>
                                          <p>A/c: {viewingVendor.bankAccountNumber}</p>
                                          <p>IFSC: {viewingVendor.ifscCode}</p>
                                          <p>Holder: {viewingVendor.bankAccountHolderName}</p>
                                        </div>
                                      </div>
                                      <div>
                                        <Label>Contract Details</Label>
                                        <div className="text-sm space-y-1">
                                          <p>Terms: {viewingVendor.paymentTerms}</p>
                                          <p>Start: {formatDate(viewingVendor.contractStartDate)}</p>
                                          {viewingVendor.contractEndDate && (
                                            <p>End: {formatDate(viewingVendor.contractEndDate)}</p>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                    {viewingVendor.specificFields && Object.keys(viewingVendor.specificFields).length > 0 && (
                                      <div>
                                        <Label>Type-specific Details</Label>
                                        <div className="text-sm space-y-1 bg-gray-50 p-3 rounded">
                                          {Object.entries(viewingVendor.specificFields).map(([key, value]) => (
                                            <p key={key}>
                                              <span className="font-medium">{key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:</span> {String(value)}
                                            </p>
                                          ))}
                                        </div>
                                      </div>
                                    )}
                                    {viewingVendor.notes && (
                                      <div>
                                        <Label>Notes</Label>
                                        <p className="text-sm">{viewingVendor.notes}</p>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </DialogContent>
                            </Dialog>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEdit(vendor)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              
              {filteredVendors.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  No vendors found matching your criteria.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Important Notice */}
      <Alert>
        <AlertDescription>
          <strong>Note:</strong> All vendor information is securely stored and managed according to data protection policies. 
          Vendor status changes are logged and require appropriate authorization levels for critical operations.
        </AlertDescription>
      </Alert>
    </div>
  );
}