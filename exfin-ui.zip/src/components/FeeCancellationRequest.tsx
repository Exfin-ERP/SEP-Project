import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { CalendarDays, Plus, Download, Printer, CheckCircle, Clock, X, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { Alert, AlertDescription } from "./ui/alert";
import { toast } from "sonner@2.0.3";
import { useAuth } from './AuthContext';

interface FeeCancellationRecord {
  id: string;
  requestNumber: string;
  studentName: string;
  studentId: string;
  course: string;
  year: string;
  campus: string;
  feeAmount: number;
  feeType: string;
  originalReceiptNumber: string;
  reasonForCancellation: string;
  requestDate: Date;
  academicYear: string;
  supportingDocuments?: string;
  remarks?: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Refunded';
  requestedBy: string;
  approvedBy?: string;
  refundAmount?: number;
}

const campusOptions = [
  'SONTYAM', 'THAGARAPUVALASA', 'BOYAPALEM', 'DAY SCHOOL',
  'SRIVEN BC-1', 'SRIVEN BC-2', 'SRIVEN DC-1', 'SRIVEN DC-2', 'SRIVEN GC-1',
  'SRIVEN LTG', 'SRIVEN LT SPARK', 'SRIVEN BC-4', 'SRIVEN SIVASIVANI'
];

const courses = ['B.Tech', 'MBA', 'BBA', 'B.Com', 'M.Tech', 'MCA', 'B.Sc', 'M.Sc', 'B.A', 'M.A'];
const years = ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year'];
const academicYears = ['2024-25', '2023-24', '2022-23', '2021-22'];
const feeTypes = ['Tuition Fee', 'Hostel Fee', 'Transport Fee', 'Exam Fee', 'Activity Fee', 'Library Fee', 'Lab Fee', 'ID Card Fee'];
const cancellationReasons = [
  'Course Withdrawal',
  'Medical Emergency',
  'Financial Hardship',
  'Transfer to Another Institution',
  'Duplicate Payment',
  'System Error',
  'Administrative Error',
  'Other'
];

const sampleRequests: FeeCancellationRecord[] = [
  {
    id: '1',
    requestNumber: 'CANCEL-2024-001',
    studentName: 'Ramesh Kumar',
    studentId: 'STU001',
    course: 'B.Tech',
    year: '2nd Year',
    campus: 'SRIVEN BC-1',
    feeAmount: 15000,
    feeType: 'Hostel Fee',
    originalReceiptNumber: 'TUITION-2024-156',
    reasonForCancellation: 'Medical Emergency',
    requestDate: new Date('2024-12-15'),
    academicYear: '2024-25',
    supportingDocuments: 'Medical Certificate, Doctor Report',
    remarks: 'Student hospitalized, unable to continue',
    status: 'Pending',
    requestedBy: 'Priya Sharma'
  },
  {
    id: '2',
    requestNumber: 'CANCEL-2024-002',
    studentName: 'Sita Reddy',
    studentId: 'STU002',
    course: 'MBA',
    year: '1st Year',
    campus: 'SRIVEN DC-1',
    feeAmount: 8500,
    feeType: 'Transport Fee',
    originalReceiptNumber: 'TRANSPORT-2024-089',
    reasonForCancellation: 'Transfer to Another Institution',
    requestDate: new Date('2024-12-14'),
    academicYear: '2024-25',
    supportingDocuments: 'Transfer Certificate, New College Admission Letter',
    status: 'Approved',
    requestedBy: 'Suresh Babu',
    approvedBy: 'Management',
    refundAmount: 7500
  }
];

export function FeeCancellationRequest() {
  const { user } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [requests] = useState<FeeCancellationRecord[]>(sampleRequests);
  
  const [formData, setFormData] = useState({
    studentName: '',
    studentId: '',
    course: '',
    year: '',
    campus: '',
    feeAmount: '',
    feeType: '',
    originalReceiptNumber: '',
    reasonForCancellation: '',
    academicYear: '2024-25',
    supportingDocuments: '',
    remarks: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const generateRequestNumber = () => {
    const year = new Date().getFullYear();
    const count = requests.length + 1;
    return `CANCEL-${year}-${count.toString().padStart(3, '0')}`;
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.studentName.trim()) newErrors.studentName = 'Student name is required';
    if (!formData.studentId.trim()) newErrors.studentId = 'Student ID is required';
    if (!formData.course) newErrors.course = 'Course is required';
    if (!formData.year) newErrors.year = 'Year is required';
    if (!formData.campus) newErrors.campus = 'Campus is required';
    if (!formData.feeType) newErrors.feeType = 'Fee type is required';
    if (!formData.originalReceiptNumber.trim()) newErrors.originalReceiptNumber = 'Original receipt number is required';
    if (!formData.reasonForCancellation) newErrors.reasonForCancellation = 'Reason for cancellation is required';
    
    const amount = parseFloat(formData.feeAmount);
    if (!formData.feeAmount || isNaN(amount) || amount <= 0) {
      newErrors.feeAmount = 'Valid fee amount is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast.success('Fee cancellation request submitted successfully!');
      
      setFormData({
        studentName: '',
        studentId: '',
        course: '',
        year: '',
        campus: '',
        feeAmount: '',
        feeType: '',
        originalReceiptNumber: '',
        reasonForCancellation: '',
        academicYear: '2024-25',
        supportingDocuments: '',
        remarks: ''
      });
      setSelectedDate(new Date());
      setShowForm(false);
    } catch (error) {
      toast.error('Failed to submit request. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const getStatusBadge = (status: FeeCancellationRecord['status']) => {
    switch (status) {
      case 'Pending':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'Approved':
        return <Badge variant="secondary" className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'Rejected':
        return <Badge variant="destructive"><X className="w-3 h-3 mr-1" />Rejected</Badge>;
      case 'Refunded':
        return <Badge variant="secondary" className="bg-blue-100 text-blue-800"><CheckCircle className="w-3 h-3 mr-1" />Refunded</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Fee Cancellation Request Form</h1>
          <p>Submit and manage fee cancellation requests for students</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus className="w-4 h-4" />
          {showForm ? 'Cancel' : 'New Cancellation Request'}
        </Button>
      </div>

      {/* Info Alert */}
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          All fee cancellation requests require proper documentation and management approval. Refund processing may take 7-15 business days.
        </AlertDescription>
      </Alert>

      {/* Request Form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Submit Fee Cancellation Request</CardTitle>
            <CardDescription>
              Fill in all details to submit a new cancellation request. Request Number: {generateRequestNumber()}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Student Information */}
              <div className="space-y-4">
                <h3>Student Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="studentName">Student Name *</Label>
                    <Input
                      id="studentName"
                      placeholder="Enter student name"
                      value={formData.studentName}
                      onChange={(e) => handleInputChange('studentName', e.target.value)}
                      className={errors.studentName ? 'border-red-500' : ''}
                    />
                    {errors.studentName && <p className="text-sm text-red-500">{errors.studentName}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="studentId">Student ID *</Label>
                    <Input
                      id="studentId"
                      placeholder="Enter student ID"
                      value={formData.studentId}
                      onChange={(e) => handleInputChange('studentId', e.target.value)}
                      className={errors.studentId ? 'border-red-500' : ''}
                    />
                    {errors.studentId && <p className="text-sm text-red-500">{errors.studentId}</p>}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="course">Course *</Label>
                    <Select onValueChange={(value) => handleInputChange('course', value)}>
                      <SelectTrigger className={errors.course ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Select course" />
                      </SelectTrigger>
                      <SelectContent>
                        {courses.map((course) => (
                          <SelectItem key={course} value={course}>
                            {course}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.course && <p className="text-sm text-red-500">{errors.course}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="year">Year *</Label>
                    <Select onValueChange={(value) => handleInputChange('year', value)}>
                      <SelectTrigger className={errors.year ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Select year" />
                      </SelectTrigger>
                      <SelectContent>
                        {years.map((year) => (
                          <SelectItem key={year} value={year}>
                            {year}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.year && <p className="text-sm text-red-500">{errors.year}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="campus">Campus *</Label>
                    <Select onValueChange={(value) => handleInputChange('campus', value)}>
                      <SelectTrigger className={errors.campus ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Select campus" />
                      </SelectTrigger>
                      <SelectContent>
                        {campusOptions.map((campus) => (
                          <SelectItem key={campus} value={campus}>
                            {campus}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.campus && <p className="text-sm text-red-500">{errors.campus}</p>}
                  </div>
                </div>
              </div>

              {/* Fee Information */}
              <div className="space-y-4">
                <h3>Fee Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="feeAmount">Fee Amount (₹) *</Label>
                    <Input
                      id="feeAmount"
                      type="number"
                      placeholder="Enter fee amount"
                      value={formData.feeAmount}
                      onChange={(e) => handleInputChange('feeAmount', e.target.value)}
                      className={errors.feeAmount ? 'border-red-500' : ''}
                    />
                    {errors.feeAmount && <p className="text-sm text-red-500">{errors.feeAmount}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="feeType">Fee Type *</Label>
                    <Select onValueChange={(value) => handleInputChange('feeType', value)}>
                      <SelectTrigger className={errors.feeType ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Select fee type" />
                      </SelectTrigger>
                      <SelectContent>
                        {feeTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.feeType && <p className="text-sm text-red-500">{errors.feeType}</p>}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="originalReceiptNumber">Original Receipt Number *</Label>
                    <Input
                      id="originalReceiptNumber"
                      placeholder="Enter receipt number"
                      value={formData.originalReceiptNumber}
                      onChange={(e) => handleInputChange('originalReceiptNumber', e.target.value)}
                      className={errors.originalReceiptNumber ? 'border-red-500' : ''}
                    />
                    {errors.originalReceiptNumber && <p className="text-sm text-red-500">{errors.originalReceiptNumber}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="academicYear">Academic Year</Label>
                    <Select value={formData.academicYear} onValueChange={(value) => handleInputChange('academicYear', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {academicYears.map((year) => (
                          <SelectItem key={year} value={year}>
                            {year}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Request Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left"
                        >
                          <CalendarDays className="mr-2 h-4 w-4" />
                          {format(selectedDate, "dd-MM-yyyy")}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={(date) => date && setSelectedDate(date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>

              {/* Cancellation Details */}
              <div className="space-y-4">
                <h3>Cancellation Details</h3>
                <div className="space-y-2">
                  <Label htmlFor="reasonForCancellation">Reason for Cancellation *</Label>
                  <Select onValueChange={(value) => handleInputChange('reasonForCancellation', value)}>
                    <SelectTrigger className={errors.reasonForCancellation ? 'border-red-500' : ''}>
                      <SelectValue placeholder="Select reason" />
                    </SelectTrigger>
                    <SelectContent>
                      {cancellationReasons.map((reason) => (
                        <SelectItem key={reason} value={reason}>
                          {reason}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.reasonForCancellation && <p className="text-sm text-red-500">{errors.reasonForCancellation}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="supportingDocuments">Supporting Documents</Label>
                  <Input
                    id="supportingDocuments"
                    placeholder="List any supporting documents (Medical certificate, Transfer letter, etc.)"
                    value={formData.supportingDocuments}
                    onChange={(e) => handleInputChange('supportingDocuments', e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="remarks">Additional Remarks</Label>
                  <Textarea
                    id="remarks"
                    placeholder="Any additional information or explanation..."
                    value={formData.remarks}
                    onChange={(e) => handleInputChange('remarks', e.target.value)}
                    rows={4}
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Submitting...' : 'Submit Request'}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Requests Table */}
      <Card>
        <CardHeader>
          <CardTitle>Fee Cancellation Requests</CardTitle>
          <CardDescription>
            Total Requests: {requests.length} | Total Amount Requested: ₹{requests.reduce((sum, r) => sum + r.feeAmount, 0).toLocaleString()}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Request No.</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Student Details</TableHead>
                  <TableHead>Fee Type</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {requests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell>{request.requestNumber}</TableCell>
                    <TableCell>{request.requestDate.toLocaleDateString('en-IN')}</TableCell>
                    <TableCell>
                      <div>
                        <div>{request.studentName}</div>
                        <div className="text-sm text-muted-foreground">{request.studentId}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{request.feeType}</TableCell>
                    <TableCell>₹{request.feeAmount.toLocaleString()}</TableCell>
                    <TableCell className="text-sm">{request.reasonForCancellation}</TableCell>
                    <TableCell>{getStatusBadge(request.status)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Printer className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}