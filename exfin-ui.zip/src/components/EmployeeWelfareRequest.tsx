import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "./ui/alert-dialog";
import { toast } from "sonner@2.0.3";
import { CalendarDays, FileText, Upload, Eye, CheckCircle, XCircle, Clock, User, Building, DollarSign, Heart, AlertTriangle, Download } from "lucide-react";
import { useAuth } from './AuthContext';

// Types for the welfare system
interface WelfareRequest {
  id: string;
  employeeName: string;
  employeeId: string;
  department: string;
  designation: string;
  requestType: 'Medical' | 'Financial Assistance' | 'Salary Advance' | 'Emergency' | 'Educational' | 'Family Support';
  amountRequested: number;
  purpose: string;
  description: string;
  dateOfRequest: string;
  status: 'Pending' | 'Under Review' | 'Approved' | 'Rejected';
  adminRemarks?: string;
  managementRemarks?: string;
  supportingDocuments: string[];
  repaymentTerms?: {
    installments: number;
    monthlyDeduction: number;
    startMonth: string;
    endMonth: string;
  };
  submittedBy: string;
  reviewedBy?: string;
  approvedBy?: string;
  dateReviewed?: string;
  dateApproved?: string;
  urgencyLevel: 'Low' | 'Medium' | 'High' | 'Critical';
}

// Sample data for demonstration
const sampleRequests: WelfareRequest[] = [
  {
    id: 'WR001',
    employeeName: 'Rajesh Kumar',
    employeeId: 'EMP001',
    department: 'Accounts Department',
    designation: 'Senior Accountant',
    requestType: 'Medical',
    amountRequested: 25000,
    purpose: 'Father\'s surgery expenses',
    description: 'My father needs urgent cardiac surgery. Required for hospital admission and procedure costs.',
    dateOfRequest: '2024-12-15',
    status: 'Under Review',
    adminRemarks: 'Documents verified, medical reports submitted',
    supportingDocuments: ['medical_reports.pdf', 'hospital_estimate.pdf'],
    submittedBy: 'Rajesh Kumar',
    reviewedBy: 'Admin',
    dateReviewed: '2024-12-16',
    urgencyLevel: 'High'
  },
  {
    id: 'WR002',
    employeeName: 'Priya Sharma',
    employeeId: 'EMP002',
    department: 'Teaching Staff',
    designation: 'Assistant Professor',
    requestType: 'Salary Advance',
    amountRequested: 50000,
    purpose: 'House down payment',
    description: 'Need advance salary for house purchase down payment',
    dateOfRequest: '2024-12-14',
    status: 'Pending',
    supportingDocuments: ['sale_agreement.pdf', 'bank_statement.pdf'],
    repaymentTerms: {
      installments: 10,
      monthlyDeduction: 5000,
      startMonth: 'January 2025',
      endMonth: 'October 2025'
    },
    submittedBy: 'Priya Sharma',
    urgencyLevel: 'Medium'
  },
  {
    id: 'WR003',
    employeeName: 'Suresh Babu',
    employeeId: 'EMP003',
    department: 'Administration',
    designation: 'Office Assistant',
    requestType: 'Emergency',
    amountRequested: 15000,
    purpose: 'Family emergency',
    description: 'Urgent financial assistance required due to family emergency',
    dateOfRequest: '2024-12-13',
    status: 'Approved',
    adminRemarks: 'Emergency verified, documents in order',
    managementRemarks: 'Approved for immediate processing',
    supportingDocuments: ['emergency_proof.pdf'],
    submittedBy: 'Suresh Babu',
    reviewedBy: 'Admin',
    approvedBy: 'Management',
    dateReviewed: '2024-12-13',
    dateApproved: '2024-12-14',
    urgencyLevel: 'Critical'
  }
];

// Helper functions for styling
const getStatusBadgeVariant = (status: WelfareRequest['status']): "default" | "secondary" | "destructive" | "outline" => {
  switch (status) {
    case 'Approved':
      return 'default';
    case 'Rejected':
      return 'destructive';
    case 'Under Review':
      return 'secondary';
    case 'Pending':
      return 'outline';
    default:
      return 'outline';
  }
};

const getUrgencyColor = (urgency: WelfareRequest['urgencyLevel']): string => {
  switch (urgency) {
    case 'Critical':
      return 'bg-red-100 text-red-800 hover:bg-red-200';
    case 'High':
      return 'bg-orange-100 text-orange-800 hover:bg-orange-200';
    case 'Medium':
      return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200';
    case 'Low':
      return 'bg-green-100 text-green-800 hover:bg-green-200';
    default:
      return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
  }
};

// Form component for new requests
function WelfareRequestForm({ onSubmit, onCancel }: { onSubmit: (request: Omit<WelfareRequest, 'id' | 'status' | 'dateOfRequest' | 'submittedBy'>) => void; onCancel: () => void }) {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    employeeName: user?.name || '',
    employeeId: '',
    department: '',
    designation: '',
    requestType: '' as WelfareRequest['requestType'] | '',
    amountRequested: '',
    purpose: '',
    description: '',
    urgencyLevel: 'Medium' as WelfareRequest['urgencyLevel'],
    supportingDocuments: [] as string[],
    repaymentTerms: {
      installments: '',
      monthlyDeduction: '',
      startMonth: '',
      endMonth: ''
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.employeeId || !formData.department || !formData.requestType || !formData.amountRequested) {
      toast.error('Please fill in all required fields');
      return;
    }

    const requestData: Omit<WelfareRequest, 'id' | 'status' | 'dateOfRequest' | 'submittedBy'> = {
      employeeName: formData.employeeName,
      employeeId: formData.employeeId,
      department: formData.department,
      designation: formData.designation,
      requestType: formData.requestType as WelfareRequest['requestType'],
      amountRequested: parseFloat(formData.amountRequested),
      purpose: formData.purpose,
      description: formData.description,
      urgencyLevel: formData.urgencyLevel,
      supportingDocuments: formData.supportingDocuments,
      ...(formData.requestType === 'Salary Advance' && formData.repaymentTerms.installments && {
        repaymentTerms: {
          installments: parseInt(formData.repaymentTerms.installments),
          monthlyDeduction: parseFloat(formData.repaymentTerms.monthlyDeduction),
          startMonth: formData.repaymentTerms.startMonth,
          endMonth: formData.repaymentTerms.endMonth
        }
      })
    };

    onSubmit(requestData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="employeeName">Employee Name *</Label>
          <Input
            id="employeeName"
            value={formData.employeeName}
            onChange={(e) => setFormData(prev => ({ ...prev, employeeName: e.target.value }))}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="employeeId">Employee ID *</Label>
          <Input
            id="employeeId"
            value={formData.employeeId}
            onChange={(e) => setFormData(prev => ({ ...prev, employeeId: e.target.value }))}
            placeholder="e.g., EMP001"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="department">Department *</Label>
          <Select onValueChange={(value) => setFormData(prev => ({ ...prev, department: value }))}>
            <SelectTrigger>
              <SelectValue placeholder="Select department" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Teaching Staff">Teaching Staff</SelectItem>
              <SelectItem value="Accounts Department">Accounts Department</SelectItem>
              <SelectItem value="Administration">Administration</SelectItem>
              <SelectItem value="IT Department">IT Department</SelectItem>
              <SelectItem value="Library">Library</SelectItem>
              <SelectItem value="Maintenance">Maintenance</SelectItem>
              <SelectItem value="Security">Security</SelectItem>
              <SelectItem value="Transport">Transport</SelectItem>
              <SelectItem value="Canteen">Canteen</SelectItem>
              <SelectItem value="Management">Management</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="designation">Designation</Label>
          <Input
            id="designation"
            value={formData.designation}
            onChange={(e) => setFormData(prev => ({ ...prev, designation: e.target.value }))}
            placeholder="e.g., Assistant Professor"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="requestType">Type of Welfare Request *</Label>
          <Select onValueChange={(value) => setFormData(prev => ({ ...prev, requestType: value as WelfareRequest['requestType'] }))}>
            <SelectTrigger>
              <SelectValue placeholder="Select request type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Medical">Medical</SelectItem>
              <SelectItem value="Financial Assistance">Financial Assistance</SelectItem>
              <SelectItem value="Salary Advance">Salary Advance</SelectItem>
              <SelectItem value="Emergency">Emergency</SelectItem>
              <SelectItem value="Educational">Educational</SelectItem>
              <SelectItem value="Family Support">Family Support</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="urgencyLevel">Urgency Level</Label>
          <Select 
            value={formData.urgencyLevel} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, urgencyLevel: value as WelfareRequest['urgencyLevel'] }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Low">Low</SelectItem>
              <SelectItem value="Medium">Medium</SelectItem>
              <SelectItem value="High">High</SelectItem>
              <SelectItem value="Critical">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="amountRequested">Amount Requested (₹) *</Label>
          <Input
            id="amountRequested"
            type="number"
            value={formData.amountRequested}
            onChange={(e) => setFormData(prev => ({ ...prev, amountRequested: e.target.value }))}
            placeholder="Enter amount"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="purpose">Purpose *</Label>
          <Input
            id="purpose"
            value={formData.purpose}
            onChange={(e) => setFormData(prev => ({ ...prev, purpose: e.target.value }))}
            placeholder="Brief purpose of request"
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Detailed Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Provide detailed information about your request"
          rows={4}
        />
      </div>

      {/* Salary Advance specific fields */}
      {formData.requestType === 'Salary Advance' && (
        <Card>
          <CardHeader>
            <CardTitle>Repayment Terms</CardTitle>
            <CardDescription>Please specify how you would like to repay the advance</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="installments">Number of Installments</Label>
                <Input
                  id="installments"
                  type="number"
                  value={formData.repaymentTerms.installments}
                  onChange={(e) => {
                    const installments = e.target.value;
                    const amount = parseFloat(formData.amountRequested) || 0;
                    const monthlyDeduction = installments ? (amount / parseInt(installments)).toFixed(2) : '';
                    
                    setFormData(prev => ({
                      ...prev,
                      repaymentTerms: {
                        ...prev.repaymentTerms,
                        installments,
                        monthlyDeduction
                      }
                    }));
                  }}
                  placeholder="e.g., 10"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="monthlyDeduction">Monthly Deduction (₹)</Label>
                <Input
                  id="monthlyDeduction"
                  type="number"
                  value={formData.repaymentTerms.monthlyDeduction}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    repaymentTerms: { ...prev.repaymentTerms, monthlyDeduction: e.target.value }
                  }))}
                  placeholder="Auto-calculated"
                  readOnly
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="startMonth">Recovery Start Month</Label>
                <Input
                  id="startMonth"
                  type="month"
                  value={formData.repaymentTerms.startMonth}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    repaymentTerms: { ...prev.repaymentTerms, startMonth: e.target.value }
                  }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="endMonth">Recovery End Month</Label>
                <Input
                  id="endMonth"
                  type="month"
                  value={formData.repaymentTerms.endMonth}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    repaymentTerms: { ...prev.repaymentTerms, endMonth: e.target.value }
                  }))}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Document Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle>Supporting Documents</CardTitle>
          <CardDescription>Upload relevant documents to support your request</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
              <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-muted-foreground">Click to upload or drag and drop</p>
              <p className="text-muted-foreground">PDF, DOC, or image files (max 10MB)</p>
              <Button type="button" variant="outline" className="mt-2">
                Choose Files
              </Button>
            </div>
            
            {formData.supportingDocuments.length > 0 && (
              <div className="space-y-2">
                <Label>Uploaded Documents:</Label>
                {formData.supportingDocuments.map((doc, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                    <span>{doc}</span>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setFormData(prev => ({
                        ...prev,
                        supportingDocuments: prev.supportingDocuments.filter((_, i) => i !== index)
                      }))}
                    >
                      Remove
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-4 pt-4">
        <Button type="submit" className="flex-1">
          Submit Request
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}

// Request details modal
function RequestDetailsModal({ request, onClose, onApprove, onReject, userRole }: {
  request: WelfareRequest;
  onClose: () => void;
  onApprove?: (remarks: string) => void;
  onReject?: (remarks: string) => void;
  userRole: string;
}) {
  const [remarks, setRemarks] = useState('');
  const [showApprovalDialog, setShowApprovalDialog] = useState<'approve' | 'reject' | null>(null);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'Under Review': return <Eye className="w-4 h-4 text-blue-500" />;
      case 'Approved': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'Rejected': return <XCircle className="w-4 h-4 text-red-500" />;
      default: return null;
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'Low': return 'bg-green-100 text-green-800';
      case 'Medium': return 'bg-yellow-100 text-yellow-800';
      case 'High': return 'bg-orange-100 text-orange-800';
      case 'Critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Heart className="w-5 h-5" />
          Welfare Request Details - {request.id}
        </DialogTitle>
        <DialogDescription>
          Review and manage employee welfare request
        </DialogDescription>
      </DialogHeader>

      <div className="space-y-6">
        {/* Status and Urgency */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            {getStatusIcon(request.status)}
            <Badge variant="outline">{request.status}</Badge>
          </div>
          <Badge className={getUrgencyColor(request.urgencyLevel)}>
            {request.urgencyLevel} Priority
          </Badge>
        </div>

        {/* Employee Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Employee Information
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Employee Name</Label>
              <p>{request.employeeName}</p>
            </div>
            <div>
              <Label>Employee ID</Label>
              <p>{request.employeeId}</p>
            </div>
            <div>
              <Label>Department</Label>
              <p>{request.department}</p>
            </div>
            <div>
              <Label>Designation</Label>
              <p>{request.designation}</p>
            </div>
          </CardContent>
        </Card>

        {/* Request Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Request Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Request Type</Label>
                <p>{request.requestType}</p>
              </div>
              <div>
                <Label>Amount Requested</Label>
                <p className="flex items-center gap-1">
                  <DollarSign className="w-4 h-4" />
                  ₹{request.amountRequested.toLocaleString()}
                </p>
              </div>
              <div>
                <Label>Purpose</Label>
                <p>{request.purpose}</p>
              </div>
              <div>
                <Label>Date of Request</Label>
                <p className="flex items-center gap-1">
                  <CalendarDays className="w-4 h-4" />
                  {new Date(request.dateOfRequest).toLocaleDateString()}
                </p>
              </div>
            </div>
            
            <div>
              <Label>Description</Label>
              <p className="mt-1">{request.description}</p>
            </div>
          </CardContent>
        </Card>

        {/* Repayment Terms for Salary Advance */}
        {request.requestType === 'Salary Advance' && request.repaymentTerms && (
          <Card>
            <CardHeader>
              <CardTitle>Repayment Terms</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Number of Installments</Label>
                <p>{request.repaymentTerms.installments}</p>
              </div>
              <div>
                <Label>Monthly Deduction</Label>
                <p>₹{request.repaymentTerms.monthlyDeduction.toLocaleString()}</p>
              </div>
              <div>
                <Label>Recovery Period</Label>
                <p>{request.repaymentTerms.startMonth} to {request.repaymentTerms.endMonth}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Supporting Documents */}
        {request.supportingDocuments.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Supporting Documents</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {request.supportingDocuments.map((doc, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      {doc}
                    </span>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-1" />
                      Download
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Review History */}
        <Card>
          <CardHeader>
            <CardTitle>Review History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="border-l-4 border-blue-500 pl-4">
                <p className="font-medium">Request Submitted</p>
                <p className="text-muted-foreground">By {request.submittedBy} on {new Date(request.dateOfRequest).toLocaleDateString()}</p>
              </div>

              {request.reviewedBy && request.dateReviewed && (
                <div className="border-l-4 border-yellow-500 pl-4">
                  <p className="font-medium">Reviewed by Admin</p>
                  <p className="text-muted-foreground">By {request.reviewedBy} on {new Date(request.dateReviewed).toLocaleDateString()}</p>
                  {request.adminRemarks && <p className="mt-1">{request.adminRemarks}</p>}
                </div>
              )}

              {request.approvedBy && request.dateApproved && (
                <div className={`border-l-4 ${request.status === 'Approved' ? 'border-green-500' : 'border-red-500'} pl-4`}>
                  <p className="font-medium">{request.status} by Management</p>
                  <p className="text-muted-foreground">By {request.approvedBy} on {new Date(request.dateApproved).toLocaleDateString()}</p>
                  {request.managementRemarks && <p className="mt-1">{request.managementRemarks}</p>}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons for Admin/Management */}
        {((userRole === 'Admin' && request.status === 'Pending') || 
          (userRole === 'Management' && request.status === 'Under Review')) && (
          <div className="flex gap-4 pt-4 border-t">
            <AlertDialog open={showApprovalDialog === 'approve'} onOpenChange={() => setShowApprovalDialog(null)}>
              <AlertDialogTrigger asChild>
                <Button onClick={() => setShowApprovalDialog('approve')} className="flex-1">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Approve
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Approve Request</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to approve this welfare request?
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <div className="my-4">
                  <Label htmlFor="approveRemarks">Approval Remarks</Label>
                  <Textarea
                    id="approveRemarks"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="Add approval remarks..."
                    rows={3}
                  />
                </div>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => {
                      onApprove?.(remarks);
                      setShowApprovalDialog(null);
                      setRemarks('');
                    }}
                  >
                    Approve
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

            <AlertDialog open={showApprovalDialog === 'reject'} onOpenChange={() => setShowApprovalDialog(null)}>
              <AlertDialogTrigger asChild>
                <Button variant="outline" onClick={() => setShowApprovalDialog('reject')} className="flex-1">
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Reject Request</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to reject this welfare request? Please provide a reason.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <div className="my-4">
                  <Label htmlFor="rejectRemarks">Rejection Reason *</Label>
                  <Textarea
                    id="rejectRemarks"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="Please provide a reason for rejection..."
                    rows={3}
                    required
                  />
                </div>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => {
                      if (!remarks.trim()) {
                        toast.error('Please provide a reason for rejection');
                        return;
                      }
                      onReject?.(remarks);
                      setShowApprovalDialog(null);
                      setRemarks('');
                    }}
                  >
                    Reject
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        )}
      </div>
    </DialogContent>
  );
}

// Main Employee Welfare component
export function EmployeeWelfareRequest() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('requests');
  const [requests, setRequests] = useState<WelfareRequest[]>(sampleRequests);
  const [selectedRequest, setSelectedRequest] = useState<WelfareRequest | null>(null);
  const [showNewRequestForm, setShowNewRequestForm] = useState(false);

  // Filter requests based on user role
  const getFilteredRequests = () => {
    if (user?.role === 'Admin') {
      return requests; // Admin can see all requests
    } else if (user?.role === 'Management') {
      return requests.filter(req => req.status === 'Under Review' || req.status === 'Approved' || req.status === 'Rejected');
    } else {
      // Regular users see only their own requests
      return requests.filter(req => req.submittedBy === user?.name);
    }
  };

  const handleNewRequest = (requestData: Omit<WelfareRequest, 'id' | 'status' | 'dateOfRequest' | 'submittedBy'>) => {
    const newRequest: WelfareRequest = {
      ...requestData,
      id: `WR${(requests.length + 1).toString().padStart(3, '0')}`,
      status: 'Pending',
      dateOfRequest: new Date().toISOString().split('T')[0],
      submittedBy: user?.name || 'Unknown User'
    };

    setRequests(prev => [newRequest, ...prev]);
    setShowNewRequestForm(false);
    toast.success('Welfare request submitted successfully');
  };

  const handleApproveRequest = (requestId: string, remarks: string) => {
    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const updatedReq = { ...req };
        
        if (user?.role === 'Admin') {
          updatedReq.status = 'Under Review';
          updatedReq.adminRemarks = remarks;
          updatedReq.reviewedBy = user.name;
          updatedReq.dateReviewed = new Date().toISOString().split('T')[0];
        } else if (user?.role === 'Management') {
          updatedReq.status = 'Approved';
          updatedReq.managementRemarks = remarks;
          updatedReq.approvedBy = user.name;
          updatedReq.dateApproved = new Date().toISOString().split('T')[0];
        }
        
        return updatedReq;
      }
      return req;
    }));

    setSelectedRequest(null);
    toast.success(user?.role === 'Admin' ? 'Request forwarded to Management' : 'Request approved successfully');
  };

  const handleRejectRequest = (requestId: string, remarks: string) => {
    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const updatedReq = { ...req, status: 'Rejected' as const };
        
        if (user?.role === 'Admin') {
          updatedReq.adminRemarks = remarks;
          updatedReq.reviewedBy = user?.name;
          updatedReq.dateReviewed = new Date().toISOString().split('T')[0];
        } else if (user?.role === 'Management') {
          updatedReq.managementRemarks = remarks;
          updatedReq.approvedBy = user?.name;
          updatedReq.dateApproved = new Date().toISOString().split('T')[0];
        }
        
        return updatedReq;
      }
      return req;
    }));

    setSelectedRequest(null);
    toast.success('Request rejected');
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'Pending': return 'secondary';
      case 'Under Review': return 'default';
      case 'Approved': return 'default';
      case 'Rejected': return 'destructive';
      default: return 'secondary';
    }
  };

  const filteredRequests = getFilteredRequests();

  // Quick stats for dashboard
  const stats = {
    total: filteredRequests.length,
    pending: filteredRequests.filter(req => req.status === 'Pending').length,
    underReview: filteredRequests.filter(req => req.status === 'Under Review').length,
    approved: filteredRequests.filter(req => req.status === 'Approved').length,
    rejected: filteredRequests.filter(req => req.status === 'Rejected').length,
    totalAmount: filteredRequests
      .filter(req => req.status === 'Approved')
      .reduce((sum, req) => sum + req.amountRequested, 0)
  };

  if (showNewRequestForm) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1>New Welfare Request</h1>
            <p>Submit a new employee welfare request for review and approval</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Employee Welfare Request Form</CardTitle>
            <CardDescription>
              Please fill out all required information. Your request will be reviewed by the admin team and forwarded to management for approval.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <WelfareRequestForm
              onSubmit={handleNewRequest}
              onCancel={() => setShowNewRequestForm(false)}
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Employee Welfare Management</h1>
          <p>Manage employee welfare requests, medical assistance, and salary advances</p>
        </div>
        {(user?.role === 'Accountant' || user?.role === 'Management' || user?.role === 'Admin') && (
          <Button onClick={() => setShowNewRequestForm(true)}>
            <Heart className="w-4 h-4 mr-2" />
            New Request
          </Button>
        )}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Total Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Pending</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-yellow-600">{stats.pending}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Under Review</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-blue-600">{stats.underReview}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Approved</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-green-600">{stats.approved}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Rejected</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-red-600">{stats.rejected}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Total Approved Amount</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">₹{stats.totalAmount.toLocaleString()}</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="requests">All Requests</TabsTrigger>
          {user?.role === 'Admin' && <TabsTrigger value="pending">Pending Review</TabsTrigger>}
          {user?.role === 'Management' && <TabsTrigger value="approval">For Approval</TabsTrigger>}
        </TabsList>

        <TabsContent value="requests" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Welfare Requests</CardTitle>
              <CardDescription>
                {user?.role === 'Admin' ? 'All employee welfare requests' : 
                 user?.role === 'Management' ? 'Requests requiring your attention' : 
                 'Your welfare requests'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Request ID</TableHead>
                      <TableHead>Employee</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Urgency</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRequests.map((request) => (
                      <TableRow key={request.id}>
                        <TableCell>{request.id}</TableCell>
                        <TableCell>
                          <div>
                            <p>{request.employeeName}</p>
                            <p className="text-muted-foreground">{request.employeeId}</p>
                          </div>
                        </TableCell>
                        <TableCell>{request.requestType}</TableCell>
                        <TableCell>₹{request.amountRequested.toLocaleString()}</TableCell>
                        <TableCell>{new Date(request.dateOfRequest).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Badge variant={getStatusBadgeVariant(request.status)}>
                            {request.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={getUrgencyColor(request.urgencyLevel)}>
                            {request.urgencyLevel}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Dialog 
                            open={selectedRequest?.id === request.id} 
                            onOpenChange={(open) => setSelectedRequest(open ? request : null)}
                          >
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <Eye className="w-4 h-4 mr-1" />
                                View
                              </Button>
                            </DialogTrigger>
                            <RequestDetailsModal
                              request={request}
                              onClose={() => setSelectedRequest(null)}
                              onApprove={(remarks) => handleApproveRequest(request.id, remarks)}
                              onReject={(remarks) => handleRejectRequest(request.id, remarks)}
                              userRole={user?.role || ''}
                            />
                          </Dialog>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                {filteredRequests.length === 0 && (
                  <div className="text-center py-8">
                    <Heart className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">No welfare requests found</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {user?.role === 'Admin' && (
          <TabsContent value="pending" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Pending Admin Review</CardTitle>
                <CardDescription>Requests waiting for your review and verification</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Request ID</TableHead>
                        <TableHead>Employee</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Urgency</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredRequests.filter(req => req.status === 'Pending').map((request) => (
                        <TableRow key={request.id}>
                          <TableCell>{request.id}</TableCell>
                          <TableCell>
                            <div>
                              <p>{request.employeeName}</p>
                              <p className="text-muted-foreground">{request.department}</p>
                            </div>
                          </TableCell>
                          <TableCell>{request.requestType}</TableCell>
                          <TableCell>₹{request.amountRequested.toLocaleString()}</TableCell>
                          <TableCell>
                            <Badge className={getUrgencyColor(request.urgencyLevel)}>
                              {request.urgencyLevel}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Dialog 
                              open={selectedRequest?.id === request.id} 
                              onOpenChange={(open) => setSelectedRequest(open ? request : null)}
                            >
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <Eye className="w-4 h-4 mr-1" />
                                  Review
                                </Button>
                              </DialogTrigger>
                              <RequestDetailsModal
                                request={request}
                                onClose={() => setSelectedRequest(null)}
                                onApprove={(remarks) => handleApproveRequest(request.id, remarks)}
                                onReject={(remarks) => handleRejectRequest(request.id, remarks)}
                                userRole={user?.role || ''}
                              />
                            </Dialog>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {user?.role === 'Management' && (
          <TabsContent value="approval" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Requests for Management Approval</CardTitle>
                <CardDescription>Requests reviewed by admin and requiring your final approval</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Request ID</TableHead>
                        <TableHead>Employee</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Admin Review</TableHead>
                        <TableHead>Urgency</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredRequests.filter(req => req.status === 'Under Review').map((request) => (
                        <TableRow key={request.id}>
                          <TableCell>{request.id}</TableCell>
                          <TableCell>
                            <div>
                              <p>{request.employeeName}</p>
                              <p className="text-muted-foreground">{request.department}</p>
                            </div>
                          </TableCell>
                          <TableCell>{request.requestType}</TableCell>
                          <TableCell>₹{request.amountRequested.toLocaleString()}</TableCell>
                          <TableCell>
                            <div>
                              <p className="text-muted-foreground">Reviewed by {request.reviewedBy}</p>
                              {request.adminRemarks && (
                                <p className="text-sm">{request.adminRemarks}</p>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={getUrgencyColor(request.urgencyLevel)}>
                              {request.urgencyLevel}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Dialog 
                              open={selectedRequest?.id === request.id} 
                              onOpenChange={(open) => setSelectedRequest(open ? request : null)}
                            >
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <Eye className="w-4 h-4 mr-1" />
                                  Approve
                                </Button>
                              </DialogTrigger>
                              <RequestDetailsModal
                                request={request}
                                onClose={() => setSelectedRequest(null)}
                                onApprove={(remarks) => handleApproveRequest(request.id, remarks)}
                                onReject={(remarks) => handleRejectRequest(request.id, remarks)}
                                userRole={user?.role || ''}
                              />
                            </Dialog>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}