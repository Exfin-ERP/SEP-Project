import image_f68c1a989952b7d595b5240d001cf19fbcd31fed from 'figma:asset/f68c1a989952b7d595b5240d001cf19fbcd31fed.png';
import image_f68c1a989952b7d595b5240d001cf19fbcd31fed from 'figma:asset/f68c1a989952b7d595b5240d001cf19fbcd31fed.png';
import image_f68c1a989952b7d595b5240d001cf19fbcd31fed from 'figma:asset/f68c1a989952b7d595b5240d001cf19fbcd31fed.png';
import image_cbafc077315f74d3d7b2719d69861c274904f1bd from 'figma:asset/cbafc077315f74d3d7b2719d69861c274904f1bd.png';
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Alert, AlertDescription } from "./ui/alert";
import { Badge } from "./ui/badge";
import { Loader2, Mail, Phone, Shield, Building } from 'lucide-react';
import { useAuth, type UserRole, type Organization } from './AuthContext';
import { toast } from "sonner@2.0.3";
import { ImageWithFallback } from './figma/ImageWithFallback';

export function LoginPage() {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [loginMethod, setLoginMethod] = useState<'email' | 'phone'>('email');
  const [role, setRole] = useState<UserRole>('Accountant');
  const [organization, setOrganization] = useState<Organization>();
  const [error, setError] = useState('');
  const { login, isLoading } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const credential = loginMethod === 'email' ? email : phone;
    
    if (!credential.trim()) {
      setError(`Please enter your ${loginMethod}`);
      return;
    }

    if (loginMethod === 'email' && !credential.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }

    if (loginMethod === 'phone' && credential.length < 10) {
      setError('Please enter a valid phone number');
      return;
    }

    if (role === 'Admin' && !organization) {
      setError('Please select an organization for Admin access');
      return;
    }

    try {
      if (loginMethod === 'email') {
        await login(credential, undefined, role, organization);
      } else {
        await login('', credential, role, organization);
      }
      toast.success('OTP sent successfully!');
    } catch (error) {
      setError('Failed to send OTP. Please try again.');
      toast.error('Failed to send OTP');
    }
  };

  const getRoleDescription = (selectedRole: UserRole) => {
    switch (selectedRole) {
      case 'Admin': return 'Full system access with organization management';
      case 'Management': return 'View and manage financial reports and analytics';
      case 'Accountant': return 'Create and manage expense transactions';
      case 'Viewer': return 'View-only access to financial data';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        {/* Logo/Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <ImageWithFallback 
              src={image_f68c1a989952b7d595b5240d001cf19fbcd31fed}
              alt="Sri Venkateswara Enterprises Logo"
              className="w-24 h-24 object-contain"
            />
          </div>
          <h2 className="mb-1">SRI VENKATESWARA ENTERPRISES</h2>
          <p className="text-muted-foreground">EDUCATIONAL SOCIETY</p>
        </div>

        <Card>
          <CardHeader className="space-y-1 text-center">
            <CardTitle>Welcome Back</CardTitle>
            <CardDescription>
              Enter your credentials to access Sri Venkateswara Enterprises
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Role Selection */}
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Select Your Role
                </Label>
                <Select value={role} onValueChange={(value: UserRole) => setRole(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Admin">
                      <div className="flex items-center justify-between w-full">
                        <span>Admin</span>
                        <Badge className="ml-2 bg-red-100 text-red-800">Full Access</Badge>
                      </div>
                    </SelectItem>
                    <SelectItem value="Management">
                      <div className="flex items-center justify-between w-full">
                        <span>Management</span>
                        <Badge className="ml-2 bg-blue-100 text-blue-800">Reports</Badge>
                      </div>
                    </SelectItem>
                    <SelectItem value="Accountant">
                      <div className="flex items-center justify-between w-full">
                        <span>Accountant</span>
                        <Badge className="ml-2 bg-green-100 text-green-800">Transactions</Badge>
                      </div>
                    </SelectItem>
                    <SelectItem value="Viewer">
                      <div className="flex items-center justify-between w-full">
                        <span>Viewer</span>
                        <Badge className="ml-2 bg-gray-100 text-gray-800">Read Only</Badge>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground">
                  {getRoleDescription(role)}
                </p>
              </div>

              {/* Organization Selection (Admin only) */}
              {role === 'Admin' && (
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Building className="w-4 h-4" />
                    Select Organization
                  </Label>
                  <Select value={organization} onValueChange={(value: Organization) => setOrganization(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose an organization" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pragyana Educational Society">
                        Pragyana Educational Society
                      </SelectItem>
                      <SelectItem value="Sriven Educational Society">
                        Sriven Educational Society
                      </SelectItem>
                      <SelectItem value="Sri Venkateswara Enterprises">
                        Sri Venkateswara Enterprises
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-muted-foreground">
                    Select the organization you want to manage
                  </p>
                </div>
              )}

              <Tabs value={loginMethod} onValueChange={(value) => setLoginMethod(value as 'email' | 'phone')}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="email" className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email
                  </TabsTrigger>
                  <TabsTrigger value="phone" className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Phone
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="email" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={isLoading}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="phone" className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+91 98765 43210"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      disabled={isLoading}
                    />
                  </div>
                </TabsContent>
              </Tabs>

              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button 
                type="submit" 
                className="w-full bg-blue-600 hover:bg-blue-700" 
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sending OTP...
                  </>
                ) : (
                  'Send OTP'
                )}
              </Button>
            </form>

            <div className="mt-4 text-center">
              <a href="#" className="text-blue-600 hover:text-blue-700 text-sm">
                Forgot password?
              </a>
            </div>

            <div className="mt-6 text-center text-sm text-gray-500">
              <p>An OTP will be sent to your {loginMethod} for verification</p>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>© 2024 Sri Venkateswara Enterprises. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}