import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Alert, AlertDescription, AlertTitle } from "./ui/alert";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { AlertTriangle, CheckCircle, Upload, FileText } from "lucide-react";
import { toast } from "sonner@2.0.3";
import { useAuth } from './AuthContext';

interface FormData {
  category_id: string;
  amount: string;
  description: string;
  payment_mode: 'CASH' | 'ONLINE' | 'CHEQUE' | 'UPI' | 'CARD' | '';
  transaction_date: string;
  campus: string;
  bill_number: string;
  notes: string;
}

const categories = [
  { id: 'cat_001', name: 'Advances', budget_limit: 500000, current_spent: 85000 },
  { id: 'cat_002', name: 'Electricity', budget_limit: 100000, current_spent: 45000 },
  { id: 'cat_003', name: 'Rentals', budget_limit: 200000, current_spent: 120000 },
  { id: 'cat_004', name: 'Loans', budget_limit: 300000, current_spent: 95000 },
  { id: 'cat_005', name: 'EMIs', budget_limit: 150000, current_spent: 78000 },
  { id: 'cat_006', name: 'Fuel', budget_limit: 80000, current_spent: 52000 },
  { id: 'cat_007', name: 'Miscellaneous', budget_limit: 100000, current_spent: 38000 }
];

export function RealTimeExpenseForm({ onSave, onCancel, expense }: {
  onSave: () => void;
  onCancel: () => void;
  expense?: any;
}) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formErrors, setFormErrors] = useState<string[]>([]);
  
  const [formData, setFormData] = useState<FormData>({
    category_id: expense?.category_id || '',
    amount: expense?.amount?.toString() || '',
    description: expense?.description || '',
    payment_mode: expense?.payment_mode || '',
    transaction_date: expense?.transaction_date?.split('T')[0] || new Date().toISOString().split('T')[0],
    campus: expense?.campus || '',
    bill_number: expense?.bill_number || '',
    notes: expense?.notes || ''
  });

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Calculate budget status
  const getBudgetStatus = () => {
    if (!formData.category_id || !formData.amount) return null;
    
    const category = categories.find(c => c.id === formData.category_id);
    const amount = parseFloat(formData.amount);
    
    if (!category || isNaN(amount)) return null;
    
    const newTotal = category.current_spent + amount;
    const percentage = (newTotal / category.budget_limit) * 100;
    
    let status: 'SAFE' | 'WARNING' | 'DANGER';
    if (percentage >= 100) {
      status = 'DANGER';
    } else if (percentage >= 80) {
      status = 'WARNING';
    } else {
      status = 'SAFE';
    }
    
    return {
      category,
      newTotal,
      percentage,
      status,
      remaining: Math.max(0, category.budget_limit - newTotal)
    };
  };

  const budgetStatus = getBudgetStatus();

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setFormErrors([]);

    try {
      // Validate form data
      const errors: string[] = [];
      
      if (!formData.amount || parseFloat(formData.amount) <= 0) {
        errors.push('Amount must be greater than zero');
      }
      if (!formData.category_id) {
        errors.push('Category is required');
      }
      if (!formData.description || formData.description.trim().length === 0) {
        errors.push('Description is required');
      }
      if (!formData.payment_mode) {
        errors.push('Payment mode is required');
      }
      if (!formData.transaction_date) {
        errors.push('Transaction date is required');
      }

      if (errors.length > 0) {
        setFormErrors(errors);
        setLoading(false);
        return;
      }

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));

      toast.success(expense ? 'Transaction updated successfully' : 'Transaction created successfully');
      onSave();
    } catch (error) {
      console.error('Error saving transaction:', error);
      toast.error('Failed to save transaction');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1>{expense ? 'Edit Transaction' : 'Book New Expenditure'}</h1>
        <p>Create a new transaction entry with real-time budget validation</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Transaction Details</CardTitle>
          <CardDescription>
            Fill in the transaction information. Budget impact will be calculated automatically.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Form Errors */}
          {formErrors.length > 0 && (
            <Alert className="mb-6">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Please fix the following errors:</AlertTitle>
              <AlertDescription>
                <ul className="list-disc list-inside">
                  {formErrors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Category Selection */}
              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select 
                  value={formData.category_id} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, category_id: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        <div className="flex items-center justify-between w-full">
                          <span>{category.name}</span>
                          <Badge variant="outline" className="ml-2">
                            {((category.current_spent / category.budget_limit) * 100).toFixed(0)}%
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Amount */}
              <div className="space-y-2">
                <Label htmlFor="amount">Amount (₹) *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                  placeholder="Enter amount"
                  required
                />
              </div>

              {/* Payment Mode */}
              <div className="space-y-2">
                <Label htmlFor="paymentMode">Payment Mode *</Label>
                <Select 
                  value={formData.payment_mode} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, payment_mode: value as any }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment mode" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CASH">💵 Cash</SelectItem>
                    <SelectItem value="ONLINE">💳 Online Transfer</SelectItem>
                    <SelectItem value="CHEQUE">📝 Cheque</SelectItem>
                    <SelectItem value="UPI">📱 UPI</SelectItem>
                    <SelectItem value="CARD">💳 Card</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Transaction Date */}
              <div className="space-y-2">
                <Label htmlFor="date">Transaction Date *</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.transaction_date}
                  onChange={(e) => setFormData(prev => ({ ...prev, transaction_date: e.target.value }))}
                  required
                />
              </div>

              {/* Campus */}
              <div className="space-y-2">
                <Label htmlFor="campus">Campus/Branch</Label>
                <Select 
                  value={formData.campus} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, campus: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select campus" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SRIVEN BC-1">SRIVEN BC-1</SelectItem>
                    <SelectItem value="SRIVEN DC-1">SRIVEN DC-1</SelectItem>
                    <SelectItem value="SONTYAM">SONTYAM</SelectItem>
                    <SelectItem value="CENTRAL OFFICE">Central Office</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Bill Number */}
              <div className="space-y-2">
                <Label htmlFor="billNumber">Bill/Reference Number</Label>
                <Input
                  id="billNumber"
                  value={formData.bill_number}
                  onChange={(e) => setFormData(prev => ({ ...prev, bill_number: e.target.value }))}
                  placeholder="Enter bill number"
                />
              </div>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe the transaction"
                rows={3}
                required
              />
            </div>

            {/* Additional Notes */}
            <div className="space-y-2">
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Any additional information"
                rows={2}
              />
            </div>

            {/* Budget Impact Alert */}
            {budgetStatus && (
              <Card>
                <CardHeader>
                  <CardTitle>Budget Impact - {budgetStatus.category.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Current Spent:</span>
                      <span>{formatCurrency(budgetStatus.category.current_spent)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Budget Limit:</span>
                      <span>{formatCurrency(budgetStatus.category.budget_limit)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>This Transaction:</span>
                      <span>{formatCurrency(parseFloat(formData.amount))}</span>
                    </div>
                    <div className="flex justify-between items-center font-medium">
                      <span>New Total:</span>
                      <span>{formatCurrency(budgetStatus.newTotal)}</span>
                    </div>
                    
                    <Progress 
                      value={Math.min(budgetStatus.percentage, 100)} 
                      className="w-full"
                    />
                    <div className="flex justify-between items-center">
                      <Badge variant={
                        budgetStatus.status === 'DANGER' ? 'destructive' :
                        budgetStatus.status === 'WARNING' ? 'secondary' : 'default'
                      }>
                        {budgetStatus.percentage.toFixed(1)}% of budget
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        Remaining: {formatCurrency(budgetStatus.remaining)}
                      </span>
                    </div>
                    
                    {budgetStatus.status === 'DANGER' && (
                      <Alert>
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle>Budget Exceeded</AlertTitle>
                        <AlertDescription>
                          This transaction will exceed the budget limit for {budgetStatus.category.name}.
                        </AlertDescription>
                      </Alert>
                    )}
                    
                    {budgetStatus.status === 'WARNING' && (
                      <Alert>
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle>Budget Warning</AlertTitle>
                        <AlertDescription>
                          This transaction will use over 80% of the budget for {budgetStatus.category.name}.
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Submit Buttons */}
            <div className="flex gap-4 pt-4">
              <Button 
                type="submit" 
                className="flex-1" 
                disabled={loading}
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                ) : (
                  <CheckCircle className="w-4 h-4 mr-2" />
                )}
                {expense ? 'Update Transaction' : 'Submit Transaction'}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onCancel}
                disabled={loading}
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}