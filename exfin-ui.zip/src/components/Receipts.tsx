import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { CalendarDays, Plus, Search, Download, Printer, FileText, Receipt, Filter, CheckCircle, Clock, X } from "lucide-react";
import { format } from "date-fns";
import { Alert, AlertDescription } from "./ui/alert";
import { toast } from "sonner@2.0.3";
import { useAuth } from './AuthContext';

export interface ReceiptRecord {
  id: string;
  receiptNumber: string;
  studentName: string;
  studentId?: string;
  campus: string;
  amount: number;
  paymentMode: string;
  date: Date;
  academicYear: string;
  semester?: string;
  remarks?: string;
  status: 'Paid' | 'Pending' | 'Cancelled';
  issuedBy: string;
  // Type-specific fields
  course?: string; // For ID Card and Exam Fee
  eventName?: string; // For Event Management
  loanType?: string; // For Loan Receipts
  installmentNumber?: number; // For Loan Receipts
}

interface ReceiptsProps {
  receiptType: 'ID Card' | 'Loan' | 'Exam Fee' | 'Event Management';
  receipts?: ReceiptRecord[];
  onAddReceipt?: (receipt: Omit<ReceiptRecord, 'id' | 'receiptNumber'>) => void;
  onUpdateReceipt?: (id: string, updates: Partial<ReceiptRecord>) => void;
}

// Campus options from your branch structure
const campusOptions = [
  // Schools (Pragyana Team)
  'SONTYAM', 'THAGARAPUVALASA', 'BOYAPALEM', 'DAY SCHOOL',
  // Colleges (Sriven Team)
  'SRIVEN BC-1', 'SRIVEN BC-2', 'SRIVEN DC-1', 'SRIVEN DC-2', 'SRIVEN GC-1',
  'SRIVEN LTG', 'SRIVEN LT SPARK', 'SRIVEN BC-4', 'SRIVEN SIVASIVANI',
  'SRIVEN MESS', 'SRIVEN BHAVISHYA', 'SRIVEN GCON', 'SRIVEN HAPPY LIFE',
  'SRIVEN NETWORK OFFICE', 'SRIVEN GC4(HOSTEL BLOCK)', 'SRIVEN GC4(CLASS BLOCK)',
  'SRIVEN MAX(BC-6)', 'SRI VENKATESWARA ENTERPRISES', 'CENTRAL OFFICE'
];

const paymentModes = ['CASH', 'CHEQUE', 'ONLINE', 'UPI', 'CARD SWIPE', 'DEMAND DRAFT'];
const academicYears = ['2024-25', '2023-24', '2022-23', '2021-22', '2020-21'];
const semesters = ['1st Semester', '2nd Semester', '3rd Semester', '4th Semester', '5th Semester', '6th Semester'];
const courses = ['B.Tech', 'MBA', 'BBA', 'B.Com', 'M.Tech', 'MCA', 'B.Sc', 'M.Sc', 'B.A', 'M.A'];
const loanTypes = ['Education Loan', 'Emergency Loan', 'Hostel Fee Loan', 'Book/Material Loan', 'Other'];

// Sample data for different receipt types
const generateSampleData = (type: string): ReceiptRecord[] => {
  const baseData = [
    {
      id: '1',
      receiptNumber: `${type.replace(' ', '').toUpperCase()}-2024-001`,
      studentName: 'Rajesh Kumar',
      studentId: 'STU001',
      campus: 'SRIVEN BC-1',
      amount: type === 'ID Card' ? 500 : type === 'Exam Fee' ? 2500 : type === 'Loan' ? 15000 : 3000,
      paymentMode: 'CASH',
      date: new Date('2024-12-15'),
      academicYear: '2024-25',
      semester: '1st Semester',
      status: 'Paid' as const,
      issuedBy: 'Priya Sharma'
    },
    {
      id: '2',
      receiptNumber: `${type.replace(' ', '').toUpperCase()}-2024-002`,
      studentName: 'Anitha Reddy',
      studentId: 'STU002',
      campus: 'SONTYAM',
      amount: type === 'ID Card' ? 500 : type === 'Exam Fee' ? 2500 : type === 'Loan' ? 25000 : 5000,
      paymentMode: 'UPI',
      date: new Date('2024-12-14'),
      academicYear: '2024-25',
      semester: '2nd Semester',
      status: 'Paid' as const,
      issuedBy: 'Suresh Babu'
    }
  ];

  // Add type-specific fields
  return baseData.map(item => {
    switch (type) {
      case 'ID Card':
        return { ...item, course: 'B.Tech' };
      case 'Exam Fee':
        return { ...item, course: 'MBA', remarks: 'Final semester examination fee' };
      case 'Loan':
        return { ...item, loanType: 'Education Loan', installmentNumber: 1 };
      case 'Event Management':
        return { ...item, eventName: 'Annual Cultural Fest 2024', remarks: 'Registration and participation fee' };
      default:
        return item;
    }
  });
};

export function Receipts({ receiptType, receipts, onAddReceipt, onUpdateReceipt }: ReceiptsProps) {
  const { user } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [campusFilter, setCampusFilter] = useState<string>('all');
  
  const defaultReceipts = generateSampleData(receiptType);
  const displayReceipts = receipts || defaultReceipts;

  const [formData, setFormData] = useState({
    studentName: '',
    studentId: '',
    campus: '',
    amount: '',
    paymentMode: 'CASH',
    academicYear: '2024-25',
    semester: '1st Semester',
    remarks: '',
    course: receiptType === 'ID Card' || receiptType === 'Exam Fee' ? 'B.Tech' : '',
    eventName: receiptType === 'Event Management' ? '' : '',
    loanType: receiptType === 'Loan' ? 'Education Loan' : '',
    installmentNumber: receiptType === 'Loan' ? '1' : ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Generate receipt number
  const generateReceiptNumber = () => {
    const year = new Date().getFullYear();
    const count = displayReceipts.length + 1;
    const prefix = receiptType.replace(' ', '').toUpperCase();
    return `${prefix}-${year}-${count.toString().padStart(3, '0')}`;
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.studentName.trim()) {
      newErrors.studentName = 'Student name is required';
    }
    if (!formData.campus) {
      newErrors.campus = 'Campus selection is required';
    }
    
    const amount = parseFloat(formData.amount);
    if (!formData.amount || isNaN(amount) || amount <= 0) {
      newErrors.amount = 'Valid amount is required';
    }

    // Type-specific validations
    if (receiptType === 'Event Management' && !formData.eventName.trim()) {
      newErrors.eventName = 'Event name is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    try {
      const receiptData: Omit<ReceiptRecord, 'id' | 'receiptNumber'> = {
        studentName: formData.studentName.trim(),
        studentId: formData.studentId.trim() || undefined,
        campus: formData.campus,
        amount: parseFloat(formData.amount),
        paymentMode: formData.paymentMode,
        date: selectedDate,
        academicYear: formData.academicYear,
        semester: formData.semester,
        remarks: formData.remarks.trim() || undefined,
        status: 'Paid',
        issuedBy: user?.name || 'Unknown',
        // Type-specific fields
        ...(receiptType === 'ID Card' || receiptType === 'Exam Fee' ? { course: formData.course } : {}),
        ...(receiptType === 'Event Management' ? { eventName: formData.eventName.trim() } : {}),
        ...(receiptType === 'Loan' ? { 
          loanType: formData.loanType, 
          installmentNumber: parseInt(formData.installmentNumber) 
        } : {})
      };

      if (onAddReceipt) {
        onAddReceipt(receiptData);
      }
      
      toast.success(`${receiptType} receipt generated successfully!`);
      
      // Reset form
      setFormData({
        studentName: '',
        studentId: '',
        campus: '',
        amount: '',
        paymentMode: 'CASH',
        academicYear: '2024-25',
        semester: '1st Semester',
        remarks: '',
        course: receiptType === 'ID Card' || receiptType === 'Exam Fee' ? 'B.Tech' : '',
        eventName: receiptType === 'Event Management' ? '' : '',
        loanType: receiptType === 'Loan' ? 'Education Loan' : '',
        installmentNumber: receiptType === 'Loan' ? '1' : ''
      });
      setSelectedDate(new Date());
      setShowForm(false);
    } catch (error) {
      toast.error('Failed to generate receipt. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const getStatusBadge = (status: ReceiptRecord['status']) => {
    switch (status) {
      case 'Paid':
        return <Badge variant="secondary" className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Paid</Badge>;
      case 'Pending':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'Cancelled':
        return <Badge variant="destructive"><X className="w-3 h-3 mr-1" />Cancelled</Badge>;
      default:
        return null;
    }
  };

  // Filter receipts
  const filteredReceipts = displayReceipts.filter(receipt => {
    const matchesSearch = receipt.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         receipt.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (receipt.studentId && receipt.studentId.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || receipt.status === statusFilter;
    const matchesCampus = campusFilter === 'all' || receipt.campus === campusFilter;
    
    return matchesSearch && matchesStatus && matchesCampus;
  });

  const printReceipt = (receipt: ReceiptRecord) => {
    toast.success('Receipt sent to printer');
  };

  const downloadReceipt = (receipt: ReceiptRecord) => {
    toast.success('Receipt downloaded as PDF');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{receiptType} Receipts</h1>
          <p className="text-muted-foreground">
            Manage and generate {receiptType.toLowerCase()} receipts for students
          </p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus className="w-4 h-4" />
          {showForm ? 'Cancel' : `New ${receiptType} Receipt`}
        </Button>
      </div>

      {/* Info Alert */}
      <Alert>
        <Receipt className="h-4 w-4" />
        <AlertDescription>
          All {receiptType.toLowerCase()} receipts are automatically numbered and stored in the system for future reference.
        </AlertDescription>
      </Alert>

      {/* Receipt Form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Generate {receiptType} Receipt</CardTitle>
            <CardDescription>
              Fill in all details to generate a new receipt. Receipt Number: {generateReceiptNumber()}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Student Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Student Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="studentName">Student Name *</Label>
                    <Input
                      id="studentName"
                      placeholder="Enter student name"
                      value={formData.studentName}
                      onChange={(e) => handleInputChange('studentName', e.target.value)}
                      className={errors.studentName ? 'border-red-500' : ''}
                    />
                    {errors.studentName && <p className="text-sm text-red-500">{errors.studentName}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="studentId">Student ID (Optional)</Label>
                    <Input
                      id="studentId"
                      placeholder="Enter student ID"
                      value={formData.studentId}
                      onChange={(e) => handleInputChange('studentId', e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="campus">Campus *</Label>
                    <Select onValueChange={(value) => handleInputChange('campus', value)}>
                      <SelectTrigger className={errors.campus ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Select campus" />
                      </SelectTrigger>
                      <SelectContent>
                        {campusOptions.map((campus) => (
                          <SelectItem key={campus} value={campus}>
                            {campus}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.campus && <p className="text-sm text-red-500">{errors.campus}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label>Receipt Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                        >
                          <CalendarDays className="mr-2 h-4 w-4" />
                          {format(selectedDate, "dd-MM-yyyy")}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={(date) => date && setSelectedDate(date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>

              {/* Payment Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Payment Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (₹) *</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="Enter amount"
                      value={formData.amount}
                      onChange={(e) => handleInputChange('amount', e.target.value)}
                      className={errors.amount ? 'border-red-500' : ''}
                    />
                    {errors.amount && <p className="text-sm text-red-500">{errors.amount}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="paymentMode">Payment Mode</Label>
                    <Select value={formData.paymentMode} onValueChange={(value) => handleInputChange('paymentMode', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentModes.map((mode) => (
                          <SelectItem key={mode} value={mode}>
                            {mode}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="academicYear">Academic Year</Label>
                    <Select value={formData.academicYear} onValueChange={(value) => handleInputChange('academicYear', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {academicYears.map((year) => (
                          <SelectItem key={year} value={year}>
                            {year}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="semester">Semester</Label>
                    <Select value={formData.semester} onValueChange={(value) => handleInputChange('semester', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {semesters.map((sem) => (
                          <SelectItem key={sem} value={sem}>
                            {sem}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* Type-specific fields */}
              {(receiptType === 'ID Card' || receiptType === 'Exam Fee') && (
                <div className="space-y-2">
                  <Label htmlFor="course">Course</Label>
                  <Select value={formData.course} onValueChange={(value) => handleInputChange('course', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {courses.map((course) => (
                        <SelectItem key={course} value={course}>
                          {course}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {receiptType === 'Event Management' && (
                <div className="space-y-2">
                  <Label htmlFor="eventName">Event Name *</Label>
                  <Input
                    id="eventName"
                    placeholder="Enter event name"
                    value={formData.eventName}
                    onChange={(e) => handleInputChange('eventName', e.target.value)}
                    className={errors.eventName ? 'border-red-500' : ''}
                  />
                  {errors.eventName && <p className="text-sm text-red-500">{errors.eventName}</p>}
                </div>
              )}

              {receiptType === 'Loan' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="loanType">Loan Type</Label>
                    <Select value={formData.loanType} onValueChange={(value) => handleInputChange('loanType', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {loanTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="installmentNumber">Installment Number</Label>
                    <Input
                      id="installmentNumber"
                      type="number"
                      min="1"
                      value={formData.installmentNumber}
                      onChange={(e) => handleInputChange('installmentNumber', e.target.value)}
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="remarks">Remarks (Optional)</Label>
                <Textarea
                  id="remarks"
                  placeholder="Any additional information..."
                  value={formData.remarks}
                  onChange={(e) => handleInputChange('remarks', e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Generating...' : 'Generate Receipt'}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filters & Search</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Search</Label>
              <div className="relative">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Student name, ID, or receipt number"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Paid">Paid</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Campus</Label>
              <Select value={campusFilter} onValueChange={setCampusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Campuses</SelectItem>
                  {campusOptions.map((campus) => (
                    <SelectItem key={campus} value={campus}>
                      {campus}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>&nbsp;</Label>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchTerm('');
                  setStatusFilter('all');
                  setCampusFilter('all');
                }}
                className="w-full"
              >
                <Filter className="w-4 h-4 mr-2" />
                Clear Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Receipts Table */}
      <Card>
        <CardHeader>
          <CardTitle>{receiptType} Receipts</CardTitle>
          <CardDescription>
            Total Records: {filteredReceipts.length} | Total Amount: ₹{filteredReceipts.reduce((sum, r) => sum + r.amount, 0).toLocaleString()}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredReceipts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No receipts found matching your criteria.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Receipt No.</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Student Name</TableHead>
                    <TableHead>Campus</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Payment Mode</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReceipts.map((receipt) => (
                    <TableRow key={receipt.id}>
                      <TableCell className="font-medium">{receipt.receiptNumber}</TableCell>
                      <TableCell>{receipt.date.toLocaleDateString('en-IN')}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{receipt.studentName}</div>
                          {receipt.studentId && (
                            <div className="text-sm text-muted-foreground">{receipt.studentId}</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">{receipt.campus}</TableCell>
                      <TableCell className="font-medium">₹{receipt.amount.toLocaleString()}</TableCell>
                      <TableCell>{receipt.paymentMode}</TableCell>
                      <TableCell>{getStatusBadge(receipt.status)}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => printReceipt(receipt)}
                          >
                            <Printer className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => downloadReceipt(receipt)}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}