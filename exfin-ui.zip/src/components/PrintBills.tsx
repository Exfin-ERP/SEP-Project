import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Separator } from "./ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Printer, FileText, Search, Calendar, Building, User, DollarSign, CheckCircle } from 'lucide-react';
import { format } from "date-fns";
import { useAuth } from './AuthContext';

interface PrintBillsProps {
  expenses: any[];
}

export function PrintBills({ expenses }: PrintBillsProps) {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBill, setSelectedBill] = useState<any>(null);

  // Filter approved transactions for current accountant
  const approvedBills = useMemo(() => {
    return expenses.filter(expense => 
      expense.status === 'Approved' && 
      expense.accountantName === user?.name
    );
  }, [expenses, user?.name]);

  // Filter bills based on search
  const filteredBills = useMemo(() => {
    if (!searchTerm) return approvedBills;
    
    return approvedBills.filter(bill =>
      bill.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bill.natureOfWork?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bill.campus?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bill.utilityType?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [approvedBills, searchTerm]);

  const handlePrint = (bill: any) => {
    setSelectedBill(bill);
    // Trigger print after a short delay to allow the component to render
    setTimeout(() => {
      window.print();
      setSelectedBill(null);
    }, 100);
  };

  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
  };

  // Print view component
  const PrintView = ({ bill }: { bill: any }) => (
    <div className="print-only">
      <style jsx>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .print-only, .print-only * {
            visibility: visible;
          }
          .print-only {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
        }
      `}</style>
      
      <div className="max-w-4xl mx-auto p-8 bg-white">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold">Sri Venkateshwara Enterprises</h1>
          <p className="text-gray-600">Expenditure Voucher</p>
          <div className="mt-4 p-2 border border-gray-300 inline-block">
            <p className="font-medium">Voucher No: {bill.id}</p>
            <p>Date: {format(new Date(bill.date), 'dd-MM-yyyy')}</p>
          </div>
        </div>

        {/* Bill Details */}
        <div className="grid grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="font-semibold mb-4">Transaction Details</h3>
            <div className="space-y-2 text-sm">
              <div><strong>Campus:</strong> {bill.campus}</div>
              <div><strong>Team:</strong> {bill.teamAssigned}</div>
              <div><strong>Nature of Work:</strong> {bill.natureOfWork}</div>
              <div><strong>Expense Type:</strong> {bill.utilityType}</div>
              <div><strong>Payment Mode:</strong> {bill.paymentMode}</div>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Authorization Details</h3>
            <div className="space-y-2 text-sm">
              <div><strong>Authorized By:</strong> {bill.authorizedBy}</div>
              <div><strong>Accountant:</strong> {bill.accountantName}</div>
              <div><strong>Bill Status:</strong> {bill.billStatus ? 'Received' : 'Pending'}</div>
              <div><strong>Approval Status:</strong> 
                <span className="ml-2 px-2 py-1 bg-green-100 text-green-800 rounded text-xs">
                  {bill.status}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Amount Section */}
        <div className="border border-gray-300 p-4 mb-8">
          <div className="flex justify-between items-center mb-4">
            <span className="text-lg font-medium">Amount:</span>
            <span className="text-2xl font-bold">{formatCurrency(bill.amount)}</span>
          </div>
          <div className="text-sm text-gray-600">
            <strong>Amount in words:</strong> {/* You can add a number-to-words conversion here */}
            {formatCurrency(bill.amount)}
          </div>
        </div>

        {/* Description */}
        {bill.notes && (
          <div className="mb-8">
            <h3 className="font-semibold mb-2">Additional Notes:</h3>
            <p className="text-sm p-3 bg-gray-50 border">{bill.notes}</p>
          </div>
        )}

        {/* Signatures */}
        <div className="grid grid-cols-3 gap-8 mt-12">
          <div className="text-center">
            <div className="h-16 border-b border-gray-300 mb-2"></div>
            <p className="text-sm">Accountant</p>
            <p className="text-xs text-gray-600">{bill.accountantName}</p>
          </div>
          
          <div className="text-center">
            <div className="h-16 border-b border-gray-300 mb-2"></div>
            <p className="text-sm">Authorized By</p>
            <p className="text-xs text-gray-600">{bill.authorizedBy}</p>
          </div>
          
          <div className="text-center">
            <div className="h-16 border-b border-gray-300 mb-2"></div>
            <p className="text-sm">Management Approval</p>
            <p className="text-xs text-gray-600">Date: {format(new Date(), 'dd-MM-yyyy')}</p>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-xs text-gray-500">
          <p>This is a computer-generated voucher and requires proper authorization.</p>
          <p>Generated on: {format(new Date(), 'dd-MM-yyyy HH:mm')}</p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Print Approved Bills</h2>
          <p className="text-muted-foreground">Download and print approved expenditure vouchers</p>
        </div>
        <Badge className="bg-green-100 text-green-800">
          {approvedBills.length} Approved Bills
        </Badge>
      </div>

      {/* Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Search Bills
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <Label htmlFor="search">Search by description, campus, or expense type</Label>
              <Input
                id="search"
                placeholder="Enter search term..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="mt-1"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bills Table */}
      <Card>
        <CardHeader>
          <CardTitle>Approved Bills Ready for Printing</CardTitle>
          <CardDescription>
            Click on any bill to print the voucher
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredBills.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No approved bills found</p>
              {searchTerm && (
                <p className="text-sm mt-2">Try adjusting your search criteria</p>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Campus</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Expense Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Payment Mode</TableHead>
                    <TableHead>Team</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredBills.map((bill) => (
                    <TableRow key={bill.id} className="hover:bg-gray-50">
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          {format(new Date(bill.date), 'dd-MM-yyyy')}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Building className="w-4 h-4 text-gray-400" />
                          {bill.campus}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-48 truncate" title={bill.natureOfWork}>
                          {bill.natureOfWork}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{bill.utilityType}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-gray-400" />
                          {formatCurrency(bill.amount)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-blue-100 text-blue-800">
                          {bill.paymentMode}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          bill.teamAssigned === 'Pragyana Team' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-blue-100 text-blue-800'
                        }>
                          {bill.teamAssigned}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          onClick={() => handlePrint(bill)}
                          className="flex items-center gap-2"
                        >
                          <Printer className="w-4 h-4" />
                          Print
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-green-600">Total Approved</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{approvedBills.length}</div>
            <p className="text-sm text-muted-foreground">Bills ready for printing</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-blue-600">Total Amount</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(approvedBills.reduce((sum, bill) => sum + bill.amount, 0))}
            </div>
            <p className="text-sm text-muted-foreground">Total approved amount</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-purple-600">This Month</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {approvedBills.filter(bill => 
                new Date(bill.date).getMonth() === new Date().getMonth()
              ).length}
            </div>
            <p className="text-sm text-muted-foreground">Bills this month</p>
          </CardContent>
        </Card>
      </div>

      {/* Print Component */}
      {selectedBill && <PrintView bill={selectedBill} />}
    </div>
  );
}