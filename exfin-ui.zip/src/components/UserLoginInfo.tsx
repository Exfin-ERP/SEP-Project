import { useAuth } from './AuthContext';
import { User } from 'lucide-react';

interface UserLoginInfoProps {
  className?: string;
}

export function UserLoginInfo({ className = '' }: UserLoginInfoProps) {
  const { user } = useAuth();

  if (!user) {
    return null;
  }

  return (
    <div className={`flex items-center gap-2 text-sm ${className}`}>
      <User className="w-4 h-4" />
      <span>
        Logged in as: <span className="font-medium">{user.name}</span> (
        <span className="text-blue-600">{user.role}</span>)
      </span>
    </div>
  );
}
