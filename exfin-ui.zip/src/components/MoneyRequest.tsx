import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { AlertCircle, CheckCircle2, Clock, HandCoins, X } from "lucide-react";
import { Alert, AlertDescription } from "./ui/alert";
import { toast } from "sonner@2.0.3";
import { useAuth } from './AuthContext';

export interface MoneyRequest {
  id: string;
  accountantName: string;
  amount: number;
  purpose: string;
  description: string;
  requestedTo: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  createdDate: Date;
  responseDate?: Date;
  remarks?: string;
}

interface MoneyRequestProps {
  requests?: MoneyRequest[];
  onSubmitRequest?: (request: Omit<MoneyRequest, 'id' | 'status' | 'createdDate'>) => void;
  onUpdateRequest?: (id: string, status: 'Approved' | 'Rejected', remarks?: string) => void;
}

// Request To options
const requestToOptions = [
  { id: 'psn', name: 'PSN SIR' },
  { id: 'sridhar', name: 'SRIDHAR SIR' },
  { id: 'dharma', name: 'DHARMA RAJU SIR' },
  { id: 'management', name: 'MANAGEMENT' },
  { id: 'principal', name: 'PRINCIPAL' },
  { id: 'admin', name: 'ADMIN' }
];

const defaultRequests: MoneyRequest[] = [
  {
    id: '1',
    accountantName: 'Rajesh Kumar',
    amount: 25000,
    purpose: 'Infrastructure Improvement',
    description: 'Purchase of new classroom furniture and equipment for Block A. This includes student desks, chairs, whiteboard, and projector setup for enhanced learning environment.',
    requestedTo: 'PSN SIR',
    status: 'Pending',
    createdDate: new Date('2024-12-15'),
  },
  {
    id: '2',
    accountantName: 'Priya Sharma',
    amount: 15000,
    purpose: 'Event Management',
    description: 'Annual cultural fest arrangements including stage setup, sound system, decoration materials, refreshments for participants and organizing committee.',
    requestedTo: 'SRIDHAR SIR',
    status: 'Approved',
    createdDate: new Date('2024-12-12'),
    responseDate: new Date('2024-12-13'),
    remarks: 'Approved for cultural fest. Please maintain proper receipts.'
  },
  {
    id: '3',
    accountantName: 'Suresh Babu',
    amount: 12000,
    purpose: 'Laboratory Supplies',
    description: 'Chemistry lab equipment and chemicals procurement for practical sessions. Includes glassware, reagents, safety equipment and laboratory consumables.',
    requestedTo: 'MANAGEMENT',
    status: 'Rejected',
    createdDate: new Date('2024-12-10'),
    responseDate: new Date('2024-12-11'),
    remarks: 'Request insufficient details. Please resubmit with detailed inventory list.'
  }
];

export function MoneyRequest({ 
  requests = defaultRequests, 
  onSubmitRequest,
  onUpdateRequest 
}: MoneyRequestProps) {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    amount: '',
    purpose: '',
    description: '',
    requestedTo: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // Amount validation
    const amount = parseFloat(formData.amount);
    if (!formData.amount) {
      newErrors.amount = 'Amount is required';
    } else if (isNaN(amount) || amount < 10000) {
      newErrors.amount = 'Amount must be ₹10,000 or above';
    }

    // Required field validations
    if (!formData.purpose.trim()) {
      newErrors.purpose = 'Purpose is required';
    }
    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }
    if (!formData.requestedTo) {
      newErrors.requestedTo = 'Please select an admin to send the request to';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    try {
      const requestData = {
        accountantName: user?.name || 'Unknown',
        amount: parseFloat(formData.amount),
        purpose: formData.purpose.trim(),
        description: formData.description.trim(),
        requestedTo: formData.requestedTo
      };

      if (onSubmitRequest) {
        onSubmitRequest(requestData);
      }
      
      toast.success('Money request submitted successfully!');
      
      // Reset form
      setFormData({
        amount: '',
        purpose: '',
        description: '',
        requestedTo: ''
      });
      setShowForm(false);
    } catch (error) {
      toast.error('Failed to submit request. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const getStatusBadge = (status: MoneyRequest['status']) => {
    switch (status) {
      case 'Pending':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'Approved':
        return <Badge variant="secondary" className="bg-green-100 text-green-800"><CheckCircle2 className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'Rejected':
        return <Badge variant="destructive"><X className="w-3 h-3 mr-1" />Rejected</Badge>;
      default:
        return null;
    }
  };

  // Filter requests for current user if user is accountant
  const userRequests = user?.role === 'Accountant' 
    ? requests.filter(req => req.accountantName === user.name)
    : requests;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Money Request</h1>
          <p className="text-muted-foreground">
            Submit requests for expenses above ₹10,000 for admin approval
          </p>
        </div>
        {user?.role === 'Accountant' && (
          <Button onClick={() => setShowForm(!showForm)} className="gap-2">
            <HandCoins className="w-4 h-4" />
            {showForm ? 'Cancel' : 'New Request'}
          </Button>
        )}
      </div>

      {/* Info Alert */}
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Money requests are required for all expenses above ₹10,000. Requests must be approved by admin before proceeding with the expenditure.
        </AlertDescription>
      </Alert>

      {/* Request Form */}
      {showForm && user?.role === 'Accountant' && (
        <Card>
          <CardHeader>
            <CardTitle>Submit Money Request</CardTitle>
            <CardDescription>
              Fill in all details for your request. Amount must be ₹10,000 or above.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount (₹) *</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="Enter amount (minimum ₹10,000)"
                    value={formData.amount}
                    onChange={(e) => handleInputChange('amount', e.target.value)}
                    className={errors.amount ? 'border-red-500' : ''}
                  />
                  {errors.amount && <p className="text-sm text-red-500">{errors.amount}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="requestedTo">Request To *</Label>
                  <Select onValueChange={(value) => handleInputChange('requestedTo', value)}>
                    <SelectTrigger className={errors.requestedTo ? 'border-red-500' : ''}>
                      <SelectValue placeholder="Select admin to send request" />
                    </SelectTrigger>
                    <SelectContent>
                      {requestToOptions.map((option) => (
                        <SelectItem key={option.id} value={option.name}>
                          {option.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.requestedTo && <p className="text-sm text-red-500">{errors.requestedTo}</p>}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="purpose">Purpose of Request *</Label>
                <Input
                  id="purpose"
                  placeholder="Brief purpose of the expense (e.g., Infrastructure, Events, Supplies)"
                  value={formData.purpose}
                  onChange={(e) => handleInputChange('purpose', e.target.value)}
                  className={errors.purpose ? 'border-red-500' : ''}
                />
                {errors.purpose && <p className="text-sm text-red-500">{errors.purpose}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Detailed Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Provide comprehensive details about the expense requirement including what will be purchased, where it will be used, and who is involved. Be specific and clear."
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  className={errors.description ? 'border-red-500' : ''}
                  rows={6}
                />
                {errors.description && <p className="text-sm text-red-500">{errors.description}</p>}
                <p className="text-xs text-muted-foreground">
                  Include: What items/services, where they will be used, who is involved, and any other relevant details
                </p>
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Submitting...' : 'Submit Request'}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Requests Table */}
      <Card>
        <CardHeader>
          <CardTitle>
            {user?.role === 'Accountant' ? 'My Money Requests' : 'All Money Requests'}
          </CardTitle>
          <CardDescription>
            {user?.role === 'Accountant' 
              ? 'Track the status of your submitted requests'
              : 'View all money requests from accountants'
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          {userRequests.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No money requests found.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Accountant</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Purpose</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Requested To</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Remarks</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {userRequests.map((request) => (
                    <TableRow key={request.id}>
                      <TableCell>
                        {request.createdDate.toLocaleDateString('en-IN')}
                      </TableCell>
                      <TableCell>{request.accountantName}</TableCell>
                      <TableCell className="font-medium">₹{request.amount.toLocaleString()}</TableCell>
                      <TableCell>{request.purpose}</TableCell>
                      <TableCell className="max-w-xs">
                        <div className="text-sm">
                          {request.description.length > 100 
                            ? `${request.description.substring(0, 100)}...` 
                            : request.description}
                        </div>
                      </TableCell>
                      <TableCell>{request.requestedTo}</TableCell>
                      <TableCell>{getStatusBadge(request.status)}</TableCell>
                      <TableCell className="max-w-xs">
                        {request.remarks && (
                          <div className="text-sm text-muted-foreground">
                            {request.remarks}
                          </div>
                        )}
                        {request.responseDate && (
                          <div className="text-xs text-muted-foreground mt-1">
                            Responded: {request.responseDate.toLocaleDateString('en-IN')}
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}