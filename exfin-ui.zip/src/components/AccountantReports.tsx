import { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { 
  FileText, 
  Filter, 
  Download, 
  Eye, 
  Calendar,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  Building2,
  Calculator
} from 'lucide-react';

// Mock data for accountants based on the provided list
const accountantsData = [
  {
    id: '1',
    name: 'Chakradhar',
    email: 'chakradhar@sriviswa.com',
    branch: 'SRIVEN BC-1',
    team: 'Sriven Team',
    openingBalance: 25000,
    cashCollections: 45000,
    digitalCollections: 32000,
    totalExpenditure: 12000,
    bankDeposits: 35000,
    closingBalance: 55000,
    transactionCount: 15,
    lastUpdated: new Date('2024-12-15'),
    status: 'Active'
  },
  {
    id: '2',
    name: 'Gyaneswara Rao',
    email: 'gyaneswararao@sriviswa.com',
    branch: 'PRAGYANA-A1',
    team: 'Pragyana Team',
    openingBalance: 18000,
    cashCollections: 28000,
    digitalCollections: 22000,
    totalExpenditure: 8500,
    bankDeposits: 25000,
    closingBalance: 34500,
    transactionCount: 12,
    lastUpdated: new Date('2024-12-15'),
    status: 'Active'
  },
  {
    id: '3',
    name: 'Mani Teja',
    email: 'maniteja@sriviswa.com',
    branch: 'SRIVEN DC-1',
    team: 'Sriven Team',
    openingBalance: 32000,
    cashCollections: 52000,
    digitalCollections: 38000,
    totalExpenditure: 15000,
    bankDeposits: 40000,
    closingBalance: 67000,
    transactionCount: 18,
    lastUpdated: new Date('2024-12-15'),
    status: 'Active'
  },
  {
    id: '4',
    name: 'Ravi Kumar',
    email: 'ravikumar@sriviswa.com',
    branch: 'SONTYAM',
    team: 'Pragyana Team',
    openingBalance: 22000,
    cashCollections: 35000,
    digitalCollections: 28000,
    totalExpenditure: 10000,
    bankDeposits: 30000,
    closingBalance: 45000,
    transactionCount: 14,
    lastUpdated: new Date('2024-12-15'),
    status: 'Active'
  },
  {
    id: '5',
    name: 'Priya Sharma',
    email: 'priyasharma@sriviswa.com',
    branch: 'SRIVEN MBA-1',
    team: 'Sriven Team',
    openingBalance: 28000,
    cashCollections: 42000,
    digitalCollections: 35000,
    totalExpenditure: 12500,
    bankDeposits: 38000,
    closingBalance: 54500,
    transactionCount: 16,
    lastUpdated: new Date('2024-12-15'),
    status: 'Active'
  },
  {
    id: '6',
    name: 'Suresh Babu',
    email: 'sureshbabu@sriviswa.com',
    branch: 'CENTRAL OFFICE',
    team: 'Central Team',
    openingBalance: 45000,
    cashCollections: 65000,
    digitalCollections: 48000,
    totalExpenditure: 20000,
    bankDeposits: 55000,
    closingBalance: 83000,
    transactionCount: 22,
    lastUpdated: new Date('2024-12-15'),
    status: 'Active'
  }
];

// Detailed transactions for each accountant (mock data)
const accountantTransactions = {
  '1': [
    {
      id: 't1',
      date: new Date('2024-12-15'),
      type: 'Fee Collection',
      branch: 'SRIVEN BC-1',
      description: 'Semester fee collection - B.Tech CSE',
      paymentMethod: 'Cash',
      amount: 15000,
      reference: 'FC001'
    },
    {
      id: 't2',
      date: new Date('2024-12-15'),
      type: 'Cash Expenditure',
      branch: 'SRIVEN BC-1',
      description: 'Office supplies and stationery',
      paymentMethod: 'Cash',
      amount: -2500,
      reference: 'EXP001'
    },
    {
      id: 't3',
      date: new Date('2024-12-15'),
      type: 'Bank Deposit',
      branch: 'SRIVEN BC-1',
      description: 'Daily cash deposit to SBI',
      paymentMethod: 'Bank Transfer',
      amount: -25000,
      reference: 'DEP001'
    }
  ],
  '2': [
    {
      id: 't4',
      date: new Date('2024-12-15'),
      type: 'Fee Collection',
      branch: 'PRAGYANA-A1',
      description: 'Monthly fee collection - Primary',
      paymentMethod: 'UPI',
      amount: 12000,
      reference: 'FC002'
    },
    {
      id: 't5',
      date: new Date('2024-12-15'),
      type: 'Cash Expenditure',
      branch: 'PRAGYANA-A1',
      description: 'Electricity bill payment',
      paymentMethod: 'Cash',
      amount: -3500,
      reference: 'EXP002'
    }
  ]
};

export function AccountantReports() {
  const [selectedAccountant, setSelectedAccountant] = useState<string | null>(null);
  const [dateFilter, setDateFilter] = useState({
    from: '',
    to: ''
  });
  const [branchFilter, setBranchFilter] = useState('all');
  const [teamFilter, setTeamFilter] = useState('all');

  // Calculate totals
  const totals = useMemo(() => {
    return accountantsData.reduce((acc, accountant) => ({
      totalOpeningBalance: acc.totalOpeningBalance + accountant.openingBalance,
      totalCashCollections: acc.totalCashCollections + accountant.cashCollections,
      totalDigitalCollections: acc.totalDigitalCollections + accountant.digitalCollections,
      totalExpenditure: acc.totalExpenditure + accountant.totalExpenditure,
      totalBankDeposits: acc.totalBankDeposits + accountant.bankDeposits,
      totalClosingBalance: acc.totalClosingBalance + accountant.closingBalance,
      totalTransactions: acc.totalTransactions + accountant.transactionCount
    }), {
      totalOpeningBalance: 0,
      totalCashCollections: 0,
      totalDigitalCollections: 0,
      totalExpenditure: 0,
      totalBankDeposits: 0,
      totalClosingBalance: 0,
      totalTransactions: 0
    });
  }, []);

  // Filter accountants based on selected filters
  const filteredAccountants = useMemo(() => {
    return accountantsData.filter(accountant => {
      if (branchFilter !== 'all' && accountant.branch !== branchFilter) return false;
      if (teamFilter !== 'all' && accountant.team !== teamFilter) return false;
      return true;
    });
  }, [branchFilter, teamFilter]);

  const getStatusBadge = (status: string) => {
    const colors = {
      'Active': 'bg-green-100 text-green-800',
      'Inactive': 'bg-red-100 text-red-800',
      'Pending': 'bg-yellow-100 text-yellow-800'
    };
    return <Badge className={colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800'}>{status}</Badge>;
  };

  const unique = {
    branches: [...new Set(accountantsData.map(a => a.branch))],
    teams: [...new Set(accountantsData.map(a => a.team))]
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Accountant Reports</h2>
          <p className="text-muted-foreground">Comprehensive financial reports from all accountants</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Reports
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Accountants</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{accountantsData.length}</div>
            <p className="text-xs text-muted-foreground">Active accountants</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Collections</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ₹{(totals.totalCashCollections + totals.totalDigitalCollections).toLocaleString('en-IN')}
            </div>
            <p className="text-xs text-muted-foreground">
              Cash: ₹{totals.totalCashCollections.toLocaleString('en-IN')} | Digital: ₹{totals.totalDigitalCollections.toLocaleString('en-IN')}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Expenditure</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totals.totalExpenditure.toLocaleString('en-IN')}</div>
            <p className="text-xs text-muted-foreground">Across all branches</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Balance</CardTitle>
            <Calculator className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{totals.totalClosingBalance.toLocaleString('en-IN')}</div>
            <p className="text-xs text-muted-foreground">Combined closing balances</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="summary" className="space-y-6">
        <TabsList>
          <TabsTrigger value="summary">Summary</TabsTrigger>
          <TabsTrigger value="detailed">Detailed View</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="summary" className="space-y-6">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5" />
                Filters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label>Date From</Label>
                  <Input
                    type="date"
                    value={dateFilter.from}
                    onChange={(e) => setDateFilter(prev => ({ ...prev, from: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Date To</Label>
                  <Input
                    type="date"
                    value={dateFilter.to}
                    onChange={(e) => setDateFilter(prev => ({ ...prev, to: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Branch</Label>
                  <Select value={branchFilter} onValueChange={setBranchFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Branches</SelectItem>
                      {unique.branches.map(branch => (
                        <SelectItem key={branch} value={branch}>{branch}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Team</Label>
                  <Select value={teamFilter} onValueChange={setTeamFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Teams</SelectItem>
                      {unique.teams.map(team => (
                        <SelectItem key={team} value={team}>{team}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Accountant Summary Table */}
          <Card>
            <CardHeader>
              <CardTitle>Accountant-wise Summary</CardTitle>
              <CardDescription>Summary of all accountant activities</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Accountant</TableHead>
                    <TableHead>Branch/Team</TableHead>
                    <TableHead>Opening Balance</TableHead>
                    <TableHead>Cash Collections</TableHead>
                    <TableHead>Digital Collections</TableHead>
                    <TableHead>Expenditure</TableHead>
                    <TableHead>Bank Deposits</TableHead>
                    <TableHead>Closing Balance</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAccountants.map((accountant) => (
                    <TableRow key={accountant.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{accountant.name}</p>
                          <p className="text-sm text-muted-foreground">{accountant.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm">{accountant.branch}</p>
                          <Badge variant="outline" className="text-xs">{accountant.team}</Badge>
                        </div>
                      </TableCell>
                      <TableCell>₹{accountant.openingBalance.toLocaleString('en-IN')}</TableCell>
                      <TableCell className="text-green-600">₹{accountant.cashCollections.toLocaleString('en-IN')}</TableCell>
                      <TableCell className="text-blue-600">₹{accountant.digitalCollections.toLocaleString('en-IN')}</TableCell>
                      <TableCell className="text-red-600">₹{accountant.totalExpenditure.toLocaleString('en-IN')}</TableCell>
                      <TableCell className="text-orange-600">₹{accountant.bankDeposits.toLocaleString('en-IN')}</TableCell>
                      <TableCell className="font-bold">₹{accountant.closingBalance.toLocaleString('en-IN')}</TableCell>
                      <TableCell>{getStatusBadge(accountant.status)}</TableCell>
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" onClick={() => setSelectedAccountant(accountant.id)}>
                              <Eye className="w-4 h-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-4xl">
                            <DialogHeader>
                              <DialogTitle>Detailed Transactions - {accountant.name}</DialogTitle>
                              <DialogDescription>
                                Detailed transaction history for {accountant.branch}
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div className="text-center p-3 bg-blue-50 rounded">
                                  <div className="text-lg font-bold text-blue-600">
                                    ₹{accountant.openingBalance.toLocaleString('en-IN')}
                                  </div>
                                  <div className="text-sm text-blue-700">Opening Balance</div>
                                </div>
                                <div className="text-center p-3 bg-green-50 rounded">
                                  <div className="text-lg font-bold text-green-600">
                                    ₹{(accountant.cashCollections + accountant.digitalCollections).toLocaleString('en-IN')}
                                  </div>
                                  <div className="text-sm text-green-700">Total Collections</div>
                                </div>
                                <div className="text-center p-3 bg-red-50 rounded">
                                  <div className="text-lg font-bold text-red-600">
                                    ₹{accountant.totalExpenditure.toLocaleString('en-IN')}
                                  </div>
                                  <div className="text-sm text-red-700">Total Expenditure</div>
                                </div>
                                <div className="text-center p-3 bg-purple-50 rounded">
                                  <div className="text-lg font-bold text-purple-600">
                                    ₹{accountant.closingBalance.toLocaleString('en-IN')}
                                  </div>
                                  <div className="text-sm text-purple-700">Closing Balance</div>
                                </div>
                              </div>
                              
                              {accountantTransactions[accountant.id] && (
                                <Table>
                                  <TableHeader>
                                    <TableRow>
                                      <TableHead>Date</TableHead>
                                      <TableHead>Type</TableHead>
                                      <TableHead>Description</TableHead>
                                      <TableHead>Payment Method</TableHead>
                                      <TableHead>Amount</TableHead>
                                      <TableHead>Reference</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {accountantTransactions[accountant.id].map((transaction) => (
                                      <TableRow key={transaction.id}>
                                        <TableCell>{transaction.date.toLocaleDateString('en-IN')}</TableCell>
                                        <TableCell>
                                          <Badge variant="outline">{transaction.type}</Badge>
                                        </TableCell>
                                        <TableCell>{transaction.description}</TableCell>
                                        <TableCell>{transaction.paymentMethod}</TableCell>
                                        <TableCell className={transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}>
                                          {transaction.amount > 0 ? '+' : ''}₹{Math.abs(transaction.amount).toLocaleString('en-IN')}
                                        </TableCell>
                                        <TableCell>{transaction.reference}</TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              )}
                            </div>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="detailed">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Transaction View</CardTitle>
              <CardDescription>Comprehensive view of all transactions across accountants</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Detailed transaction view will be implemented here</p>
                <p className="text-sm">This will show all individual transactions from all accountants</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Financial Analytics</CardTitle>
              <CardDescription>Charts and graphs showing financial trends</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                <TrendingUp className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Analytics charts will be implemented here</p>
                <p className="text-sm">This will show trends, comparisons, and financial insights</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}