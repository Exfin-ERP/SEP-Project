import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { CalendarDays, Plus, Download, Printer, CheckCircle, Clock, X } from "lucide-react";
import { format } from "date-fns";
import { Alert, AlertDescription } from "./ui/alert";
import { toast } from "sonner@2.0.3";
import { useAuth } from './AuthContext';

interface EventManagementReceiptRecord {
  id: string;
  receiptNumber: string;
  participantName: string;
  participantId?: string;
  contactNumber: string;
  email?: string;
  campus: string;
  amount: number;
  paymentMode: string;
  date: Date;
  eventName: string;
  eventDate: Date;
  eventType: string;
  participationCategory: string;
  teamSize?: number;
  teamMembers?: string;
  remarks?: string;
  status: 'Paid' | 'Pending' | 'Cancelled';
  issuedBy: string;
}

const campusOptions = [
  'SONTYAM', 'THAGARAPUVALASA', 'BOYAPALEM', 'DAY SCHOOL',
  'SRIVEN BC-1', 'SRIVEN BC-2', 'SRIVEN DC-1', 'SRIVEN DC-2', 'SRIVEN GC-1',
  'SRIVEN LTG', 'SRIVEN LT SPARK', 'SRIVEN BC-4', 'SRIVEN SIVASIVANI'
];

const paymentModes = ['CASH', 'CHEQUE', 'ONLINE', 'UPI', 'CARD SWIPE', 'DEMAND DRAFT'];
const eventTypes = [
  'Cultural Event',
  'Technical Event',
  'Sports Event',
  'Workshop',
  'Seminar',
  'Conference',
  'Competition',
  'Festival',
  'Educational Trip',
  'Guest Lecture'
];

const participationCategories = [
  'Individual',
  'Team (2 members)',
  'Team (3-5 members)',
  'Team (6-10 members)',
  'Group (10+ members)',
  'Institution Level',
  'Inter-College'
];

const sampleReceipts: EventManagementReceiptRecord[] = [
  {
    id: '1',
    receiptNumber: 'EVENT-2024-001',
    participantName: 'Arjun Kumar',
    participantId: 'STU001',
    contactNumber: '9876543210',
    email: 'arjun@example.com',
    campus: 'SRIVEN BC-1',
    amount: 1500,
    paymentMode: 'UPI',
    date: new Date('2024-12-15'),
    eventName: 'Annual Cultural Fest 2024',
    eventDate: new Date('2025-01-15'),
    eventType: 'Cultural Event',
    participationCategory: 'Individual',
    status: 'Paid',
    issuedBy: 'Priya Sharma'
  },
  {
    id: '2',
    receiptNumber: 'EVENT-2024-002',
    participantName: 'Meera Reddy',
    participantId: 'STU002',
    contactNumber: '9876543211',
    email: 'meera@example.com',
    campus: 'SRIVEN DC-1',
    amount: 2500,
    paymentMode: 'CASH',
    date: new Date('2024-12-14'),
    eventName: 'Tech Symposium 2024',
    eventDate: new Date('2025-01-20'),
    eventType: 'Technical Event',
    participationCategory: 'Team (3-5 members)',
    teamSize: 4,
    teamMembers: 'Meera Reddy, Raj Kumar, Sita Devi, Ram Prasad',
    remarks: 'Project presentation competition',
    status: 'Paid',
    issuedBy: 'Suresh Babu'
  }
];

export function EventManagementReceipt() {
  const { user } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedEventDate, setSelectedEventDate] = useState<Date>(new Date());
  const [receipts] = useState<EventManagementReceiptRecord[]>(sampleReceipts);
  
  const [formData, setFormData] = useState({
    participantName: '',
    participantId: '',
    contactNumber: '',
    email: '',
    campus: '',
    amount: '',
    paymentMode: 'CASH',
    eventName: '',
    eventType: 'Cultural Event',
    participationCategory: 'Individual',
    teamSize: '',
    teamMembers: '',
    remarks: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const generateReceiptNumber = () => {
    const year = new Date().getFullYear();
    const count = receipts.length + 1;
    return `EVENT-${year}-${count.toString().padStart(3, '0')}`;
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.participantName.trim()) newErrors.participantName = 'Participant name is required';
    if (!formData.contactNumber.trim()) newErrors.contactNumber = 'Contact number is required';
    if (!formData.campus) newErrors.campus = 'Campus is required';
    if (!formData.eventName.trim()) newErrors.eventName = 'Event name is required';
    
    const amount = parseFloat(formData.amount);
    if (!formData.amount || isNaN(amount) || amount <= 0) {
      newErrors.amount = 'Valid amount is required';
    }

    // Validate contact number format
    if (formData.contactNumber && !/^\d{10}$/.test(formData.contactNumber.replace(/\s/g, ''))) {
      newErrors.contactNumber = 'Please enter a valid 10-digit contact number';
    }

    // Validate email if provided
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Team validation
    if (formData.participationCategory.includes('Team') && !formData.teamMembers.trim()) {
      newErrors.teamMembers = 'Team members list is required for team participation';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast.success('Event management receipt generated successfully!');
      
      setFormData({
        participantName: '',
        participantId: '',
        contactNumber: '',
        email: '',
        campus: '',
        amount: '',
        paymentMode: 'CASH',
        eventName: '',
        eventType: 'Cultural Event',
        participationCategory: 'Individual',
        teamSize: '',
        teamMembers: '',
        remarks: ''
      });
      setSelectedDate(new Date());
      setSelectedEventDate(new Date());
      setShowForm(false);
    } catch (error) {
      toast.error('Failed to generate receipt. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const getStatusBadge = (status: EventManagementReceiptRecord['status']) => {
    switch (status) {
      case 'Paid':
        return <Badge variant="secondary" className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Paid</Badge>;
      case 'Pending':
        return <Badge variant="secondary" className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'Cancelled':
        return <Badge variant="destructive"><X className="w-3 h-3 mr-1" />Cancelled</Badge>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Event Management Receipts</h1>
          <p>Generate and manage event participation receipts</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus className="w-4 h-4" />
          {showForm ? 'Cancel' : 'New Event Receipt'}
        </Button>
      </div>

      {/* Info Alert */}
      <Alert>
        <CheckCircle className="h-4 w-4" />
        <AlertDescription>
          All event management receipts are automatically numbered and stored for future reference. Ensure event details are accurate.
        </AlertDescription>
      </Alert>

      {/* Receipt Form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Generate Event Management Receipt</CardTitle>
            <CardDescription>
              Fill in all details to generate a new receipt. Receipt Number: {generateReceiptNumber()}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Participant Information */}
              <div className="space-y-4">
                <h3>Participant Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="participantName">Participant Name *</Label>
                    <Input
                      id="participantName"
                      placeholder="Enter participant name"
                      value={formData.participantName}
                      onChange={(e) => handleInputChange('participantName', e.target.value)}
                      className={errors.participantName ? 'border-red-500' : ''}
                    />
                    {errors.participantName && <p className="text-sm text-red-500">{errors.participantName}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="participantId">Student/Participant ID (Optional)</Label>
                    <Input
                      id="participantId"
                      placeholder="Enter ID if applicable"
                      value={formData.participantId}
                      onChange={(e) => handleInputChange('participantId', e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="contactNumber">Contact Number *</Label>
                    <Input
                      id="contactNumber"
                      placeholder="Enter 10-digit mobile number"
                      value={formData.contactNumber}
                      onChange={(e) => handleInputChange('contactNumber', e.target.value)}
                      className={errors.contactNumber ? 'border-red-500' : ''}
                    />
                    {errors.contactNumber && <p className="text-sm text-red-500">{errors.contactNumber}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address (Optional)</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter email address"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      className={errors.email ? 'border-red-500' : ''}
                    />
                    {errors.email && <p className="text-sm text-red-500">{errors.email}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="campus">Campus *</Label>
                    <Select onValueChange={(value) => handleInputChange('campus', value)}>
                      <SelectTrigger className={errors.campus ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Select campus" />
                      </SelectTrigger>
                      <SelectContent>
                        {campusOptions.map((campus) => (
                          <SelectItem key={campus} value={campus}>
                            {campus}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.campus && <p className="text-sm text-red-500">{errors.campus}</p>}
                  </div>
                </div>
              </div>

              {/* Event Information */}
              <div className="space-y-4">
                <h3>Event Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="eventName">Event Name *</Label>
                    <Input
                      id="eventName"
                      placeholder="Enter event name"
                      value={formData.eventName}
                      onChange={(e) => handleInputChange('eventName', e.target.value)}
                      className={errors.eventName ? 'border-red-500' : ''}
                    />
                    {errors.eventName && <p className="text-sm text-red-500">{errors.eventName}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="eventType">Event Type</Label>
                    <Select value={formData.eventType} onValueChange={(value) => handleInputChange('eventType', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {eventTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Event Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left"
                        >
                          <CalendarDays className="mr-2 h-4 w-4" />
                          {format(selectedEventDate, "dd-MM-yyyy")}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={selectedEventDate}
                          onSelect={(date) => date && setSelectedEventDate(date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="participationCategory">Participation Category</Label>
                    <Select value={formData.participationCategory} onValueChange={(value) => handleInputChange('participationCategory', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {participationCategories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Team Details - Only show if team participation */}
                {formData.participationCategory.includes('Team') && (
                  <div className="space-y-4">
                    <h4>Team Details</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="teamSize">Team Size</Label>
                        <Input
                          id="teamSize"
                          type="number"
                          placeholder="Enter number of team members"
                          value={formData.teamSize}
                          onChange={(e) => handleInputChange('teamSize', e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="teamMembers">Team Members *</Label>
                      <Textarea
                        id="teamMembers"
                        placeholder="Enter all team member names (comma separated)"
                        value={formData.teamMembers}
                        onChange={(e) => handleInputChange('teamMembers', e.target.value)}
                        className={errors.teamMembers ? 'border-red-500' : ''}
                        rows={3}
                      />
                      {errors.teamMembers && <p className="text-sm text-red-500">{errors.teamMembers}</p>}
                    </div>
                  </div>
                )}
              </div>

              {/* Payment Information */}
              <div className="space-y-4">
                <h3>Payment Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (₹) *</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="Enter amount"
                      value={formData.amount}
                      onChange={(e) => handleInputChange('amount', e.target.value)}
                      className={errors.amount ? 'border-red-500' : ''}
                    />
                    {errors.amount && <p className="text-sm text-red-500">{errors.amount}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="paymentMode">Payment Mode</Label>
                    <Select value={formData.paymentMode} onValueChange={(value) => handleInputChange('paymentMode', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentModes.map((mode) => (
                          <SelectItem key={mode} value={mode}>
                            {mode}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Receipt Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full justify-start text-left"
                        >
                          <CalendarDays className="mr-2 h-4 w-4" />
                          {format(selectedDate, "dd-MM-yyyy")}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={(date) => date && setSelectedDate(date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="remarks">Remarks (Optional)</Label>
                  <Textarea
                    id="remarks"
                    placeholder="Any additional information about the event or participation..."
                    value={formData.remarks}
                    onChange={(e) => handleInputChange('remarks', e.target.value)}
                    rows={3}
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Generating...' : 'Generate Receipt'}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Receipts Table */}
      <Card>
        <CardHeader>
          <CardTitle>Event Management Receipts</CardTitle>
          <CardDescription>
            Total Records: {receipts.length} | Total Amount: ₹{receipts.reduce((sum, r) => sum + r.amount, 0).toLocaleString()}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Receipt No.</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Participant Details</TableHead>
                  <TableHead>Event Name</TableHead>
                  <TableHead>Event Type</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {receipts.map((receipt) => (
                  <TableRow key={receipt.id}>
                    <TableCell>{receipt.receiptNumber}</TableCell>
                    <TableCell>{receipt.date.toLocaleDateString('en-IN')}</TableCell>
                    <TableCell>
                      <div>
                        <div>{receipt.participantName}</div>
                        <div className="text-sm text-muted-foreground">{receipt.contactNumber}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{receipt.eventName}</TableCell>
                    <TableCell className="text-sm">{receipt.eventType}</TableCell>
                    <TableCell>₹{receipt.amount.toLocaleString()}</TableCell>
                    <TableCell>{getStatusBadge(receipt.status)}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Printer className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}