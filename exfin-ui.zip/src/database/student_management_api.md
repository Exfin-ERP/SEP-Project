# Student Management API Documentation
## Sri Venkateswara Enterprises - Educational ERP System

---

## Base URL
```
Production: https://api.sriven.edu.in/v1
Development: http://localhost:3000/api/v1
```

## Authentication
All endpoints require JWT authentication via Bearer token:
```
Authorization: Bearer <token>
```

---

## Student Management Endpoints

### 1. Create Student
**Endpoint:** `POST /students`

**Description:** Create a new student record

**Required Permissions:** `Admin`, `Management`

**Request Body:**
```json
{
  "admissionNumber": "PRAG-2024-001",
  "firstName": "Rajesh",
  "lastName": "Kumar",
  "dateOfBirth": "2014-05-15",
  "gender": "Male",
  "classGrade": "Class 5",
  "section": "A",
  "rollNumber": "5A-01",
  "academicYear": "2024-25",
  "admissionDate": "2024-04-01",
  "status": "Active",
  "parentPhone": "+91 98765 43210",
  "parentEmail": "rajesh.parent@email.com",
  "email": "rajesh.student@email.com",
  "phone": "+91 98765 43211",
  "address": "123 Main Street, Sector 5",
  "city": "Hyderabad",
  "state": "Telangana",
  "pincode": "500001",
  "bloodGroup": "O+",
  "caste": "OC",
  "religion": "Hindu",
  "fatherName": "Kumar Reddy",
  "motherName": "Lakshmi Reddy",
  "guardianName": "",
  "organizationId": 1,
  "branchId": 1
}
```

**Response:** `201 Created`
```json
{
  "success": true,
  "message": "Student created successfully",
  "data": {
    "id": "123",
    "studentId": "PRAG-20241215-789",
    "admissionNumber": "PRAG-2024-001",
    "firstName": "Rajesh",
    "lastName": "Kumar",
    "fullName": "Rajesh Kumar",
    "dateOfBirth": "2014-05-15T00:00:00.000Z",
    "gender": "Male",
    "classGrade": "Class 5",
    "section": "A",
    "rollNumber": "5A-01",
    "academicYear": "2024-25",
    "admissionDate": "2024-04-01T00:00:00.000Z",
    "status": "Active",
    "parentPhone": "+91 98765 43210",
    "parentEmail": "rajesh.parent@email.com",
    "createdAt": "2024-12-15T10:30:00.000Z",
    "updatedAt": "2024-12-15T10:30:00.000Z"
  }
}
```

**Error Response:** `400 Bad Request`
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid student data",
    "details": [
      {
        "field": "firstName",
        "message": "First name is required"
      },
      {
        "field": "email",
        "message": "Invalid email format"
      }
    ]
  }
}
```

---

### 2. Get Students (List with Filters)
**Endpoint:** `GET /students`

**Description:** Retrieve a list of students with optional filtering and pagination

**Required Permissions:** `Admin`, `Management`, `Accountant`, `Viewer`

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 20, max: 100)
- `search` (optional): Search by name, admission number, student ID, or parent phone
- `classGrade` (optional): Filter by class (e.g., "Class 5", "B.Tech")
- `section` (optional): Filter by section (e.g., "A", "B")
- `status` (optional): Filter by status ("Active", "Inactive", "Passed Out", "Transferred")
- `academicYear` (optional): Filter by academic year (e.g., "2024-25")
- `organizationId` (optional): Filter by organization
- `branchId` (optional): Filter by branch
- `gender` (optional): Filter by gender ("Male", "Female", "Other")

**Example:**
```
GET /students?page=1&limit=20&classGrade=Class%205&status=Active&organizationId=1
```

**Response:** `200 OK`
```json
{
  "success": true,
  "data": [
    {
      "id": "123",
      "studentId": "PRAG-20241215-789",
      "admissionNumber": "PRAG-2024-001",
      "firstName": "Rajesh",
      "lastName": "Kumar",
      "fullName": "Rajesh Kumar",
      "classGrade": "Class 5",
      "section": "A",
      "rollNumber": "5A-01",
      "status": "Active",
      "parentPhone": "+91 98765 43210",
      "academicYear": "2024-25"
    }
  ],
  "pagination": {
    "currentPage": 1,
    "totalPages": 5,
    "totalRecords": 95,
    "perPage": 20
  },
  "summary": {
    "totalStudents": 450,
    "activeStudents": 425,
    "maleStudents": 240,
    "femaleStudents": 210
  }
}
```

---

### 3. Get Student by ID
**Endpoint:** `GET /students/:id`

**Description:** Retrieve detailed information for a specific student

**Required Permissions:** `Admin`, `Management`, `Accountant`, `Viewer`

**Example:**
```
GET /students/PRAG-20241215-789
```

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "id": "123",
    "studentId": "PRAG-20241215-789",
    "admissionNumber": "PRAG-2024-001",
    "firstName": "Rajesh",
    "lastName": "Kumar",
    "fullName": "Rajesh Kumar",
    "dateOfBirth": "2014-05-15T00:00:00.000Z",
    "gender": "Male",
    "classGrade": "Class 5",
    "section": "A",
    "rollNumber": "5A-01",
    "academicYear": "2024-25",
    "admissionDate": "2024-04-01T00:00:00.000Z",
    "status": "Active",
    "email": "rajesh.student@email.com",
    "phone": "+91 98765 43211",
    "parentPhone": "+91 98765 43210",
    "parentEmail": "rajesh.parent@email.com",
    "address": "123 Main Street, Sector 5",
    "city": "Hyderabad",
    "state": "Telangana",
    "pincode": "500001",
    "bloodGroup": "O+",
    "caste": "OC",
    "religion": "Hindu",
    "fatherName": "Kumar Reddy",
    "motherName": "Lakshmi Reddy",
    "guardianName": "",
    "organizationId": 1,
    "branchId": 1,
    "createdAt": "2024-04-01T10:00:00.000Z",
    "updatedAt": "2024-12-15T10:30:00.000Z"
  }
}
```

**Error Response:** `404 Not Found`
```json
{
  "success": false,
  "error": {
    "code": "RESOURCE_NOT_FOUND",
    "message": "Student not found"
  }
}
```

---

### 4. Update Student
**Endpoint:** `PUT /students/:id`

**Description:** Update student information

**Required Permissions:** `Admin`, `Management`

**Request Body:** (partial updates allowed)
```json
{
  "section": "B",
  "rollNumber": "5B-15",
  "phone": "+91 98765 43212",
  "email": "rajesh.new@email.com",
  "address": "456 New Address",
  "status": "Active"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Student updated successfully",
  "data": {
    "id": "123",
    "studentId": "PRAG-20241215-789",
    "admissionNumber": "PRAG-2024-001",
    "firstName": "Rajesh",
    "lastName": "Kumar",
    "fullName": "Rajesh Kumar",
    "section": "B",
    "rollNumber": "5B-15",
    "phone": "+91 98765 43212",
    "email": "rajesh.new@email.com",
    "address": "456 New Address",
    "updatedAt": "2024-12-15T14:30:00.000Z"
  }
}
```

---

### 5. Delete Student (Soft Delete)
**Endpoint:** `DELETE /students/:id`

**Description:** Soft delete a student record (marks as deleted but retains data)

**Required Permissions:** `Admin` only

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Student deleted successfully"
}
```

---

### 6. Bulk Upload Students
**Endpoint:** `POST /students/bulk-upload`

**Description:** Upload multiple students from CSV/Excel file

**Required Permissions:** `Admin`, `Management`

**Request Body:**
```json
{
  "students": [
    {
      "admissionNumber": "PRAG-2024-002",
      "firstName": "Priya",
      "lastName": "Sharma",
      "dateOfBirth": "2013-08-22",
      "gender": "Female",
      "classGrade": "Class 6",
      "section": "B",
      "rollNumber": "6B-12",
      "academicYear": "2024-25",
      "admissionDate": "2024-04-01",
      "parentPhone": "+91 98765 43220"
    },
    {
      "admissionNumber": "PRAG-2024-003",
      "firstName": "Arun",
      "lastName": "Reddy",
      "dateOfBirth": "2012-03-10",
      "gender": "Male",
      "classGrade": "Class 8",
      "section": "A",
      "rollNumber": "8A-05",
      "academicYear": "2024-25",
      "admissionDate": "2024-04-01",
      "parentPhone": "+91 98765 43221"
    }
  ]
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Bulk upload completed: 2 successful, 0 failed",
  "data": {
    "success": 2,
    "failed": 0,
    "errors": []
  }
}
```

**Partial Success Response:**
```json
{
  "success": true,
  "message": "Bulk upload completed: 1 successful, 1 failed",
  "data": {
    "success": 1,
    "failed": 1,
    "errors": [
      {
        "admissionNumber": "PRAG-2024-003",
        "error": {
          "code": "DUPLICATE_ENTRY",
          "message": "A student with this admission number already exists"
        }
      }
    ]
  }
}
```

---

### 7. Promote Students
**Endpoint:** `POST /students/promote`

**Description:** Promote multiple students to the next class

**Required Permissions:** `Admin`, `Management`

**Request Body:**
```json
{
  "studentIds": [
    "PRAG-20241215-789",
    "PRAG-20241215-790",
    "PRAG-20241215-791"
  ],
  "newClass": "Class 6",
  "newAcademicYear": "2025-26"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Promotion completed: 3 successful, 0 failed",
  "data": {
    "successCount": 3,
    "failCount": 0,
    "errors": []
  }
}
```

---

### 8. Transfer Student
**Endpoint:** `POST /students/:id/transfer`

**Description:** Transfer a student to a different branch or organization

**Required Permissions:** `Admin` only

**Request Body:**
```json
{
  "newOrganizationId": 2,
  "newBranchId": 5,
  "transferDate": "2024-12-20",
  "reason": "Parent request - family relocation"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Student transferred successfully",
  "data": {
    "id": "123",
    "studentId": "PRAG-20241215-789",
    "organizationId": 2,
    "branchId": 5,
    "status": "Active"
  }
}
```

---

### 9. Mark as Passed Out
**Endpoint:** `POST /students/:id/passed-out`

**Description:** Mark a student as passed out/graduated

**Required Permissions:** `Admin`, `Management`

**Request Body:**
```json
{
  "passingDate": "2024-05-31",
  "finalClass": "Class 10",
  "remarks": "Successfully completed secondary education"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Student marked as passed out successfully",
  "data": {
    "id": "123",
    "studentId": "PRAG-20241215-789",
    "status": "Passed Out"
  }
}
```

---

### 10. Get Student Summary Statistics
**Endpoint:** `GET /students/summary`

**Description:** Get aggregated statistics about students

**Required Permissions:** `Admin`, `Management`

**Query Parameters:**
- `organizationId` (optional): Filter by organization
- `branchId` (optional): Filter by branch
- `academicYear` (optional): Filter by academic year

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "totalStudents": 450,
    "activeStudents": 425,
    "maleStudents": 240,
    "femaleStudents": 210,
    "byClass": {
      "Class 1": 45,
      "Class 2": 48,
      "Class 3": 50,
      "Class 4": 47,
      "Class 5": 52,
      "Class 6": 48,
      "Class 7": 45,
      "Class 8": 42,
      "Class 9": 38,
      "Class 10": 35
    },
    "byStatus": {
      "Active": 425,
      "Inactive": 15,
      "Passed Out": 10,
      "Transferred": 0
    },
    "byGender": {
      "Male": 240,
      "Female": 210
    }
  }
}
```

---

## Data Models

### Student Object
```typescript
interface Student {
  id: string;
  studentId: string;
  admissionNumber: string;
  firstName: string;
  lastName: string;
  fullName: string;
  dateOfBirth: Date;
  gender: 'Male' | 'Female' | 'Other';
  classGrade: string;
  section: string;
  rollNumber: string;
  academicYear: string;
  admissionDate: Date;
  status: 'Active' | 'Inactive' | 'Passed Out' | 'Transferred';
  email?: string;
  phone?: string;
  parentPhone: string;
  parentEmail?: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  bloodGroup?: string;
  caste?: string;
  religion?: string;
  photoUrl?: string;
  fatherName?: string;
  motherName?: string;
  guardianName?: string;
  organizationId?: number;
  branchId?: number;
  createdAt?: Date;
  updatedAt?: Date;
  createdBy?: number;
  updatedBy?: number;
}
```

---

## Error Codes

| Code | Description | HTTP Status |
|------|-------------|-------------|
| `VALIDATION_ERROR` | Input validation failed | 400 |
| `DUPLICATE_ENTRY` | Record with same identifier exists | 400 |
| `RESOURCE_NOT_FOUND` | Student not found | 404 |
| `AUTH_ERROR` | Authentication failed | 401 |
| `PERMISSION_DENIED` | Insufficient permissions | 403 |
| `DATABASE_ERROR` | Database operation failed | 500 |
| `SERVICE_ERROR` | Internal service error | 500 |
| `BULK_UPLOAD_ERROR` | Bulk upload operation failed | 500 |

---

## Rate Limiting
- **Standard**: 1000 requests/hour per user
- **Bulk Operations**: 10 requests/hour
- **Burst Limit**: 20 requests/minute

---

## Best Practices

### 1. Pagination
Always use pagination for list endpoints to avoid performance issues:
```
GET /students?page=1&limit=20
```

### 2. Search Optimization
Use specific filters when possible instead of broad searches:
```
# Good
GET /students?classGrade=Class 5&section=A

# Less Efficient
GET /students?search=class 5 section a
```

### 3. Bulk Operations
- Use bulk upload for >10 students
- Validate data locally before upload
- Handle partial failures gracefully

### 4. Data Validation
- Validate admission number format before submission
- Check email/phone formats
- Ensure dates are in ISO 8601 format

### 5. Security
- Never expose student PII unnecessarily
- Use field-level permissions
- Log all CRUD operations for audit trail

---

## Integration Examples

### JavaScript/TypeScript
```typescript
// Create Student
const response = await fetch('https://api.sriven.edu.in/v1/students', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    admissionNumber: 'PRAG-2024-001',
    firstName: 'Rajesh',
    lastName: 'Kumar',
    // ... other fields
  })
});

const data = await response.json();
if (data.success) {
  console.log('Student created:', data.data);
} else {
  console.error('Error:', data.error);
}
```

### Get Students with Filters
```typescript
const params = new URLSearchParams({
  page: '1',
  limit: '20',
  classGrade: 'Class 5',
  status: 'Active'
});

const response = await fetch(`https://api.sriven.edu.in/v1/students?${params}`, {
  headers: {
    'Authorization': `Bearer ${token}`
  }
});

const data = await response.json();
console.log('Students:', data.data);
console.log('Total Pages:', data.pagination.totalPages);
```

---

## Change Log

**Version 1.0** (December 15, 2024)
- Initial release
- Complete CRUD operations
- Bulk upload support
- Promotion and transfer functionality
- Comprehensive filtering and search

---

**For support or questions:**
- Technical: api-support@sriven.edu.in
- Documentation: docs@sriven.edu.in
