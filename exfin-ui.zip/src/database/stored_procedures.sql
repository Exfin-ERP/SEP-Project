-- Stored Procedures for Sri Venkateswara Enterprises Database
-- These procedures handle common database operations and business logic

USE sriviswa_finance;

DELIMITER //

-- ==========================================
-- 1. PROCEDURE: User Authentication
-- ==========================================
CREATE PROCEDURE AuthenticateUser(
    IN p_email VARCHAR(100),
    IN p_phone VARCHAR(15),
    IN p_otp_code VARCHAR(6)
)
BEGIN
    DECLARE user_count INT DEFAULT 0;
    DECLARE otp_valid BOOLEAN DEFAULT FALSE;
    
    -- Check if user exists and OTP is valid
    SELECT COUNT(*), 
           CASE WHEN COUNT(*) > 0 AND otp_code = p_otp_code AND otp_expires_at > NOW() 
                THEN TRUE ELSE FALSE END
    INTO user_count, otp_valid
    FROM users 
    WHERE (email = p_email OR phone = p_phone) 
    AND status = 'active';
    
    IF user_count > 0 AND otp_valid THEN
        -- Update last login and clear OTP
        UPDATE users 
        SET last_login = NOW(), otp_code = NULL, otp_expires_at = NULL
        WHERE (email = p_email OR phone = p_phone);
        
        -- Return user details
        SELECT u.id, u.email, u.phone, u.name, u.role, u.status,
               o.name as organization_name, t.name as team_name, b.name as branch_name
        FROM users u
        LEFT JOIN organizations o ON u.organization_id = o.id
        LEFT JOIN teams t ON u.team_id = t.id
        LEFT JOIN branches b ON u.branch_id = b.id
        WHERE (u.email = p_email OR u.phone = p_phone);
    ELSE
        SELECT NULL as id, 'Invalid credentials or OTP' as error_message;
    END IF;
END//

-- ==========================================
-- 2. PROCEDURE: Generate and Send OTP
-- ==========================================
CREATE PROCEDURE GenerateOTP(
    IN p_email VARCHAR(100),
    IN p_phone VARCHAR(15)
)
BEGIN
    DECLARE user_count INT DEFAULT 0;
    DECLARE new_otp VARCHAR(6);
    
    -- Check if user exists
    SELECT COUNT(*) INTO user_count
    FROM users 
    WHERE (email = p_email OR phone = p_phone) 
    AND status = 'active';
    
    IF user_count > 0 THEN
        -- Generate 6-digit OTP
        SET new_otp = LPAD(FLOOR(RAND() * 999999), 6, '0');
        
        -- Update user with new OTP (expires in 10 minutes)
        UPDATE users 
        SET otp_code = new_otp, 
            otp_expires_at = DATE_ADD(NOW(), INTERVAL 10 MINUTE)
        WHERE (email = p_email OR phone = p_phone);
        
        SELECT 'success' as status, new_otp as otp_code, 'OTP generated successfully' as message;
    ELSE
        SELECT 'error' as status, NULL as otp_code, 'User not found' as message;
    END IF;
END//

-- ==========================================
-- 3. PROCEDURE: Create New Expense
-- ==========================================
CREATE PROCEDURE CreateExpense(
    IN p_amount DECIMAL(15,2),
    IN p_category_id INT,
    IN p_description TEXT,
    IN p_nature_of_work TEXT,
    IN p_date DATE,
    IN p_notes TEXT,
    IN p_branch_id INT,
    IN p_payment_mode VARCHAR(20),
    IN p_payment_status VARCHAR(20),
    IN p_bill_status BOOLEAN,
    IN p_authorized_by VARCHAR(100),
    IN p_accountant_id INT,
    IN p_vendor_id INT
)
BEGIN
    DECLARE new_expense_code VARCHAR(30);
    DECLARE team_id INT;
    DECLARE expense_id INT;
    
    -- Generate expense code
    SET new_expense_code = CONCAT('EXP-', YEAR(p_date), '-', 
                                  LPAD((SELECT COALESCE(MAX(CAST(SUBSTRING(expense_code, -3) AS UNSIGNED)), 0) + 1 
                                        FROM expenses 
                                        WHERE expense_code LIKE CONCAT('EXP-', YEAR(p_date), '-%')), 3, '0'));
    
    -- Get team assignment based on branch
    SELECT team_id INTO team_id FROM branches WHERE id = p_branch_id;
    
    -- Insert new expense
    INSERT INTO expenses (
        expense_code, amount, category_id, description, nature_of_work, date, notes,
        branch_id, team_assigned_id, payment_mode, payment_status, bill_status,
        authorized_by, accountant_id, vendor_id, status
    ) VALUES (
        new_expense_code, p_amount, p_category_id, p_description, p_nature_of_work, p_date, p_notes,
        p_branch_id, team_id, p_payment_mode, p_payment_status, p_bill_status,
        p_authorized_by, p_accountant_id, p_vendor_id, 'Pending'
    );
    
    SET expense_id = LAST_INSERT_ID();
    
    -- Create notification for admin users
    INSERT INTO notifications (user_id, title, message, type, reference_type, reference_id)
    SELECT u.id, 'New Expense Pending Approval',
           CONCAT('Expense ', new_expense_code, ' worth ₹', FORMAT(p_amount, 2), ' is pending your approval from ', u2.name),
           'expense_pending', 'expense', expense_id
    FROM users u
    CROSS JOIN users u2
    WHERE u.role = 'Admin' AND u.status = 'active'
    AND u2.id = p_accountant_id;
    
    -- Log audit trail
    INSERT INTO audit_logs (user_id, action, table_name, record_id, new_values)
    VALUES (p_accountant_id, 'CREATE', 'expenses', expense_id, 
            JSON_OBJECT('expense_code', new_expense_code, 'amount', p_amount, 'status', 'Pending'));
    
    SELECT expense_id as id, new_expense_code as expense_code, 'Expense created successfully' as message;
END//

-- ==========================================
-- 4. PROCEDURE: Approve/Reject Expense
-- ==========================================
CREATE PROCEDURE UpdateExpenseStatus(
    IN p_expense_id INT,
    IN p_status VARCHAR(20),
    IN p_approved_by INT,
    IN p_rejection_reason TEXT
)
BEGIN
    DECLARE accountant_id INT;
    DECLARE expense_code VARCHAR(30);
    DECLARE amount DECIMAL(15,2);
    
    -- Get expense details
    SELECT accountant_id, expense_code, amount 
    INTO accountant_id, expense_code, amount
    FROM expenses 
    WHERE id = p_expense_id;
    
    -- Update expense status
    UPDATE expenses 
    SET status = p_status,
        approved_by = p_approved_by,
        approved_at = CASE WHEN p_status = 'Approved' THEN NOW() ELSE NULL END,
        rejection_reason = p_rejection_reason
    WHERE id = p_expense_id;
    
    -- Create notification for accountant
    INSERT INTO notifications (user_id, title, message, type, reference_type, reference_id)
    VALUES (accountant_id, 
            CONCAT('Expense ', CASE WHEN p_status = 'Approved' THEN 'Approved' ELSE 'Rejected' END),
            CONCAT('Your expense ', expense_code, ' for ₹', FORMAT(amount, 2), ' has been ', LOWER(p_status)),
            CASE WHEN p_status = 'Approved' THEN 'expense_approved' ELSE 'expense_rejected' END,
            'expense', p_expense_id);
    
    -- Log audit trail
    INSERT INTO audit_logs (user_id, action, table_name, record_id, new_values)
    VALUES (p_approved_by, 'UPDATE', 'expenses', p_expense_id, 
            JSON_OBJECT('status', p_status, 'approved_by', p_approved_by, 'approved_at', NOW()));
    
    SELECT 'success' as status, CONCAT('Expense ', p_status, ' successfully') as message;
END//

-- ==========================================
-- 5. PROCEDURE: Get Dashboard Data
-- ==========================================
CREATE PROCEDURE GetDashboardData(
    IN p_user_id INT,
    IN p_date_from DATE,
    IN p_date_to DATE
)
BEGIN
    DECLARE user_role VARCHAR(20);
    DECLARE user_branch_id INT;
    DECLARE user_team_id INT;
    
    -- Get user details
    SELECT role, branch_id, team_id 
    INTO user_role, user_branch_id, user_team_id
    FROM users 
    WHERE id = p_user_id;
    
    -- Return different data based on user role
    IF user_role = 'Admin' THEN
        -- Admin sees all data
        SELECT 
            COUNT(*) as total_expenses,
            COALESCE(SUM(amount), 0) as total_amount,
            COALESCE(SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END), 0) as pending_count,
            COALESCE(SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END), 0) as approved_count,
            COALESCE(SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END), 0) as rejected_count
        FROM expenses 
        WHERE date BETWEEN p_date_from AND p_date_to;
        
    ELSEIF user_role = 'Accountant' THEN
        -- Accountant sees only their data
        SELECT 
            COUNT(*) as total_expenses,
            COALESCE(SUM(amount), 0) as total_amount,
            COALESCE(SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END), 0) as pending_count,
            COALESCE(SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END), 0) as approved_count,
            COALESCE(SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END), 0) as rejected_count
        FROM expenses 
        WHERE accountant_id = p_user_id 
        AND date BETWEEN p_date_from AND p_date_to;
        
    ELSE
        -- Management/Viewer sees team/organization data
        SELECT 
            COUNT(*) as total_expenses,
            COALESCE(SUM(amount), 0) as total_amount,
            COALESCE(SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END), 0) as pending_count,
            COALESCE(SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END), 0) as approved_count,
            COALESCE(SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END), 0) as rejected_count
        FROM expenses e
        JOIN branches b ON e.branch_id = b.id
        WHERE b.team_id = user_team_id 
        AND e.date BETWEEN p_date_from AND p_date_to;
    END IF;
END//

-- ==========================================
-- 6. PROCEDURE: Update Balance Tracking
-- ==========================================
CREATE PROCEDURE UpdateBalanceTracking(
    IN p_date DATE,
    IN p_branch_id INT,
    IN p_team_id INT,
    IN p_opening_balance DECIMAL(15,2),
    IN p_credits DECIMAL(15,2),
    IN p_debits DECIMAL(15,2),
    IN p_created_by INT
)
BEGIN
    DECLARE closing_balance DECIMAL(15,2);
    DECLARE transaction_count INT;
    
    -- Calculate closing balance
    SET closing_balance = p_opening_balance + p_credits - p_debits;
    
    -- Get transaction count for the day
    SELECT COUNT(*) INTO transaction_count
    FROM expenses 
    WHERE branch_id = p_branch_id 
    AND DATE(created_at) = p_date;
    
    -- Insert or update balance tracking
    INSERT INTO balance_tracking (
        date, branch_id, team_id, opening_balance, closing_balance,
        total_credits, total_debits, transaction_count, created_by
    ) VALUES (
        p_date, p_branch_id, p_team_id, p_opening_balance, closing_balance,
        p_credits, p_debits, transaction_count, p_created_by
    ) ON DUPLICATE KEY UPDATE
        closing_balance = closing_balance,
        total_credits = p_credits,
        total_debits = p_debits,
        transaction_count = transaction_count,
        created_by = p_created_by;
    
    SELECT 'success' as status, 'Balance updated successfully' as message;
END//

-- ==========================================
-- 7. PROCEDURE: Get Pending Approvals
-- ==========================================
CREATE PROCEDURE GetPendingApprovals(
    IN p_team_id INT,
    IN p_limit INT
)
BEGIN
    SELECT 
        e.id,
        e.expense_code,
        e.amount,
        e.description,
        e.nature_of_work,
        e.date,
        e.payment_status,
        e.bill_status,
        e.created_at,
        u.name as accountant_name,
        b.name as branch_name,
        b.code as branch_code,
        c.name as category_name,
        t.name as team_name
    FROM expenses e
    JOIN users u ON e.accountant_id = u.id
    JOIN branches b ON e.branch_id = b.id
    JOIN expense_categories c ON e.category_id = c.id
    JOIN teams t ON e.team_assigned_id = t.id
    WHERE e.status = 'Pending'
    AND (p_team_id IS NULL OR e.team_assigned_id = p_team_id)
    ORDER BY e.created_at ASC
    LIMIT p_limit;
END//

DELIMITER ;

-- ==========================================
-- Create indexes for stored procedures
-- ==========================================
CREATE INDEX idx_expenses_accountant_date ON expenses(accountant_id, date);
CREATE INDEX idx_expenses_team_status ON expenses(team_assigned_id, status);
CREATE INDEX idx_expenses_branch_date ON expenses(branch_id, date);
CREATE INDEX idx_users_email_phone ON users(email, phone);
CREATE INDEX idx_balance_tracking_composite ON balance_tracking(date, branch_id, team_id);