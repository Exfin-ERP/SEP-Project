-- Database Views for Sri Venkateswara Enterprises
-- Views for simplified data access and reporting

USE sriviswa_finance;

-- ==========================================
-- 1. VIEW: Complete Expense Details
-- ==========================================
CREATE VIEW view_expense_details AS
SELECT 
    e.id,
    e.expense_code,
    e.amount,
    e.description,
    e.nature_of_work,
    e.date,
    e.notes,
    e.payment_mode,
    e.payment_status,
    e.bill_status,
    e.bill_number,
    e.bill_date,
    e.authorized_by,
    e.status,
    e.created_at,
    e.updated_at,
    e.approved_at,
    e.rejection_reason,
    
    -- Category details
    c.name as category_name,
    
    -- Branch details
    b.code as branch_code,
    b.name as branch_name,
    b.type as branch_type,
    
    -- Team details
    t.name as team_name,
    
    -- Organization details
    o.name as organization_name,
    o.code as organization_code,
    
    -- Accountant details
    accountant.name as accountant_name,
    accountant.email as accountant_email,
    accountant.phone as accountant_phone,
    
    -- Approver details
    approver.name as approved_by_name,
    
    -- Vendor details
    v.name as vendor_name,
    v.vendor_code as vendor_code,
    v.type as vendor_type
    
FROM expenses e
LEFT JOIN expense_categories c ON e.category_id = c.id
LEFT JOIN branches b ON e.branch_id = b.id
LEFT JOIN teams t ON e.team_assigned_id = t.id
LEFT JOIN organizations o ON b.organization_id = o.id
LEFT JOIN users accountant ON e.accountant_id = accountant.id
LEFT JOIN users approver ON e.approved_by = approver.id
LEFT JOIN vendors v ON e.vendor_id = v.id;

-- ==========================================
-- 2. VIEW: User Dashboard Summary
-- ==========================================
CREATE VIEW view_user_dashboard AS
SELECT 
    u.id as user_id,
    u.name as user_name,
    u.role,
    u.email,
    u.phone,
    
    -- Organization details
    o.name as organization_name,
    o.code as organization_code,
    
    -- Team details
    t.name as team_name,
    
    -- Branch details
    b.name as branch_name,
    b.code as branch_code,
    
    -- Summary statistics
    COALESCE(expense_stats.total_expenses, 0) as total_expenses,
    COALESCE(expense_stats.pending_expenses, 0) as pending_expenses,
    COALESCE(expense_stats.approved_expenses, 0) as approved_expenses,
    COALESCE(expense_stats.rejected_expenses, 0) as rejected_expenses,
    COALESCE(expense_stats.total_amount, 0) as total_amount,
    COALESCE(expense_stats.pending_amount, 0) as pending_amount
    
FROM users u
LEFT JOIN organizations o ON u.organization_id = o.id
LEFT JOIN teams t ON u.team_id = t.id
LEFT JOIN branches b ON u.branch_id = b.id
LEFT JOIN (
    SELECT 
        accountant_id,
        COUNT(*) as total_expenses,
        SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending_expenses,
        SUM(CASE WHEN status = 'Approved' THEN 1 ELSE 0 END) as approved_expenses,
        SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) as rejected_expenses,
        SUM(amount) as total_amount,
        SUM(CASE WHEN status = 'Pending' THEN amount ELSE 0 END) as pending_amount
    FROM expenses
    WHERE date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY accountant_id
) expense_stats ON u.id = expense_stats.accountant_id
WHERE u.status = 'active';

-- ==========================================
-- 3. VIEW: Monthly Expense Summary
-- ==========================================
CREATE VIEW view_monthly_expense_summary AS
SELECT 
    YEAR(e.date) as expense_year,
    MONTH(e.date) as expense_month,
    MONTHNAME(e.date) as month_name,
    
    -- Organization breakdown
    o.name as organization_name,
    o.code as organization_code,
    
    -- Team breakdown
    t.name as team_name,
    
    -- Category breakdown
    c.name as category_name,
    
    -- Summary statistics
    COUNT(*) as transaction_count,
    SUM(e.amount) as total_amount,
    AVG(e.amount) as average_amount,
    MIN(e.amount) as min_amount,
    MAX(e.amount) as max_amount,
    
    -- Status breakdown
    SUM(CASE WHEN e.status = 'Approved' THEN e.amount ELSE 0 END) as approved_amount,
    SUM(CASE WHEN e.status = 'Pending' THEN e.amount ELSE 0 END) as pending_amount,
    SUM(CASE WHEN e.status = 'Rejected' THEN e.amount ELSE 0 END) as rejected_amount,
    
    -- Payment status breakdown
    SUM(CASE WHEN e.payment_status = 'Paid' THEN e.amount ELSE 0 END) as paid_amount,
    SUM(CASE WHEN e.payment_status = 'Unpaid' THEN e.amount ELSE 0 END) as unpaid_amount,
    SUM(CASE WHEN e.payment_status = 'Advance' THEN e.amount ELSE 0 END) as advance_amount
    
FROM expenses e
LEFT JOIN expense_categories c ON e.category_id = c.id
LEFT JOIN branches b ON e.branch_id = b.id
LEFT JOIN teams t ON e.team_assigned_id = t.id
LEFT JOIN organizations o ON b.organization_id = o.id
GROUP BY 
    YEAR(e.date), MONTH(e.date), o.id, t.id, c.id
ORDER BY 
    expense_year DESC, expense_month DESC, organization_name, team_name, category_name;

-- ==========================================
-- 4. VIEW: Vendor Performance Summary
-- ==========================================
CREATE VIEW view_vendor_performance AS
SELECT 
    v.id as vendor_id,
    v.vendor_code,
    v.name as vendor_name,
    v.type as vendor_type,
    v.contact_person,
    v.email,
    v.phone,
    v.status as vendor_status,
    v.created_at as vendor_registered_date,
    
    -- Transaction statistics
    COALESCE(vendor_stats.total_transactions, 0) as total_transactions,
    COALESCE(vendor_stats.total_amount, 0) as total_amount,
    COALESCE(vendor_stats.avg_transaction_amount, 0) as avg_transaction_amount,
    COALESCE(vendor_stats.last_transaction_date, NULL) as last_transaction_date,
    
    -- Payment statistics
    COALESCE(vendor_stats.paid_amount, 0) as paid_amount,
    COALESCE(vendor_stats.unpaid_amount, 0) as unpaid_amount,
    COALESCE(vendor_stats.advance_amount, 0) as advance_amount,
    
    -- Performance metrics
    CASE 
        WHEN vendor_stats.total_transactions IS NULL THEN 'No Transactions'
        WHEN vendor_stats.unpaid_amount > vendor_stats.paid_amount THEN 'Payment Pending'
        WHEN vendor_stats.last_transaction_date < DATE_SUB(CURDATE(), INTERVAL 90 DAY) THEN 'Inactive'
        ELSE 'Active'
    END as performance_status
    
FROM vendors v
LEFT JOIN (
    SELECT 
        vendor_id,
        COUNT(*) as total_transactions,
        SUM(amount) as total_amount,
        AVG(amount) as avg_transaction_amount,
        MAX(date) as last_transaction_date,
        SUM(CASE WHEN payment_status = 'Paid' THEN amount ELSE 0 END) as paid_amount,
        SUM(CASE WHEN payment_status = 'Unpaid' THEN amount ELSE 0 END) as unpaid_amount,
        SUM(CASE WHEN payment_status = 'Advance' THEN amount ELSE 0 END) as advance_amount
    FROM expenses
    WHERE vendor_id IS NOT NULL
    GROUP BY vendor_id
) vendor_stats ON v.id = vendor_stats.vendor_id;

-- ==========================================
-- 5. VIEW: Branch Performance Summary
-- ==========================================
CREATE VIEW view_branch_performance AS
SELECT 
    b.id as branch_id,
    b.code as branch_code,
    b.name as branch_name,
    b.type as branch_type,
    b.student_count,
    b.monthly_collection,
    
    -- Organization details
    o.name as organization_name,
    o.code as organization_code,
    
    -- Team details
    t.name as team_name,
    
    -- Financial statistics (last 30 days)
    COALESCE(branch_stats.total_expenses, 0) as total_expenses_30d,
    COALESCE(branch_stats.total_amount, 0) as total_amount_30d,
    COALESCE(branch_stats.avg_expense, 0) as avg_expense_30d,
    COALESCE(branch_stats.pending_amount, 0) as pending_amount_30d,
    COALESCE(branch_stats.approved_amount, 0) as approved_amount_30d,
    
    -- Accountant information
    accountant_info.accountant_count,
    accountant_info.accountant_names,
    
    -- Performance metrics
    ROUND((COALESCE(branch_stats.total_amount, 0) / NULLIF(b.monthly_collection, 0)) * 100, 2) as expense_ratio_percent,
    CASE 
        WHEN branch_stats.total_amount IS NULL THEN 'No Activity'
        WHEN (branch_stats.total_amount / NULLIF(b.monthly_collection, 0)) > 0.5 THEN 'High Expense'
        WHEN (branch_stats.total_amount / NULLIF(b.monthly_collection, 0)) > 0.2 THEN 'Medium Expense'
        ELSE 'Low Expense'
    END as expense_category
    
FROM branches b
LEFT JOIN organizations o ON b.organization_id = o.id
LEFT JOIN teams t ON b.team_id = t.id
LEFT JOIN (
    SELECT 
        branch_id,
        COUNT(*) as total_expenses,
        SUM(amount) as total_amount,
        AVG(amount) as avg_expense,
        SUM(CASE WHEN status = 'Pending' THEN amount ELSE 0 END) as pending_amount,
        SUM(CASE WHEN status = 'Approved' THEN amount ELSE 0 END) as approved_amount
    FROM expenses
    WHERE date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY branch_id
) branch_stats ON b.id = branch_stats.branch_id
LEFT JOIN (
    SELECT 
        branch_id,
        COUNT(*) as accountant_count,
        GROUP_CONCAT(name ORDER BY name SEPARATOR ', ') as accountant_names
    FROM users
    WHERE role = 'Accountant' AND status = 'active'
    GROUP BY branch_id
) accountant_info ON b.id = accountant_info.branch_id
WHERE b.status = 'active';

-- ==========================================
-- 6. VIEW: Pending Approvals Summary
-- ==========================================
CREATE VIEW view_pending_approvals AS
SELECT 
    e.id as expense_id,
    e.expense_code,
    e.amount,
    e.description,
    e.nature_of_work,
    e.date as expense_date,
    e.payment_status,
    e.bill_status,
    e.created_at,
    DATEDIFF(CURDATE(), e.created_at) as days_pending,
    
    -- Accountant details
    accountant.name as accountant_name,
    accountant.email as accountant_email,
    accountant.phone as accountant_phone,
    
    -- Branch details
    b.name as branch_name,
    b.code as branch_code,
    b.type as branch_type,
    
    -- Team details
    t.name as team_name,
    
    -- Organization details  
    o.name as organization_name,
    
    -- Category details
    c.name as category_name,
    
    -- Priority classification
    CASE 
        WHEN DATEDIFF(CURDATE(), e.created_at) > 7 THEN 'High'
        WHEN DATEDIFF(CURDATE(), e.created_at) > 3 THEN 'Medium'
        ELSE 'Normal'
    END as priority,
    
    CASE 
        WHEN e.amount > 50000 THEN 'High Value'
        WHEN e.amount > 10000 THEN 'Medium Value'
        ELSE 'Low Value'
    END as amount_category
    
FROM expenses e
JOIN users accountant ON e.accountant_id = accountant.id
JOIN branches b ON e.branch_id = b.id
JOIN teams t ON e.team_assigned_id = t.id
JOIN organizations o ON b.organization_id = o.id
LEFT JOIN expense_categories c ON e.category_id = c.id
WHERE e.status = 'Pending'
ORDER BY e.created_at ASC;

-- ==========================================
-- 7. VIEW: Daily Balance Summary
-- ==========================================
CREATE VIEW view_daily_balance_summary AS
SELECT 
    bt.date,
    
    -- Branch details
    b.code as branch_code,
    b.name as branch_name,
    b.type as branch_type,
    
    -- Team details
    t.name as team_name,
    
    -- Organization details
    o.name as organization_name,
    
    -- Balance details
    bt.opening_balance,
    bt.closing_balance,
    bt.total_credits,
    bt.total_debits,
    bt.transaction_count,
    
    -- Calculated fields
    (bt.closing_balance - bt.opening_balance) as net_change,
    CASE 
        WHEN bt.closing_balance > bt.opening_balance THEN 'Positive'
        WHEN bt.closing_balance < bt.opening_balance THEN 'Negative'
        ELSE 'Neutral'
    END as balance_trend,
    
    -- Weekly moving average
    AVG(bt.closing_balance) OVER (
        PARTITION BY bt.branch_id, bt.team_id 
        ORDER BY bt.date 
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as weekly_avg_balance
    
FROM balance_tracking bt
JOIN branches b ON bt.branch_id = b.id
JOIN teams t ON bt.team_id = t.id
JOIN organizations o ON b.organization_id = o.id
ORDER BY bt.date DESC, organization_name, team_name, branch_name;

-- ==========================================
-- Create indexes for view performance
-- ==========================================
CREATE INDEX idx_expenses_date_status ON expenses(date, status);
CREATE INDEX idx_expenses_vendor_date ON expenses(vendor_id, date);
CREATE INDEX idx_balance_tracking_date_branch ON balance_tracking(date, branch_id);
CREATE INDEX idx_users_role_status ON users(role, status);