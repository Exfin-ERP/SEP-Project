-- ==========================================
-- SAMPLE DATA FOR REVENUE & EXPENDITURE MANAGEMENT
-- Sri Venkateswara Enterprises
-- Educational Institution Finance System
-- ==========================================

-- Note: This assumes organizations, branches, and users tables are already populated
-- Refer to the main sample_data.sql for those inserts

-- ==========================================
-- 1. INSERT CLASSES/COURSES
-- ==========================================
INSERT INTO classes (class_name, class_type, department, organization_id, is_active) VALUES
-- Pragyana Educational Society (Primary/Secondary)
('Class 1', 'Primary', 'Primary Education', 1, TRUE),
('Class 2', 'Primary', 'Primary Education', 1, TRUE),
('Class 3', 'Primary', 'Primary Education', 1, TRUE),
('Class 4', 'Primary', 'Primary Education', 1, TRUE),
('Class 5', 'Primary', 'Primary Education', 1, TRUE),
('Class 6', 'Secondary', 'Secondary Education', 1, TRUE),
('Class 7', 'Secondary', 'Secondary Education', 1, TRUE),
('Class 8', 'Secondary', 'Secondary Education', 1, TRUE),
('Class 9', 'Higher Secondary', 'Higher Education', 1, TRUE),
('Class 10', 'Higher Secondary', 'Higher Education', 1, TRUE),

-- Sriven Educational Society (Colleges)
('B.Tech - Computer Science', 'Undergraduate', 'Engineering', 2, TRUE),
('B.Tech - Electronics', 'Undergraduate', 'Engineering', 2, TRUE),
('MBA', 'Postgraduate', 'Management', 2, TRUE),
('B.Pharmacy', 'Undergraduate', 'Pharmacy', 2, TRUE),
('M.Pharmacy', 'Postgraduate', 'Pharmacy', 2, TRUE);

-- ==========================================
-- 2. INSERT FEE MASTER DATA
-- ==========================================
INSERT INTO fee_master (fee_code, fee_name, fee_category, amount, is_mandatory, frequency, organization_id, class_id, academic_year, is_active, effective_from) VALUES
-- Primary School Fees (Classes 1-5)
('TF-P1-2425', 'Tuition Fee - Class 1', 'Tuition', 15000.00, TRUE, 'Annual', 1, 1, '2024-25', TRUE, '2024-04-01'),
('TF-P2-2425', 'Tuition Fee - Class 2', 'Tuition', 16000.00, TRUE, 'Annual', 1, 2, '2024-25', TRUE, '2024-04-01'),
('TF-P3-2425', 'Tuition Fee - Class 3', 'Tuition', 17000.00, TRUE, 'Annual', 1, 3, '2024-25', TRUE, '2024-04-01'),
('AF-P-2425', 'Admission Fee - Primary', 'Admission', 5000.00, TRUE, 'One Time', 1, NULL, '2024-25', TRUE, '2024-04-01'),
('LF-P-2425', 'Library Fee - Primary', 'Library', 1000.00, TRUE, 'Annual', 1, NULL, '2024-25', TRUE, '2024-04-01'),
('TRF-P-2425', 'Transport Fee - Primary', 'Transport', 8000.00, FALSE, 'Annual', 1, NULL, '2024-25', TRUE, '2024-04-01'),
('SF-P-2425', 'Sports Fee - Primary', 'Sports', 1500.00, TRUE, 'Annual', 1, NULL, '2024-25', TRUE, '2024-04-01'),

-- Secondary/Higher Secondary Fees (Classes 6-10)
('TF-S6-2425', 'Tuition Fee - Class 6', 'Tuition', 20000.00, TRUE, 'Annual', 1, 6, '2024-25', TRUE, '2024-04-01'),
('TF-S9-2425', 'Tuition Fee - Class 9', 'Tuition', 25000.00, TRUE, 'Annual', 1, 9, '2024-25', TRUE, '2024-04-01'),
('TF-S10-2425', 'Tuition Fee - Class 10', 'Tuition', 28000.00, TRUE, 'Annual', 1, 10, '2024-25', TRUE, '2024-04-01'),
('LBF-S-2425', 'Lab Fee - Secondary', 'Lab', 3000.00, TRUE, 'Annual', 1, NULL, '2024-25', TRUE, '2024-04-01'),
('EF-S-2425', 'Exam Fee - Secondary', 'Exam', 2000.00, TRUE, 'Annual', 1, NULL, '2024-25', TRUE, '2024-04-01'),

-- College Fees (B.Tech, MBA, Pharmacy)
('TF-BTECH-2425', 'Tuition Fee - B.Tech', 'Tuition', 85000.00, TRUE, 'Annual', 2, 11, '2024-25', TRUE, '2024-04-01'),
('TF-MBA-2425', 'Tuition Fee - MBA', 'Tuition', 95000.00, TRUE, 'Annual', 2, 13, '2024-25', TRUE, '2024-04-01'),
('TF-BPHARM-2425', 'Tuition Fee - B.Pharmacy', 'Tuition', 75000.00, TRUE, 'Annual', 2, 14, '2024-25', TRUE, '2024-04-01'),
('LBF-BTECH-2425', 'Lab Fee - B.Tech', 'Lab', 15000.00, TRUE, 'Annual', 2, 11, '2024-25', TRUE, '2024-04-01'),
('HF-COLL-2425', 'Hostel Fee - College', 'Hostel', 45000.00, FALSE, 'Annual', 2, NULL, '2024-25', TRUE, '2024-04-01'),
('MF-COLL-2425', 'Mess Fee - College', 'Mess', 3500.00, FALSE, 'Monthly', 2, NULL, '2024-25', TRUE, '2024-04-01');

-- ==========================================
-- 3. INSERT SAMPLE STUDENTS
-- ==========================================
INSERT INTO students (student_id, admission_number, first_name, last_name, date_of_birth, gender, class_id, section, roll_number, academic_year, admission_date, status, parent_phone, parent_email, organization_id, branch_id, created_by) VALUES
-- Pragyana Students
('STU001', 'PRAG-2024-001', 'Rajesh', 'Kumar', '2014-05-15', 'Male', 5, 'A', '5A-01', '2024-25', '2024-04-01', 'Active', '9876543210', 'rajesh.parent@email.com', 1, 1, 1),
('STU002', 'PRAG-2024-002', 'Priya', 'Sharma', '2013-08-22', 'Female', 6, 'B', '6B-12', '2024-25', '2024-04-01', 'Active', '9876543211', 'priya.parent@email.com', 1, 1, 1),
('STU003', 'PRAG-2024-003', 'Arun', 'Reddy', '2012-03-10', 'Male', 8, 'A', '8A-05', '2024-25', '2024-04-01', 'Active', '9876543212', 'arun.parent@email.com', 1, 2, 1),
('STU004', 'PRAG-2024-004', 'Sneha', 'Patel', '2010-11-30', 'Female', 10, 'C', '10C-20', '2024-25', '2024-04-01', 'Active', '9876543213', 'sneha.parent@email.com', 1, 2, 1),

-- Sriven College Students
('STU101', 'SRIV-2024-101', 'Manikanta', 'Rao', '2002-07-14', 'Male', 11, 'CSE-A', 'CSE-A-25', '2024-25', '2024-08-01', 'Active', '9876543220', 'manikanta@email.com', 2, 3, 1),
('STU102', 'SRIV-2024-102', 'Kavya', 'Reddy', '2003-02-20', 'Female', 11, 'CSE-B', 'CSE-B-15', '2024-25', '2024-08-01', 'Active', '9876543221', 'kavya@email.com', 2, 3, 1),
('STU103', 'SRIV-2024-103', 'Vikram', 'Singh', '2001-09-05', 'Male', 13, 'MBA-A', 'MBA-A-10', '2024-25', '2024-08-01', 'Active', '9876543222', 'vikram@email.com', 2, 5, 1),
('STU104', 'SRIV-2024-104', 'Anjali', 'Nair', '2002-12-18', 'Female', 14, 'PHARM-A', 'PHARM-A-08', '2024-25', '2024-08-01', 'Active', '9876543223', 'anjali@email.com', 2, 6, 1);

-- ==========================================
-- 4. INSERT STAFF DATA
-- ==========================================
INSERT INTO staff (staff_id, employee_code, first_name, last_name, date_of_birth, gender, designation, department, date_of_joining, employment_type, status, basic_salary, gross_salary, phone, email, organization_id, branch_id, created_by) VALUES
-- Teaching Staff
('STAF001', 'EMP-2020-001', 'Ramesh', 'Babu', '1985-06-12', 'Male', 'Senior Teacher', 'Primary Education', '2020-06-01', 'Permanent', 'Active', 35000.00, 42000.00, '9876540001', 'ramesh.babu@sriven.edu.in', 1, 1, 1),
('STAF002', 'EMP-2019-015', 'Lakshmi', 'Devi', '1980-03-25', 'Female', 'Principal', 'Administration', '2019-04-01', 'Permanent', 'Active', 55000.00, 68000.00, '9876540002', 'lakshmi@sriven.edu.in', 1, 1, 1),
('STAF003', 'EMP-2021-032', 'Suresh', 'Kumar', '1990-09-18', 'Male', 'Assistant Professor', 'Computer Science', '2021-08-01', 'Permanent', 'Active', 45000.00, 55000.00, '9876540003', 'suresh@sriven.edu.in', 2, 3, 1),

-- Non-Teaching Staff
('STAF004', 'EMP-2018-005', 'Rajani', 'Kumari', '1988-11-05', 'Female', 'Accountant', 'Finance', '2018-07-01', 'Permanent', 'Active', 28000.00, 35000.00, '9876540004', 'rajani@sriven.edu.in', 1, 1, 1),
('STAF005', 'EMP-2022-048', 'Venkat', 'Rao', '1995-02-14', 'Male', 'Lab Assistant', 'Engineering', '2022-01-10', 'Contract', 'Active', 18000.00, 22000.00, '9876540005', 'venkat@sriven.edu.in', 2, 3, 1),
('STAF006', 'EMP-2020-025', 'Padma', 'Latha', '1987-07-22', 'Female', 'Office Administrator', 'Administration', '2020-03-15', 'Permanent', 'Active', 25000.00, 30000.00, '9876540006', 'padma@sriven.edu.in', 2, 5, 1);

-- ==========================================
-- 5. INSERT VENDORS
-- ==========================================
INSERT INTO vendors (vendor_code, vendor_name, vendor_type, vendor_category, contact_person, email, phone, address, city, state, gst_number, pan_number, payment_terms, credit_days, organization_id, is_active, created_by) VALUES
('VEN001', 'City Electricity Board', 'Utility', 'Electricity', 'Customer Care', 'care@cityelectricity.gov.in', '1800-123-456', 'Power House Road', 'Hyderabad', 'Telangana', NULL, NULL, 'Immediate', 0, 1, TRUE, 1),
('VEN002', 'Bharat Gas Corporation', 'Supplier', 'LPG/Fuel', 'Sales Manager', 'sales@bharatgas.com', '9876540010', 'Gas Godown, Industrial Area', 'Hyderabad', 'Telangana', '36ABCDE1234F1Z5', 'ABCDE1234F', 'Net 7', 7, 1, TRUE, 1),
('VEN003', 'Fresh Grocers Pvt Ltd', 'Supplier', 'Mess Supplies', 'Ravi Kumar', 'ravi@freshgrocers.com', '9876540011', 'Market Yard', 'Hyderabad', 'Telangana', '36FGHIJ5678K2L3', 'FGHIJ5678K', 'Net 15', 15, 2, TRUE, 1),
('VEN004', 'Tech Solutions India', 'Service Provider', 'IT Services', 'Sanjay Reddy', 'sanjay@techsolutions.in', '9876540012', 'Tech Park, Phase 2', 'Hyderabad', 'Telangana', '36MNOPQ9012R3S4', 'MNOPQ9012R', 'Net 30', 30, 2, TRUE, 1),
('VEN005', 'Building Maintenance Co', 'Service Provider', 'Maintenance', 'Prakash', 'prakash@buildmaint.com', '9876540013', 'Service Lane', 'Hyderabad', 'Telangana', '36UVWXY3456Z7A8', 'UVWXY3456Z', 'Net 7', 7, 1, TRUE, 1),
('VEN006', 'Stationary Mart', 'Supplier', 'Stationary', 'Sudhir', 'sudhir@stationarymart.com', '9876540014', 'Commercial Street', 'Hyderabad', 'Telangana', '36BCDEF6789G1H2', 'BCDEF6789G', 'Net 15', 15, 1, TRUE, 1);

-- ==========================================
-- 6. INSERT REVENUE TRANSACTIONS (Sample Data)
-- ==========================================
INSERT INTO revenue_transactions (transaction_id, receipt_number, revenue_type, student_id, student_name, class_grade, fee_id, fee_type, amount, payment_mode, payment_reference, transaction_date, payment_status, academic_year, financial_year, organization_id, branch_id, description, created_by) VALUES
-- Student Fee Payments - Primary School
('REV-2024-12-001', 'REC/2024/001', 'Student Fee', 'STU001', 'Rajesh Kumar', 'Class 5', 1, 'Tuition Fee', 15000.00, 'Online', 'UPI123456', '2024-12-01', 'Paid', '2024-25', '2024-25', 1, 1, 'Annual tuition fee payment for Class 5', 1),
('REV-2024-12-002', 'REC/2024/002', 'Student Fee', 'STU002', 'Priya Sharma', 'Class 6', 8, 'Tuition Fee', 20000.00, 'Cash', NULL, '2024-12-02', 'Paid', '2024-25', '2024-25', 1, 1, 'Annual tuition fee payment for Class 6', 1),
('REV-2024-12-003', 'REC/2024/003', 'Student Fee', 'STU003', 'Arun Reddy', 'Class 8', NULL, 'Library Fee', 1000.00, 'UPI', 'UPI789012', '2024-12-03', 'Paid', '2024-25', '2024-25', 1, 2, 'Library fee for academic year', 1),
('REV-2024-12-004', 'REC/2024/004', 'Student Fee', 'STU004', 'Sneha Patel', 'Class 10', 10, 'Tuition Fee', 28000.00, 'Cheque', 'CHQ456789', '2024-12-04', 'Paid', '2024-25', '2024-25', 1, 2, 'Class 10 annual tuition fee', 1),

-- Exam Fee Payments
('REV-2024-12-005', 'REC/2024/005', 'Examination Fee', 'STU004', 'Sneha Patel', 'Class 10', 12, 'Exam Fee', 2000.00, 'Online', 'NET890123', '2024-12-05', 'Paid', '2024-25', '2024-25', 1, 2, 'Board examination fee', 1),

-- College Fee Payments
('REV-2024-12-006', 'REC/2024/006', 'Student Fee', 'STU101', 'Manikanta Rao', 'B.Tech - CSE', 13, 'Tuition Fee', 85000.00, 'DD', 'DD567890', '2024-12-06', 'Paid', '2024-25', '2024-25', 2, 3, 'B.Tech annual tuition fee', 1),
('REV-2024-12-007', 'REC/2024/007', 'Student Fee', 'STU102', 'Kavya Reddy', 'B.Tech - CSE', 13, 'Tuition Fee', 85000.00, 'Online', 'NETBANK123', '2024-12-07', 'Paid', '2024-25', '2024-25', 2, 3, 'B.Tech annual tuition fee', 1),
('REV-2024-12-008', 'REC/2024/008', 'Mess Fee', 'STU101', 'Manikanta Rao', 'B.Tech - CSE', 18, 'Mess Fee', 3500.00, 'UPI', 'UPI234567', '2024-12-08', 'Paid', '2024-25', '2024-25', 2, 3, 'Mess fee for December 2024', 1),
('REV-2024-12-009', 'REC/2024/009', 'Student Fee', 'STU103', 'Vikram Singh', 'MBA', 14, 'Tuition Fee', 95000.00, 'Online', 'IMPS456789', '2024-12-09', 'Paid', '2024-25', '2024-25', 2, 5, 'MBA annual tuition fee', 1),

-- Donations
('REV-2024-12-010', 'REC/2024/010', 'Donation/Grant', NULL, NULL, NULL, NULL, NULL, 50000.00, 'Cheque', 'CHQ789012', '2024-12-10', 'Paid', '2024-25', '2024-25', 1, 1, 'Infrastructure development donation', 1),
('REV-2024-12-011', 'REC/2024/011', 'Donation/Grant', NULL, NULL, NULL, NULL, NULL, 100000.00, 'Online', 'NEFT345678', '2024-12-11', 'Paid', '2024-25', '2024-25', 2, 3, 'Computer lab equipment donation', 1),

-- Other Income
('REV-2024-12-012', 'REC/2024/012', 'Other Income', NULL, NULL, NULL, NULL, NULL, 8000.00, 'Cash', NULL, '2024-12-12', 'Paid', '2024-25', '2024-25', 1, 1, 'Canteen rental income for December', 1),
('REV-2024-12-013', 'REC/2024/013', 'Other Income', NULL, NULL, NULL, NULL, NULL, 15000.00, 'Online', 'UPI678901', '2024-12-13', 'Paid', '2024-25', '2024-25', 2, 3, 'Annual day event ticket sales', 1);

-- ==========================================
-- 7. INSERT EXPENDITURE TRANSACTIONS (Sample Data)
-- ==========================================
INSERT INTO expenditure_transactions (transaction_id, category, staff_id, staff_name, designation, salary_month, gross_salary, deductions, net_pay, amount, payment_mode, transaction_date, payment_status, approval_status, financial_year, organization_id, branch_id, description, created_by) VALUES
-- Salary Payments
('EXP-2024-12-001', 'Salaries', 'STAF001', 'Ramesh Babu', 'Senior Teacher', 'December 2024', 42000.00, 3360.00, 38640.00, 38640.00, 'Online', '2024-12-01', 'Paid', 'Approved', '2024-25', 1, 1, 'Salary for December 2024', 1),
('EXP-2024-12-002', 'Salaries', 'STAF002', 'Lakshmi Devi', 'Principal', 'December 2024', 68000.00, 6120.00, 61880.00, 61880.00, 'Online', '2024-12-01', 'Paid', 'Approved', '2024-25', 1, 1, 'Salary for December 2024', 1),
('EXP-2024-12-003', 'Salaries', 'STAF003', 'Suresh Kumar', 'Assistant Professor', 'December 2024', 55000.00, 4950.00, 50050.00, 50050.00, 'Online', '2024-12-01', 'Paid', 'Approved', '2024-25', 2, 3, 'Salary for December 2024', 1),
('EXP-2024-12-004', 'Salaries', 'STAF004', 'Rajani Kumari', 'Accountant', 'December 2024', 35000.00, 2800.00, 32200.00, 32200.00, 'Online', '2024-12-01', 'Paid', 'Approved', '2024-25', 1, 1, 'Salary for December 2024', 1);

-- Utility Payments
INSERT INTO expenditure_transactions (transaction_id, category, vendor_id, vendor_name, bill_number, amount, payment_mode, transaction_date, due_date, payment_status, approval_status, tds_applicable, gst_applicable, financial_year, organization_id, branch_id, description, created_by) VALUES
('EXP-2024-12-005', 'Rent & Utilities', 1, 'City Electricity Board', 'EB/2024/12/001', 45000.00, 'Online', '2024-12-05', '2024-12-10', 'Paid', 'Approved', FALSE, FALSE, '2024-25', 1, 1, 'Electricity bill for November 2024', 1),
('EXP-2024-12-006', 'Rent & Utilities', 1, 'City Electricity Board', 'EB/2024/12/002', 38000.00, 'Online', '2024-12-05', '2024-12-10', 'Paid', 'Approved', FALSE, FALSE, '2024-25', 1, 2, 'Electricity bill for November 2024', 1),
('EXP-2024-12-007', 'Rent & Utilities', 2, 'Bharat Gas Corporation', 'GAS/2024/456', 12000.00, 'Cheque', '2024-12-06', '2024-12-13', 'Paid', 'Approved', FALSE, TRUE, '2024-25', 2, 3, 'LPG cylinders for mess', 1);

-- Purchases
INSERT INTO expenditure_transactions (transaction_id, category, vendor_id, vendor_name, item_name, quantity, rate, invoice_number, amount, payment_mode, transaction_date, payment_status, approval_status, gst_applicable, gst_amount, financial_year, organization_id, branch_id, description, created_by) VALUES
('EXP-2024-12-008', 'Purchases', 3, 'Fresh Grocers Pvt Ltd', 'Groceries for Mess', 1.00, 25000.00, 'INV/FG/2024/789', 25000.00, 'Online', '2024-12-07', 'Paid', 'Approved', TRUE, 1250.00, '2024-25', 2, 3, 'Monthly grocery supplies for college mess', 1),
('EXP-2024-12-009', 'Purchases', 6, 'Stationary Mart', 'Office Stationary', 1.00, 8500.00, 'INV/SM/2024/123', 8500.00, 'Cash', '2024-12-08', 'Paid', 'Approved', TRUE, 425.00, '2024-25', 1, 1, 'Stationary for office and classrooms', 1);

-- Maintenance
INSERT INTO expenditure_transactions (transaction_id, category, vendor_id, vendor_name, service_type, amount, payment_mode, transaction_date, payment_status, approval_status, tds_applicable, tds_amount, financial_year, organization_id, branch_id, description, created_by) VALUES
('EXP-2024-12-010', 'Maintenance', 5, 'Building Maintenance Co', 'Building Maintenance', 15000.00, 'Cheque', '2024-12-09', 'Paid', 'Approved', TRUE, 150.00, '2024-25', 1, 1, 'Roof repair and painting work', 1),
('EXP-2024-12-011', 'Maintenance', 4, 'Tech Solutions India', 'Equipment Repair', 22000.00, 'Online', '2024-12-10', 'Paid', 'Approved', TRUE, 220.00, '2024-25', 2, 3, 'Computer lab equipment maintenance', 1);

-- Events
INSERT INTO expenditure_transactions (transaction_id, category, event_name, budget_allocated, actual_spend, amount, payment_mode, transaction_date, payment_status, approval_status, financial_year, organization_id, branch_id, description, created_by) VALUES
('EXP-2024-12-012', 'Events & Activities', 'Annual Day Celebration', 50000.00, 48500.00, 48500.00, 'Cash', '2024-12-11', 'Paid', 'Approved', '2024-25', 1, 1, 'Annual day event expenses including decorations, prizes, refreshments', 1),
('EXP-2024-12-013', 'Events & Activities', 'Tech Fest 2024', 75000.00, 72000.00, 72000.00, 'Online', '2024-12-12', 'Paid', 'Approved', '2024-25', 2, 3, 'Technical fest organizing expenses', 1);

-- Miscellaneous
INSERT INTO expenditure_transactions (transaction_id, category, amount, payment_mode, transaction_date, payment_status, approval_status, financial_year, organization_id, branch_id, description, created_by) VALUES
('EXP-2024-12-014', 'Miscellaneous', 5000.00, 'Cash', '2024-12-13', 'Paid', 'Approved', '2024-25', 1, 1, 'Guest lecture honorarium', 1),
('EXP-2024-12-015', 'Miscellaneous', 3500.00, 'Online', '2024-12-14', 'Pending', 'Pending', '2024-25', 2, 3, 'Office refreshments and pantry supplies', 1);

-- ==========================================
-- 8. REFRESH MATERIALIZED VIEWS
-- ==========================================
REFRESH MATERIALIZED VIEW revenue_summary_by_category;
REFRESH MATERIALIZED VIEW expenditure_summary_by_category;

-- ==========================================
-- VERIFICATION QUERIES
-- ==========================================

-- Check total revenue by organization
-- SELECT organization_id, SUM(amount) as total_revenue 
-- FROM revenue_transactions 
-- WHERE is_deleted = FALSE 
-- GROUP BY organization_id;

-- Check total expenditure by category
-- SELECT category, SUM(amount) as total_expenditure 
-- FROM expenditure_transactions 
-- WHERE is_deleted = FALSE 
-- GROUP BY category 
-- ORDER BY total_expenditure DESC;

-- Check pending approvals
-- SELECT COUNT(*) as pending_approvals 
-- FROM expenditure_transactions 
-- WHERE approval_status = 'Pending' AND is_deleted = FALSE;

-- Revenue vs Expenditure Summary
-- SELECT 
--     'Revenue' as type, 
--     SUM(amount) as total 
-- FROM revenue_transactions 
-- WHERE is_deleted = FALSE
-- UNION ALL
-- SELECT 
--     'Expenditure' as type, 
--     SUM(amount) as total 
-- FROM expenditure_transactions 
-- WHERE is_deleted = FALSE;
