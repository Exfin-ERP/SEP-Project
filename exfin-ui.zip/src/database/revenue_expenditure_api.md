# Revenue & Expenditure API Endpoints Documentation
## Sri Venkateswara Enterprises - Educational Finance System

---

## Table of Contents
1. [Revenue Management APIs](#revenue-management-apis)
2. [Expenditure Management APIs](#expenditure-management-apis)
3. [Master Data APIs](#master-data-apis)
4. [Reports & Analytics APIs](#reports--analytics-apis)
5. [Common Response Formats](#common-response-formats)

---

## Base URL
```
Production: https://api.sriven.edu.in/v1
Development: http://localhost:3000/api/v1
```

## Authentication
All endpoints require JWT authentication via Bearer token in the Authorization header:
```
Authorization: Bearer <token>
```

---

## Revenue Management APIs

### 1. Create Revenue Transaction
**Endpoint:** `POST /revenue/transactions`

**Request Body:**
```json
{
  "revenue_type": "Student Fee",
  "student_id": "STU001",
  "student_name": "Rajesh Kumar",
  "class_grade": "Class 5",
  "fee_id": 1,
  "fee_type": "Tuition Fee",
  "amount": 15000.00,
  "payment_mode": "Online",
  "payment_reference": "UPI123456",
  "transaction_date": "2024-12-15",
  "payment_status": "Paid",
  "academic_year": "2024-25",
  "organization_id": 1,
  "branch_id": 1,
  "description": "Annual tuition fee payment",
  "remarks": "Full payment received"
}
```

**Response:** `201 Created`
```json
{
  "success": true,
  "message": "Revenue transaction created successfully",
  "data": {
    "id": 145,
    "transaction_id": "REV-2024-12-145",
    "receipt_number": "REC/2024/145",
    "amount": 15000.00,
    "created_at": "2024-12-15T10:30:00Z"
  }
}
```

### 2. Get Revenue Transactions
**Endpoint:** `GET /revenue/transactions`

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 20)
- `revenue_type` (optional): Filter by type
- `organization_id` (optional): Filter by organization
- `branch_id` (optional): Filter by branch
- `academic_year` (optional): Filter by academic year
- `student_id` (optional): Filter by student
- `from_date` (optional): Start date filter (YYYY-MM-DD)
- `to_date` (optional): End date filter (YYYY-MM-DD)
- `payment_status` (optional): Filter by status

**Example:**
```
GET /revenue/transactions?organization_id=1&academic_year=2024-25&page=1&limit=20
```

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "transactions": [
      {
        "id": 145,
        "transaction_id": "REV-2024-12-145",
        "receipt_number": "REC/2024/145",
        "revenue_type": "Student Fee",
        "student_name": "Rajesh Kumar",
        "class_grade": "Class 5",
        "fee_type": "Tuition Fee",
        "amount": 15000.00,
        "payment_mode": "Online",
        "payment_status": "Paid",
        "transaction_date": "2024-12-15",
        "academic_year": "2024-25",
        "created_at": "2024-12-15T10:30:00Z"
      }
    ],
    "pagination": {
      "current_page": 1,
      "total_pages": 8,
      "total_records": 145,
      "per_page": 20
    },
    "summary": {
      "total_amount": 2250000.00,
      "paid_amount": 2100000.00,
      "pending_amount": 150000.00
    }
  }
}
```

### 3. Get Revenue Transaction by ID
**Endpoint:** `GET /revenue/transactions/:id`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "id": 145,
    "transaction_id": "REV-2024-12-145",
    "receipt_number": "REC/2024/145",
    "revenue_type": "Student Fee",
    "student_id": "STU001",
    "student_name": "Rajesh Kumar",
    "class_grade": "Class 5",
    "fee_id": 1,
    "fee_type": "Tuition Fee",
    "amount": 15000.00,
    "payment_mode": "Online",
    "payment_reference": "UPI123456",
    "payment_status": "Paid",
    "transaction_date": "2024-12-15",
    "academic_year": "2024-25",
    "organization_id": 1,
    "branch_id": 1,
    "description": "Annual tuition fee payment",
    "remarks": "Full payment received",
    "created_by": {
      "id": 5,
      "name": "Chakradhar"
    },
    "created_at": "2024-12-15T10:30:00Z",
    "updated_at": "2024-12-15T10:30:00Z"
  }
}
```

### 4. Update Revenue Transaction
**Endpoint:** `PUT /revenue/transactions/:id`

**Request Body:**
```json
{
  "payment_status": "Paid",
  "payment_reference": "UPI123456-UPDATED",
  "remarks": "Payment confirmed"
}
```

**Response:** `200 OK`

### 5. Delete Revenue Transaction (Soft Delete)
**Endpoint:** `DELETE /revenue/transactions/:id`

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Revenue transaction deleted successfully"
}
```

### 6. Revenue Summary by Category
**Endpoint:** `GET /revenue/summary/by-category`

**Query Parameters:**
- `organization_id` (required)
- `academic_year` (optional)
- `from_date` (optional)
- `to_date` (optional)

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "categories": [
      {
        "revenue_type": "Student Fee",
        "transaction_count": 150,
        "total_amount": 1850000.00,
        "percentage": 62.5
      },
      {
        "revenue_type": "Examination Fee",
        "transaction_count": 80,
        "total_amount": 160000.00,
        "percentage": 5.4
      },
      {
        "revenue_type": "Donation/Grant",
        "transaction_count": 5,
        "total_amount": 250000.00,
        "percentage": 8.4
      }
    ],
    "total": 2960000.00
  }
}
```

---

## Expenditure Management APIs

### 1. Create Expenditure Transaction
**Endpoint:** `POST /expenditure/transactions`

**Request Body (Salary Example):**
```json
{
  "category": "Salaries",
  "staff_id": "STAF001",
  "staff_name": "Ramesh Babu",
  "designation": "Senior Teacher",
  "salary_month": "December 2024",
  "gross_salary": 42000.00,
  "deductions": 3360.00,
  "net_pay": 38640.00,
  "amount": 38640.00,
  "payment_mode": "Online",
  "transaction_date": "2024-12-01",
  "payment_status": "Paid",
  "approval_status": "Approved",
  "financial_year": "2024-25",
  "organization_id": 1,
  "branch_id": 1,
  "description": "Salary for December 2024"
}
```

**Request Body (Purchase Example):**
```json
{
  "category": "Purchases",
  "vendor_id": 3,
  "vendor_name": "Fresh Grocers Pvt Ltd",
  "item_name": "Groceries for Mess",
  "quantity": 1,
  "rate": 25000.00,
  "invoice_number": "INV/FG/2024/789",
  "amount": 25000.00,
  "payment_mode": "Online",
  "transaction_date": "2024-12-07",
  "payment_status": "Paid",
  "approval_status": "Approved",
  "gst_applicable": true,
  "gst_amount": 1250.00,
  "gst_percentage": 5.00,
  "financial_year": "2024-25",
  "organization_id": 2,
  "branch_id": 3,
  "description": "Monthly grocery supplies"
}
```

**Response:** `201 Created`
```json
{
  "success": true,
  "message": "Expenditure transaction created successfully",
  "data": {
    "id": 256,
    "transaction_id": "EXP-2024-12-256",
    "amount": 38640.00,
    "approval_required": false,
    "created_at": "2024-12-01T10:00:00Z"
  }
}
```

### 2. Get Expenditure Transactions
**Endpoint:** `GET /expenditure/transactions`

**Query Parameters:**
- `page`, `limit`, `category`, `organization_id`, `branch_id`
- `staff_id`, `vendor_id`, `financial_year`
- `payment_status`, `approval_status`
- `from_date`, `to_date`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "transactions": [
      {
        "id": 256,
        "transaction_id": "EXP-2024-12-256",
        "category": "Salaries",
        "staff_name": "Ramesh Babu",
        "designation": "Senior Teacher",
        "amount": 38640.00,
        "payment_mode": "Online",
        "payment_status": "Paid",
        "approval_status": "Approved",
        "transaction_date": "2024-12-01"
      }
    ],
    "pagination": {
      "current_page": 1,
      "total_pages": 13,
      "total_records": 256,
      "per_page": 20
    },
    "summary": {
      "total_amount": 3450000.00,
      "paid_amount": 3200000.00,
      "pending_amount": 250000.00,
      "pending_approvals": 15
    }
  }
}
```

### 3. Update Expenditure Transaction
**Endpoint:** `PUT /expenditure/transactions/:id`

**Request Body:**
```json
{
  "payment_status": "Paid",
  "paid_date": "2024-12-15",
  "payment_reference": "NEFT123456"
}
```

**Response:** `200 OK`

### 4. Approve/Reject Expenditure
**Endpoint:** `POST /expenditure/transactions/:id/approve`

**Request Body:**
```json
{
  "action": "approve",
  "remarks": "Approved by management"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Expenditure approved successfully",
  "data": {
    "id": 256,
    "approval_status": "Approved",
    "approved_by": 2,
    "approved_at": "2024-12-15T14:30:00Z"
  }
}
```

### 5. Expenditure Summary by Category
**Endpoint:** `GET /expenditure/summary/by-category`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "categories": [
      {
        "category": "Salaries",
        "transaction_count": 120,
        "total_amount": 2500000.00,
        "paid_amount": 2500000.00,
        "pending_amount": 0.00,
        "percentage": 72.5
      },
      {
        "category": "Rent & Utilities",
        "transaction_count": 45,
        "total_amount": 450000.00,
        "paid_amount": 400000.00,
        "pending_amount": 50000.00,
        "percentage": 13.0
      }
    ],
    "total": 3450000.00
  }
}
```

---

## Master Data APIs

### 1. Students
**Endpoints:**
- `GET /students` - List all students
- `GET /students/:id` - Get student details
- `POST /students` - Create student
- `PUT /students/:id` - Update student
- `DELETE /students/:id` - Delete student

### 2. Staff
**Endpoints:**
- `GET /staff` - List all staff
- `GET /staff/:id` - Get staff details
- `POST /staff` - Create staff
- `PUT /staff/:id` - Update staff

### 3. Vendors
**Endpoints:**
- `GET /vendors` - List all vendors
- `GET /vendors/:id` - Get vendor details
- `POST /vendors` - Create vendor
- `PUT /vendors/:id` - Update vendor

### 4. Fee Master
**Endpoints:**
- `GET /fees/master` - List all fees
- `GET /fees/master/:id` - Get fee details
- `POST /fees/master` - Create fee
- `PUT /fees/master/:id` - Update fee

---

## Reports & Analytics APIs

### 1. Financial Summary Report
**Endpoint:** `GET /reports/financial-summary`

**Query Parameters:**
- `organization_id` (required)
- `from_date` (required)
- `to_date` (required)
- `branch_id` (optional)

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "period": {
      "from": "2024-04-01",
      "to": "2024-12-31"
    },
    "revenue": {
      "total": 2960000.00,
      "by_category": {
        "Student Fee": 1850000.00,
        "Examination Fee": 160000.00,
        "Donation/Grant": 250000.00,
        "Other Income": 700000.00
      }
    },
    "expenditure": {
      "total": 3450000.00,
      "by_category": {
        "Salaries": 2500000.00,
        "Rent & Utilities": 450000.00,
        "Purchases": 300000.00,
        "Maintenance": 150000.00,
        "Events & Activities": 50000.00
      }
    },
    "balance": -490000.00,
    "profit_loss_percentage": -16.5
  }
}
```

### 2. Monthly Trends Report
**Endpoint:** `GET /reports/monthly-trends`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "months": [
      {
        "month": "Apr 2024",
        "revenue": 450000.00,
        "expenditure": 380000.00,
        "balance": 70000.00
      },
      {
        "month": "May 2024",
        "revenue": 380000.00,
        "expenditure": 420000.00,
        "balance": -40000.00
      }
    ]
  }
}
```

### 3. Student Fee Status Report
**Endpoint:** `GET /reports/student-fee-status`

**Response:** Detailed student-wise fee payment status

### 4. Pending Approvals Report
**Endpoint:** `GET /reports/pending-approvals`

**Response:** List of all pending expenditure approvals

---

## Common Response Formats

### Success Response
```json
{
  "success": true,
  "message": "Operation successful",
  "data": { }
}
```

### Error Response
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": [
      {
        "field": "amount",
        "message": "Amount must be greater than 0"
      }
    ]
  }
}
```

### HTTP Status Codes
- `200 OK` - Success
- `201 Created` - Resource created
- `400 Bad Request` - Invalid input
- `401 Unauthorized` - Authentication required
- `403 Forbidden` - Insufficient permissions
- `404 Not Found` - Resource not found
- `500 Internal Server Error` - Server error

---

## Error Codes

| Code | Description |
|------|-------------|
| `VALIDATION_ERROR` | Input validation failed |
| `AUTH_ERROR` | Authentication failed |
| `PERMISSION_DENIED` | Insufficient permissions |
| `RESOURCE_NOT_FOUND` | Requested resource not found |
| `DUPLICATE_ENTRY` | Duplicate record exists |
| `APPROVAL_REQUIRED` | Transaction requires approval |
| `AMOUNT_EXCEEDS_LIMIT` | Amount exceeds allowed limit |
| `DATABASE_ERROR` | Database operation failed |

---

## Rate Limiting
- 1000 requests per hour per user
- Burst limit: 20 requests per minute

## Best Practices
1. Always use HTTPS in production
2. Include proper error handling
3. Implement request retry logic with exponential backoff
4. Cache frequently accessed data
5. Use pagination for large datasets
6. Validate all inputs before submission
7. Store sensitive data encrypted
8. Implement proper logging for audit trail
