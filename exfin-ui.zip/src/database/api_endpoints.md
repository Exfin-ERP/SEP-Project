# Sri Venkateswara Enterprises API Endpoints Documentation

## Base URL
```
https://api.sriviswa-finance.com/v1
```

## Authentication
All API endpoints require authentication using JWT tokens obtained from the login endpoint.

### Headers
```
Authorization: Bearer <jwt_token>
Content-Type: application/json
```

---

## 1. Authentication Endpoints

### POST /auth/send-otp
Send OTP for login authentication.

**Request Body:**
```json
{
  "email": "user@sriviswa.edu.in",
  "phone": "+91-9876543210",
  "role": "Accountant"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "OTP sent successfully",
  "otp_expires_at": "2024-12-15T10:15:00Z"
}
```

### POST /auth/verify-otp
Verify OTP and login.

**Request Body:**
```json
{
  "email": "user@sriviswa.edu.in",
  "phone": "+91-9876543210",
  "otp_code": "123456"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "name": "Rajesh Kumar",
    "email": "rajesh@sriviswa.edu.in",
    "role": "Accountant",
    "organization": "Pragyana Educational Society",
    "team": "Pragyana Team",
    "branch": "Pragyana Main Campus"
  }
}
```

### POST /auth/logout
Logout and invalidate token.

**Response:**
```json
{
  "status": "success",
  "message": "Logged out successfully"
}
```

---

## 2. Dashboard Endpoints

### GET /dashboard/summary
Get dashboard summary data for the authenticated user.

**Query Parameters:**
```
?date_from=2024-12-01&date_to=2024-12-31
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "total_expenses": 125,
    "total_amount": 487500.00,
    "pending_count": 12,
    "approved_count": 98,
    "rejected_count": 15,
    "monthly_trends": [
      {"month": "Nov", "amount": 125000},
      {"month": "Dec", "amount": 187500}
    ],
    "category_breakdown": [
      {"category": "MESS EXPENSES", "amount": 145000, "percentage": 29.7},
      {"category": "ELECTRICITY EXPENSES", "amount": 98000, "percentage": 20.1}
    ]
  }
}
```

### GET /dashboard/balance
Get balance information for user's branch/team.

**Response:**
```json
{
  "status": "success",
  "data": {
    "opening_balance": 2456780.50,
    "closing_balance": 2398450.25,
    "total_credits": 69254.50,
    "total_debits": 127584.75,
    "net_change": -58330.25,
    "last_updated": "2024-12-15T09:30:00Z"
  }
}
```

---

## 3. Expense Management Endpoints

### GET /expenses
Get list of expenses based on user role and permissions.

**Query Parameters:**
```
?page=1&limit=20&status=Pending&date_from=2024-12-01&date_to=2024-12-31&branch_id=1&team_id=1
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "expenses": [
      {
        "id": 1,
        "expense_code": "EXP-2024-001",
        "amount": 45000.00,
        "description": "Mess van diesel and groceries",
        "nature_of_work": "Monthly mess expenses including diesel and supplies",
        "date": "2024-12-15",
        "payment_mode": "CASH",
        "payment_status": "Paid",
        "bill_status": true,
        "status": "Pending",
        "accountant_name": "Rajesh Kumar",
        "branch_name": "Sriven Main Campus",
        "team_name": "Sriven Team",
        "category_name": "MESS EXPENSES",
        "created_at": "2024-12-15T08:30:00Z"
      }
    ],
    "pagination": {
      "current_page": 1,
      "total_pages": 5,
      "total_records": 98,
      "limit": 20
    }
  }
}
```

### POST /expenses
Create a new expense entry.

**Request Body:**
```json
{
  "amount": 45000.00,
  "category_id": 2,
  "description": "Mess van diesel and groceries",
  "nature_of_work": "Monthly mess expenses including diesel for transportation and grocery supplies",
  "date": "2024-12-15",
  "notes": "Monthly mess expenses",
  "branch_id": 6,
  "payment_mode": "CASH",
  "payment_status": "Paid",
  "bill_status": true,
  "authorized_by": "PSN SIR",
  "vendor_id": 3,
  "attachments": [
    {
      "file_name": "bill_001.pdf",
      "file_data": "base64_encoded_file_data"
    }
  ]
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Expense created successfully",
  "data": {
    "id": 125,
    "expense_code": "EXP-2024-125",
    "team_assigned": "Sriven Team",
    "status": "Pending"
  }
}
```

### PUT /expenses/{id}
Update an existing expense.

**Request Body:** (Same as POST with updated fields)

**Response:**
```json
{
  "status": "success",
  "message": "Expense updated successfully"
}
```

### DELETE /expenses/{id}
Delete an expense (only allowed for pending expenses by the creator).

**Response:**
```json
{
  "status": "success",
  "message": "Expense deleted successfully"
}
```

### PUT /expenses/{id}/approve
Approve an expense (Admin/Management only).

**Request Body:**
```json
{
  "remarks": "Approved for payment processing"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Expense approved successfully"
}
```

### PUT /expenses/{id}/reject
Reject an expense (Admin/Management only).

**Request Body:**
```json
{
  "rejection_reason": "Insufficient supporting documents"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Expense rejected successfully"
}
```

---

## 4. Vendor Management Endpoints

### GET /vendors
Get list of vendors.

**Query Parameters:**
```
?page=1&limit=20&status=approved&type=mess&search=annapurna
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "vendors": [
      {
        "id": 3,
        "vendor_code": "VENDOR-003",
        "name": "Annapurna Catering Services",
        "type": "mess",
        "contact_person": "Sita Devi",
        "email": "sita@annapurna.com",
        "phone": "+91-9876543212",
        "address": "Kukatpally, Hyderabad, Telangana",
        "gst_number": "36MNOPQ9012R3S4",
        "status": "approved",
        "services": "Food catering and mess services",
        "registered_date": "2024-01-18T00:00:00Z"
      }
    ],
    "pagination": {
      "current_page": 1,
      "total_pages": 3,
      "total_records": 45,
      "limit": 20
    }
  }
}
```

### POST /vendors
Register a new vendor (Admin only).

**Request Body:**
```json
{
  "name": "New Vendor Services",
  "type": "maintenance",
  "contact_person": "John Doe",
  "email": "john@newvendor.com",
  "phone": "+91-9876543999",
  "address": "Business District, Hyderabad",
  "gst_number": "36ABCDE9999F1Z5",
  "pan_number": "ABCDE9999F",
  "bank_account_number": "999888777666",
  "bank_ifsc_code": "HDFC0009999",
  "bank_name": "HDFC Bank",
  "bank_account_holder": "New Vendor Services",
  "services": "Maintenance and repair services"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Vendor registered successfully",
  "data": {
    "id": 25,
    "vendor_code": "VENDOR-025",
    "status": "pending"
  }
}
```

### PUT /vendors/{id}/approve
Approve a vendor (Admin only).

**Response:**
```json
{
  "status": "success",
  "message": "Vendor approved successfully"
}
```

---

## 5. Branch/Campus Management Endpoints

### GET /branches
Get list of branches/campuses.

**Query Parameters:**
```
?type=school&team_id=1&organization_id=1
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "branches": [
      {
        "id": 1,
        "code": "PRAGYANA-MAIN",
        "name": "Pragyana Main Campus",
        "type": "school",
        "organization_name": "Pragyana Educational Society",
        "team_name": "Pragyana Team",
        "student_count": 450,
        "monthly_collection": 425000.00,
        "principal_name": "Dr. Rajesh Kumar",
        "phone": "+91-9876540001",
        "email": "main@pragyana.edu.in"
      }
    ]
  }
}
```

### GET /branches/{id}/performance
Get branch performance metrics.

**Response:**
```json
{
  "status": "success",
  "data": {
    "branch_id": 1,
    "branch_name": "Pragyana Main Campus",
    "total_expenses_30d": 125000.00,
    "expense_ratio_percent": 29.4,
    "expense_category": "Medium Expense",
    "accountant_count": 1,
    "pending_approvals": 5,
    "average_expense": 4500.00
  }
}
```

---

## 6. Team Management Endpoints

### GET /teams
Get list of teams.

**Response:**
```json
{
  "status": "success",
  "data": {
    "teams": [
      {
        "id": 1,
        "name": "Pragyana Team",
        "organization_name": "Pragyana Educational Society",
        "team_lead_name": "Rajesh Kumar",
        "branch_count": 5,
        "accountant_count": 3,
        "total_monthly_collection": 1975000.00
      }
    ]
  }
}
```

---

## 7. Reports & Analytics Endpoints

### GET /reports/monthly-summary
Get monthly financial summary.

**Query Parameters:**
```
?year=2024&month=12&team_id=1&organization_id=1
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "month": "December 2024",
    "total_expenses": 487500.00,
    "total_transactions": 125,
    "category_breakdown": [
      {"category": "MESS EXPENSES", "amount": 145000, "count": 25},
      {"category": "ELECTRICITY EXPENSES", "amount": 98000, "count": 12}
    ],
    "team_breakdown": [
      {"team": "Pragyana Team", "amount": 185000, "count": 45},
      {"team": "Sriven Team", "amount": 302500, "count": 80}
    ],
    "payment_status_breakdown": {
      "paid": 287500.00,
      "unpaid": 145000.00,
      "advance": 55000.00
    }
  }
}
```

### GET /reports/vendor-performance
Get vendor performance report.

**Response:**
```json
{
  "status": "success",
  "data": {
    "vendors": [
      {
        "vendor_name": "Annapurna Catering Services",
        "total_transactions": 25,
        "total_amount": 875000.00,
        "avg_transaction": 35000.00,
        "paid_amount": 650000.00,
        "unpaid_amount": 225000.00,
        "performance_status": "Active",
        "last_transaction_date": "2024-12-15"
      }
    ]
  }
}
```

---

## 8. Notification Endpoints

### GET /notifications
Get user notifications.

**Query Parameters:**
```
?unread_only=true&limit=20
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "notifications": [
      {
        "id": 1,
        "title": "New Expense Pending Approval",
        "message": "Expense EXP-2024-001 worth ₹45,000 is pending your approval",
        "type": "expense_pending",
        "is_read": false,
        "created_at": "2024-12-15T08:30:00Z",
        "reference_type": "expense",
        "reference_id": 1
      }
    ],
    "unread_count": 5
  }
}
```

### PUT /notifications/{id}/mark-read
Mark notification as read.

**Response:**
```json
{
  "status": "success",
  "message": "Notification marked as read"
}
```

---

## 9. File Upload Endpoints

### POST /files/upload
Upload file attachments.

**Request Body:** (multipart/form-data)
```
file: <file>
entity_type: expense
entity_id: 125
```

**Response:**
```json
{
  "status": "success",
  "message": "File uploaded successfully",
  "data": {
    "file_id": 45,
    "file_name": "bill_001.pdf",
    "file_path": "/uploads/expenses/2024/12/bill_001_xyz123.pdf",
    "file_size": 1024568
  }
}
```

---

## Error Responses

### Standard Error Format
```json
{
  "status": "error",
  "message": "Error description",
  "code": "ERROR_CODE",
  "details": {
    "field": "validation error details"
  }
}
```

### Common HTTP Status Codes
- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `422` - Validation Error
- `500` - Internal Server Error

---

## Rate Limiting
- API requests are limited to 100 requests per minute per user
- File uploads are limited to 10MB per file
- Bulk operations are limited to 100 records per request