-- Database Triggers for Sri Venkateswara Enterprises
-- Triggers for audit logging and business logic enforcement

USE sriviswa_finance;

DELIMITER //

-- ==========================================
-- 1. TRIGGER: Audit Trail for Expenses
-- ==========================================
CREATE TRIGGER expenses_audit_insert
AFTER INSERT ON expenses
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (
        user_id, action, table_name, record_id, new_values, created_at
    ) VALUES (
        NEW.accountant_id, 'INSERT', 'expenses', NEW.id,
        JSON_OBJECT(
            'expense_code', NEW.expense_code,
            'amount', NEW.amount,
            'description', NEW.description,
            'status', NEW.status,
            'payment_mode', NEW.payment_mode,
            'payment_status', NEW.payment_status,
            'branch_id', NEW.branch_id,
            'team_assigned_id', NEW.team_assigned_id
        ),
        NOW()
    );
END//

CREATE TRIGGER expenses_audit_update
AFTER UPDATE ON expenses
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (
        user_id, action, table_name, record_id, old_values, new_values, created_at
    ) VALUES (
        COALESCE(NEW.approved_by, NEW.accountant_id), 'UPDATE', 'expenses', NEW.id,
        JSON_OBJECT(
            'status', OLD.status,
            'approved_by', OLD.approved_by,
            'approved_at', OLD.approved_at,
            'amount', OLD.amount,
            'payment_status', OLD.payment_status
        ),
        JSON_OBJECT(
            'status', NEW.status,
            'approved_by', NEW.approved_by,
            'approved_at', NEW.approved_at,
            'amount', NEW.amount,
            'payment_status', NEW.payment_status
        ),
        NOW()
    );
END//

-- ==========================================
-- 2. TRIGGER: Audit Trail for Users
-- ==========================================
CREATE TRIGGER users_audit_update
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (
        user_id, action, table_name, record_id, old_values, new_values, created_at
    ) VALUES (
        NEW.id, 'UPDATE', 'users', NEW.id,
        JSON_OBJECT(
            'status', OLD.status,
            'role', OLD.role,
            'last_login', OLD.last_login,
            'organization_id', OLD.organization_id,
            'team_id', OLD.team_id
        ),
        JSON_OBJECT(
            'status', NEW.status,
            'role', NEW.role,
            'last_login', NEW.last_login,
            'organization_id', NEW.organization_id,
            'team_id', NEW.team_id
        ),
        NOW()
    );
END//

-- ==========================================
-- 3. TRIGGER: Audit Trail for Vendors
-- ==========================================
CREATE TRIGGER vendors_audit_insert
AFTER INSERT ON vendors
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (
        user_id, action, table_name, record_id, new_values, created_at
    ) VALUES (
        1, 'INSERT', 'vendors', NEW.id, -- Default to admin user ID 1
        JSON_OBJECT(
            'vendor_code', NEW.vendor_code,
            'name', NEW.name,
            'type', NEW.type,
            'status', NEW.status,
            'contact_person', NEW.contact_person,
            'email', NEW.email,
            'phone', NEW.phone
        ),
        NOW()
    );
END//

CREATE TRIGGER vendors_audit_update
AFTER UPDATE ON vendors
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (
        user_id, action, table_name, record_id, old_values, new_values, created_at
    ) VALUES (
        COALESCE(NEW.approved_by, 1), 'UPDATE', 'vendors', NEW.id,
        JSON_OBJECT(
            'status', OLD.status,
            'approved_by', OLD.approved_by,
            'approved_at', OLD.approved_at,
            'remarks', OLD.remarks
        ),
        JSON_OBJECT(
            'status', NEW.status,
            'approved_by', NEW.approved_by,
            'approved_at', NEW.approved_at,
            'remarks', NEW.remarks
        ),
        NOW()
    );
END//

-- ==========================================
-- 4. TRIGGER: Auto-generate expense code
-- ==========================================
CREATE TRIGGER expenses_generate_code
BEFORE INSERT ON expenses
FOR EACH ROW
BEGIN
    DECLARE next_number INT;
    DECLARE year_part VARCHAR(4);
    
    SET year_part = YEAR(NEW.date);
    
    -- Get next sequence number for the year
    SELECT COALESCE(MAX(CAST(SUBSTRING(expense_code, -3) AS UNSIGNED)), 0) + 1
    INTO next_number
    FROM expenses
    WHERE expense_code LIKE CONCAT('EXP-', year_part, '-%');
    
    -- Generate expense code
    SET NEW.expense_code = CONCAT('EXP-', year_part, '-', LPAD(next_number, 3, '0'));
END//

-- ==========================================
-- 5. TRIGGER: Auto-generate vendor code
-- ==========================================
CREATE TRIGGER vendors_generate_code
BEFORE INSERT ON vendors
FOR EACH ROW
BEGIN
    DECLARE next_number INT;
    
    -- Get next sequence number
    SELECT COALESCE(MAX(CAST(SUBSTRING(vendor_code, -3) AS UNSIGNED)), 0) + 1
    INTO next_number
    FROM vendors
    WHERE vendor_code LIKE 'VENDOR-%';
    
    -- Generate vendor code if not provided
    IF NEW.vendor_code IS NULL OR NEW.vendor_code = '' THEN
        SET NEW.vendor_code = CONCAT('VENDOR-', LPAD(next_number, 3, '0'));
    END IF;
END//

-- ==========================================
-- 6. TRIGGER: Validate expense business rules
-- ==========================================
CREATE TRIGGER expenses_validate_business_rules
BEFORE INSERT ON expenses
FOR EACH ROW
BEGIN
    DECLARE branch_team_id INT;
    DECLARE accountant_branch_id INT;
    
    -- Get team assignment for the branch
    SELECT team_id INTO branch_team_id
    FROM branches
    WHERE id = NEW.branch_id;
    
    -- Get accountant's assigned branch
    SELECT branch_id INTO accountant_branch_id
    FROM users
    WHERE id = NEW.accountant_id AND role = 'Accountant';
    
    -- Validate team assignment
    IF branch_team_id IS NOT NULL THEN
        SET NEW.team_assigned_id = branch_team_id;
    END IF;
    
    -- Validate accountant branch assignment (optional check)
    -- Uncomment if you want strict branch-accountant mapping
    /*
    IF accountant_branch_id IS NOT NULL AND accountant_branch_id != NEW.branch_id THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Accountant is not assigned to this branch';
    END IF;
    */
    
    -- Validate amount
    IF NEW.amount <= 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Expense amount must be greater than zero';
    END IF;
    
    -- Validate date (not future date)
    IF NEW.date > CURDATE() THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Expense date cannot be in the future';
    END IF;
END//

-- ==========================================
-- 7. TRIGGER: Update balance tracking on expense changes
-- ==========================================
CREATE TRIGGER expenses_update_balance_insert
AFTER INSERT ON expenses
FOR EACH ROW
BEGIN
    DECLARE current_date DATE DEFAULT CURDATE();
    DECLARE branch_team_id INT;
    
    -- Get branch team
    SELECT team_id INTO branch_team_id
    FROM branches
    WHERE id = NEW.branch_id;
    
    -- Update or insert balance tracking record
    INSERT INTO balance_tracking (
        date, branch_id, team_id, opening_balance, closing_balance,
        total_credits, total_debits, transaction_count, created_by
    ) VALUES (
        current_date, NEW.branch_id, branch_team_id, 0, 0,
        0, NEW.amount, 1, NEW.accountant_id
    ) ON DUPLICATE KEY UPDATE
        total_debits = total_debits + NEW.amount,
        transaction_count = transaction_count + 1,
        closing_balance = opening_balance + total_credits - (total_debits + NEW.amount);
END//

-- ==========================================
-- 8. TRIGGER: Auto-create notifications
-- ==========================================
CREATE TRIGGER expenses_create_notifications
AFTER INSERT ON expenses
FOR EACH ROW
BEGIN
    DECLARE accountant_name VARCHAR(100);
    
    -- Get accountant name
    SELECT name INTO accountant_name
    FROM users
    WHERE id = NEW.accountant_id;
    
    -- Create notifications for admin users in the same organization
    INSERT INTO notifications (user_id, title, message, type, reference_type, reference_id)
    SELECT u.id, 
           'New Expense Pending Approval',
           CONCAT('Expense ', NEW.expense_code, ' worth ₹', FORMAT(NEW.amount, 2), 
                  ' is pending your approval from ', accountant_name),
           'expense_pending',
           'expense',
           NEW.id
    FROM users u
    JOIN users accountant ON accountant.id = NEW.accountant_id
    WHERE u.role = 'Admin' 
    AND u.status = 'active'
    AND u.organization_id = accountant.organization_id;
END//

-- ==========================================
-- 9. TRIGGER: Notification on expense status change
-- ==========================================
CREATE TRIGGER expenses_status_notifications
AFTER UPDATE ON expenses
FOR EACH ROW
BEGIN
    -- Only create notification if status changed
    IF OLD.status != NEW.status AND NEW.status IN ('Approved', 'Rejected') THEN
        INSERT INTO notifications (user_id, title, message, type, reference_type, reference_id)
        VALUES (
            NEW.accountant_id,
            CONCAT('Expense ', CASE WHEN NEW.status = 'Approved' THEN 'Approved' ELSE 'Rejected' END),
            CONCAT('Your expense ', NEW.expense_code, ' for ₹', FORMAT(NEW.amount, 2), 
                   ' has been ', LOWER(NEW.status)),
            CASE WHEN NEW.status = 'Approved' THEN 'expense_approved' ELSE 'expense_rejected' END,
            'expense',
            NEW.id
        );
    END IF;
END//

-- ==========================================
-- 10. TRIGGER: Auto-set vendor approval date
-- ==========================================
CREATE TRIGGER vendors_auto_approval_date
BEFORE UPDATE ON vendors
FOR EACH ROW
BEGIN
    -- Set approval date when status changes to approved
    IF OLD.status != 'approved' AND NEW.status = 'approved' THEN
        SET NEW.approved_at = NOW();
    END IF;
    
    -- Clear approval date if status changes from approved
    IF OLD.status = 'approved' AND NEW.status != 'approved' THEN
        SET NEW.approved_at = NULL;
    END IF;
END//

DELIMITER ;

-- ==========================================
-- Create additional indexes for trigger performance
-- ==========================================
CREATE INDEX idx_expenses_branch_team ON expenses(branch_id, team_assigned_id);
CREATE INDEX idx_users_organization_role ON users(organization_id, role, status);
CREATE INDEX idx_branches_team ON branches(team_id);
CREATE INDEX idx_balance_tracking_branch_date ON balance_tracking(branch_id, date);