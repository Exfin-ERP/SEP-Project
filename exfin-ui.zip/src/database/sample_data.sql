-- Sample Data for Sri Venkateswara Enterprises Database
-- This file contains sample data to populate the database for testing

USE sri_venkateswara_finance;

-- ==========================================
-- 1. INSERT ORGANIZATIONS
-- ==========================================
INSERT INTO organizations (name, code, description, address, phone, email, gst_number, pan_number) VALUES
('Pragyana Educational Society', 'PRAGYANA', 'Primary and secondary education provider', 'Hyderabad, Telangana, India', '+91-9876543210', 'info@pragyana.edu.in', '36ABCDE1234F1Z5', 'ABCDE1234F'),
('Sriven Educational Society', 'SRIVEN', 'Higher education and professional colleges', 'Hyderabad, Telangana, India', '+91-9876543211', 'info@sriven.edu.in', '36FGHIJ5678K2L3', 'FGHIJ5678K'),
('Sri Venkateswara Enterprises', 'SRIVEN', 'Central finance management organization', 'Hyderabad, Telangana, India', '+91-9876543212', 'finance@sriven.edu.in', '36MNOPQ9012R3S4', 'MNOPQ9012R');

-- ==========================================
-- 2. INSERT TEAMS
-- ==========================================
INSERT INTO teams (name, organization_id, description) VALUES
('Pragyana Team', 1, 'Team managing school finances and operations'),
('Sriven Team', 2, 'Team managing college finances and operations'),
('Central Admin Team', 3, 'Central administration and oversight team');

-- ==========================================
-- 3. INSERT BRANCHES/CAMPUSES
-- ==========================================
INSERT INTO branches (code, name, type, organization_id, team_id, address, phone, email, principal_name, student_count, monthly_collection) VALUES
-- Schools (Pragyana Team)
('PRAGYANA-MAIN', 'Pragyana Main Campus', 'school', 1, 1, 'Main Road, Hyderabad', '+91-9876540001', 'main@pragyana.edu.in', 'Dr. Rajesh Kumar', 450, 425000.00),
('PRAGYANA-A1', 'Pragyana A1 Branch', 'school', 1, 1, 'A1 Area, Hyderabad', '+91-9876540002', 'a1@pragyana.edu.in', 'Mrs. Priya Sharma', 380, 380000.00),
('PRAGYANA-A2', 'Pragyana A2 Branch', 'school', 1, 1, 'A2 Area, Hyderabad', '+91-9876540003', 'a2@pragyana.edu.in', 'Mr. Suresh Babu', 420, 395000.00),
('PRAGYANA-B1', 'Pragyana B1 Branch', 'school', 1, 1, 'B1 Area, Hyderabad', '+91-9876540004', 'b1@pragyana.edu.in', 'Dr. Lakshmi Devi', 390, 375000.00),
('PRAGYANA-B2', 'Pragyana B2 Branch', 'school', 1, 1, 'B2 Area, Hyderabad', '+91-9876540005', 'b2@pragyana.edu.in', 'Mr. Venkat Rao', 425, 400000.00),

-- Colleges (Sriven Team)
('SRIVEN-MAIN', 'Sriven Main Campus', 'college', 2, 2, 'Main Campus, Hyderabad', '+91-9876540011', 'main@sriven.edu.in', 'Dr. Srinivas Reddy', 1200, 1580000.00),
('SRIVEN-GH1', 'Sriven GH1 Campus', 'college', 2, 2, 'GH1 Area, Hyderabad', '+91-9876540012', 'gh1@sriven.edu.in', 'Prof. Madhavi', 800, 1200000.00),
('SRIVEN-LT', 'Sriven LT SPARK', 'college', 2, 2, 'LT Area, Hyderabad', '+91-9876540013', 'lt@sriven.edu.in', 'Dr. Ramesh Kumar', 650, 950000.00),
('SRIVEN-BH3', 'Sriven BH-3 Campus', 'college', 2, 2, 'BH3 Area, Hyderabad', '+91-9876540014', 'bh3@sriven.edu.in', 'Mrs. Kavitha', 720, 1100000.00),
('SRIVEN-TECH', 'Sriven Tech Campus', 'college', 2, 2, 'Tech Park, Hyderabad', '+91-9876540015', 'tech@sriven.edu.in', 'Dr. Prasad', 950, 1450000.00),
('SRIVEN-MED', 'Sriven Medical Campus', 'college', 2, 2, 'Medical District, Hyderabad', '+91-9876540016', 'medical@sriven.edu.in', 'Dr. Anitha', 600, 2800000.00),
('SRIVEN-ENG', 'Sriven Engineering Campus', 'college', 2, 2, 'Engineering Hub, Hyderabad', '+91-9876540017', 'engineering@sriven.edu.in', 'Prof. Kumar', 1100, 1800000.00),
('SRIVEN-MBA', 'Sriven MBA Campus', 'college', 2, 2, 'Business District, Hyderabad', '+91-9876540018', 'mba@sriven.edu.in', 'Dr. Nandini', 450, 1200000.00),
('SRIVEN-LAW', 'Sriven Law Campus', 'college', 2, 2, 'Legal Complex, Hyderabad', '+91-9876540019', 'law@sriven.edu.in', 'Justice Sharma', 300, 900000.00),
('SRIVEN-PHARMA', 'Sriven Pharmacy Campus', 'college', 2, 2, 'Pharma City, Hyderabad', '+91-9876540020', 'pharma@sriven.edu.in', 'Dr. Ravi', 280, 750000.00),
('SRIVEN-ARTS', 'Sriven Arts Campus', 'college', 2, 2, 'Arts Quarter, Hyderabad', '+91-9876540021', 'arts@sriven.edu.in', 'Prof. Sita', 520, 650000.00),
('SRIVEN-SCIENCE', 'Sriven Science Campus', 'college', 2, 2, 'Science Park, Hyderabad', '+91-9876540022', 'science@sriven.edu.in', 'Dr. Mohan', 480, 720000.00);

-- ==========================================
-- 4. INSERT USERS
-- ==========================================
INSERT INTO users (email, phone, name, role, organization_id, team_id, branch_id, status) VALUES
-- Admin Users
('admin@sriviswa.edu.in', '+91-9876543210', 'PSN Sir', 'Admin', 3, 3, NULL, 'active'),
('sridhar@sriviswa.edu.in', '+91-9876543211', 'Sridhar Sir', 'Admin', 3, 3, NULL, 'active'),

-- Management Users
('management1@pragyana.edu.in', '+91-9876543220', 'Dr. Management Lead', 'Management', 1, 1, NULL, 'active'),
('management2@sriven.edu.in', '+91-9876543221', 'Prof. Finance Head', 'Management', 2, 2, NULL, 'active'),

-- Accountant Users for Schools (Pragyana Team)
('accountant1@pragyana.edu.in', '+91-9876543230', 'Rajesh Kumar', 'Accountant', 1, 1, 1, 'active'),
('accountant2@pragyana.edu.in', '+91-9876543231', 'Priya Sharma', 'Accountant', 1, 1, 2, 'active'),
('accountant3@pragyana.edu.in', '+91-9876543232', 'Suresh Babu', 'Accountant', 1, 1, 3, 'active'),

-- Accountant Users for Colleges (Sriven Team)
('accountant4@sriven.edu.in', '+91-9876543240', 'Lakshmi Devi', 'Accountant', 2, 2, 6, 'active'),
('accountant5@sriven.edu.in', '+91-9876543241', 'Venkat Rao', 'Accountant', 2, 2, 7, 'active'),
('accountant6@sriven.edu.in', '+91-9876543242', 'Madhavi Reddy', 'Accountant', 2, 2, 8, 'active'),
('accountant7@sriven.edu.in', '+91-9876543243', 'Ramesh Kumar', 'Accountant', 2, 2, 9, 'active'),
('accountant8@sriven.edu.in', '+91-9876543244', 'Kavitha Singh', 'Accountant', 2, 2, 10, 'active'),

-- Viewer Users
('viewer1@sriviswa.edu.in', '+91-9876543250', 'Finance Viewer 1', 'Viewer', 3, 3, NULL, 'active'),
('viewer2@sriviswa.edu.in', '+91-9876543251', 'Finance Viewer 2', 'Viewer', 3, 3, NULL, 'active');

-- ==========================================
-- 5. INSERT EXPENSE CATEGORIES
-- ==========================================
INSERT INTO expense_categories (name, description) VALUES
('MAINTENANCE', 'Building and infrastructure maintenance'),
('MESS EXPENSES', 'Food and catering related expenses'),
('SALARY PAYABLE', 'Employee salary and compensation'),
('RENTALS', 'Property and equipment rental costs'),
('SERVICE VENDOR', 'External service provider payments'),
('STUDENT FEE REFUND', 'Student fee refunds and adjustments'),
('TRAVELLING EXPENSES', 'Travel and transportation costs'),
('OTHER EXPENSES', 'Miscellaneous operational expenses'),
('FIXED ASSET', 'Asset purchases and investments'),
('INTEREST ON LOAN', 'Loan interest payments'),
('STATIONARY', 'Office supplies and stationery'),
('WATER EXPENSES', 'Water utility and maintenance'),
('ELECTRICITY EXPENSES', 'Electrical utility and maintenance'),
('LOANS', 'Loan principal payments'),
('RENOVATION', 'Building renovation and upgrades'),
('MISCELLANEOUS', 'Other uncategorized expenses');

-- ==========================================
-- 6. INSERT VENDORS
-- ==========================================
INSERT INTO vendors (vendor_code, name, type, contact_person, email, phone, address, gst_number, pan_number, bank_account_number, bank_ifsc_code, bank_name, bank_account_holder, services, status) VALUES
('VENDOR-001', 'Telangana State Electricity Board', 'electricity', 'Rajesh Kumar', 'rajesh@tseb.gov.in', '+91-9876543210', 'Vidyut Bhavan, Hyderabad, Telangana', '36ABCDE1234F1Z5', 'ABCDE1234F', '123456789012', 'SBIN0001234', 'State Bank of India', 'TSEB Collections', 'Electricity supply and maintenance for educational institutions', 'approved'),

('VENDOR-002', 'Sri Lakshmi Properties', 'rental_owners', 'Venkata Rao', 'venkat@srilakshmi.com', '+91-9876543211', 'Banjara Hills, Hyderabad, Telangana', '36FGHIJ5678K2L3', 'FGHIJ5678K', '987654321098', 'HDFC0001234', 'HDFC Bank', 'Sri Lakshmi Properties', 'Commercial property rental for educational institutions', 'approved'),

('VENDOR-003', 'Annapurna Catering Services', 'mess', 'Sita Devi', 'sita@annapurna.com', '+91-9876543212', 'Kukatpally, Hyderabad, Telangana', '36MNOPQ9012R3S4', 'MNOPQ9012R', '456789123456', 'ICIC0001234', 'ICICI Bank', 'Annapurna Catering Services', 'Food catering and mess services for hostels and institutions', 'approved'),

('VENDOR-004', 'Hyderabad Water Supply', 'supplies', 'Ravi Kumar', 'ravi@hwssb.gov.in', '+91-9876543213', 'Water Board, Hyderabad', '36PQRST3456U7V8', 'PQRST3456U', '789123456789', 'SBIN0005678', 'State Bank of India', 'HWSSB Collections', 'Water supply and maintenance', 'approved'),

('VENDOR-005', 'Modern Office Supplies', 'supplies', 'Prema Kumari', 'prema@modernoffice.com', '+91-9876543214', 'Commercial Street, Hyderabad', '36UVWXY7890Z1A2', 'UVWXY7890Z', '321654987123', 'HDFC0005678', 'HDFC Bank', 'Modern Office Supplies', 'Office stationery and supplies', 'pending');

-- ==========================================
-- 7. INSERT SAMPLE EXPENSES
-- ==========================================
INSERT INTO expenses (expense_code, amount, category_id, description, nature_of_work, date, notes, branch_id, team_assigned_id, payment_mode, payment_status, bill_status, authorized_by, accountant_id, status, vendor_id) VALUES
('EXP-2024-001', 45000.00, 2, 'Mess van diesel and groceries', 'Monthly mess expenses including diesel for transportation and grocery supplies', '2024-12-15', 'Monthly mess expenses', 6, 2, 'CASH', 'Paid', TRUE, 'PSN SIR', 7, 'Pending', 3),

('EXP-2024-002', 15000.00, 13, 'Monthly electricity bill', 'Electricity bill payment for December 2024', '2024-12-14', NULL, 2, 1, 'ONLINE', 'Unpaid', TRUE, 'MANAGEMENT', 5, 'Approved', 1),

('EXP-2024-003', 8500.00, 1, 'Building maintenance work', 'Roof repair and painting work for main building', '2024-12-13', 'Roof repair and painting', 10, 2, 'CHEQUE', 'Advance', FALSE, 'DIRECTOR', 11, 'Pending', NULL),

('EXP-2024-004', 25000.00, 3, 'Teacher salary advance', 'Advance salary payment for teaching staff', '2024-12-12', 'Emergency advance for festival season', 1, 1, 'ONLINE', 'Paid', FALSE, 'PSN SIR', 4, 'Approved', NULL),

('EXP-2024-005', 12500.00, 11, 'Office supplies purchase', 'Stationery and office supplies for administrative work', '2024-12-11', 'Quarterly stationery purchase', 7, 2, 'CASH', 'Unpaid', TRUE, 'MANAGEMENT', 8, 'Pending', 5);

-- ==========================================
-- 8. INSERT BALANCE TRACKING DATA
-- ==========================================
INSERT INTO balance_tracking (date, branch_id, team_id, opening_balance, closing_balance, total_credits, total_debits, transaction_count, created_by) VALUES
('2024-12-01', 1, 1, 500000.00, 485000.00, 0.00, 15000.00, 3, 1),
('2024-12-01', 6, 2, 800000.00, 755000.00, 0.00, 45000.00, 5, 1),
('2024-12-02', 1, 1, 485000.00, 460000.00, 0.00, 25000.00, 2, 1),
('2024-12-02', 6, 2, 755000.00, 742500.00, 0.00, 12500.00, 1, 1);

-- ==========================================
-- 9. INSERT SYSTEM SETTINGS
-- ==========================================
INSERT INTO system_settings (setting_key, setting_value, setting_type, description) VALUES
('company_name', 'Sri Venkateswara Enterprises', 'string', 'Company name displayed in the system'),
('default_currency', 'INR', 'string', 'Default currency for the system'),
('financial_year_start', '04-01', 'string', 'Financial year start date (MM-DD)'),
('max_file_upload_size', '10485760', 'number', 'Maximum file upload size in bytes (10MB)'),
('email_notifications_enabled', 'true', 'boolean', 'Enable email notifications'),
('auto_approval_limit', '5000', 'number', 'Auto approval limit for expenses'),
('backup_enabled', 'true', 'boolean', 'Enable automatic database backups'),
('session_timeout', '1800', 'number', 'Session timeout in seconds (30 minutes)');

-- ==========================================
-- 10. INSERT SAMPLE NOTIFICATIONS
-- ==========================================
INSERT INTO notifications (user_id, title, message, type, reference_type, reference_id) VALUES
(1, 'New Expense Pending Approval', 'Expense EXP-2024-001 worth ₹45,000 is pending your approval from Rajesh Kumar', 'expense_pending', 'expense', 1),
(1, 'New Expense Pending Approval', 'Expense EXP-2024-003 worth ₹8,500 is pending your approval from Madhavi Reddy', 'expense_pending', 'expense', 3),
(1, 'New Expense Pending Approval', 'Expense EXP-2024-005 worth ₹12,500 is pending your approval from Kavitha Singh', 'expense_pending', 'expense', 5),
(5, 'Expense Approved', 'Your expense EXP-2024-002 for ₹15,000 has been approved', 'expense_approved', 'expense', 2),
(4, 'Expense Approved', 'Your expense EXP-2024-004 for ₹25,000 has been approved', 'expense_approved', 'expense', 4);

-- Update team leads
UPDATE teams SET team_lead_id = 4 WHERE id = 1; -- Pragyana Team lead
UPDATE teams SET team_lead_id = 7 WHERE id = 2; -- Sriven Team lead