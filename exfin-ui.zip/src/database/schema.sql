-- Sri Venkateswara Enterprises Database Schema
-- Created for comprehensive finance management system

-- Create database
CREATE DATABASE IF NOT EXISTS sri_venkateswara_finance;
USE sriviswa_finance;

-- ==========================================
-- 1. ORGANIZATIONS TABLE
-- ==========================================
CREATE TABLE organizations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    code VARCHAR(20) NOT NULL UNIQUE,
    description TEXT,
    address TEXT,
    phone VARCHAR(15),
    email VARCHAR(100),
    gst_number VARCHAR(20),
    pan_number VARCHAR(15),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==========================================
-- 2. TEAMS TABLE
-- ==========================================
CREATE TABLE teams (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    organization_id INT,
    description TEXT,
    team_lead_id INT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id)
);

-- ==========================================
-- 3. BRANCHES/CAMPUSES TABLE
-- ==========================================
CREATE TABLE branches (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    type ENUM('school', 'college') NOT NULL,
    organization_id INT,
    team_id INT,
    address TEXT,
    phone VARCHAR(15),
    email VARCHAR(100),
    principal_name VARCHAR(100),
    student_count INT DEFAULT 0,
    monthly_collection DECIMAL(15,2) DEFAULT 0.00,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id),
    FOREIGN KEY (team_id) REFERENCES teams(id)
);

-- ==========================================
-- 4. USERS TABLE
-- ==========================================
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15) UNIQUE,
    name VARCHAR(100) NOT NULL,
    role ENUM('Admin', 'Management', 'Accountant', 'Viewer') NOT NULL,
    organization_id INT,
    team_id INT,
    branch_id INT,
    profile_image VARCHAR(255),
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    otp_code VARCHAR(6),
    otp_expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (organization_id) REFERENCES organizations(id),
    FOREIGN KEY (team_id) REFERENCES teams(id),
    FOREIGN KEY (branch_id) REFERENCES branches(id)
);

-- ==========================================
-- 5. EXPENSE CATEGORIES TABLE
-- ==========================================
CREATE TABLE expense_categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 6. VENDORS TABLE
-- ==========================================
CREATE TABLE vendors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    vendor_code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    type ENUM('vendors', 'rental_owners', 'electricity', 'salaries', 'mess', 'transport', 'supplies', 'maintenance') NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(15),
    address TEXT,
    gst_number VARCHAR(20),
    pan_number VARCHAR(15),
    bank_account_number VARCHAR(30),
    bank_ifsc_code VARCHAR(15),
    bank_name VARCHAR(100),
    bank_account_holder VARCHAR(100),
    services TEXT,
    documents JSON, -- Store document file paths
    status ENUM('pending', 'approved', 'rejected', 'suspended') DEFAULT 'pending',
    approved_by INT,
    approved_at TIMESTAMP NULL,
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- ==========================================
-- 7. EXPENSES/TRANSACTIONS TABLE
-- ==========================================
CREATE TABLE expenses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    expense_code VARCHAR(30) UNIQUE NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    category_id INT,
    description TEXT NOT NULL,
    nature_of_work TEXT NOT NULL,
    date DATE NOT NULL,
    notes TEXT,
    
    -- Branch and Team Assignment
    branch_id INT NOT NULL,
    team_assigned_id INT,
    
    -- Payment Details
    payment_mode ENUM('CASH', 'CHEQUE', 'ONLINE', 'SWIPE', 'UPI', 'ADVANCE', 'OTHER MODE') DEFAULT 'CASH',
    payment_status ENUM('Paid', 'Unpaid', 'Advance') DEFAULT 'Unpaid',
    
    -- Bill Information
    bill_status BOOLEAN DEFAULT FALSE,
    bill_number VARCHAR(50),
    bill_date DATE,
    
    -- Authorization
    authorized_by VARCHAR(100),
    
    -- Accountant Information
    accountant_id INT NOT NULL,
    
    -- Approval Workflow
    status ENUM('Pending', 'Approved', 'Rejected', 'Cancelled') DEFAULT 'Pending',
    approved_by INT,
    approved_at TIMESTAMP NULL,
    rejection_reason TEXT,
    
    -- Vendor Information
    vendor_id INT,
    
    -- Attachments
    attachments JSON, -- Store file paths
    
    -- Audit Trail
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (category_id) REFERENCES expense_categories(id),
    FOREIGN KEY (branch_id) REFERENCES branches(id),
    FOREIGN KEY (team_assigned_id) REFERENCES teams(id),
    FOREIGN KEY (accountant_id) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id),
    FOREIGN KEY (vendor_id) REFERENCES vendors(id)
);

-- ==========================================
-- 8. BALANCE TRACKING TABLE
-- ==========================================
CREATE TABLE balance_tracking (
    id INT PRIMARY KEY AUTO_INCREMENT,
    date DATE NOT NULL,
    branch_id INT,
    team_id INT,
    opening_balance DECIMAL(15,2) DEFAULT 0.00,
    closing_balance DECIMAL(15,2) DEFAULT 0.00,
    total_credits DECIMAL(15,2) DEFAULT 0.00,
    total_debits DECIMAL(15,2) DEFAULT 0.00,
    transaction_count INT DEFAULT 0,
    notes TEXT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(id),
    FOREIGN KEY (team_id) REFERENCES teams(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    UNIQUE KEY unique_date_branch_team (date, branch_id, team_id)
);

-- ==========================================
-- 9. AUDIT LOGS TABLE
-- ==========================================
CREATE TABLE audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50) NOT NULL,
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ==========================================
-- 10. FILE ATTACHMENTS TABLE
-- ==========================================
CREATE TABLE file_attachments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    file_name VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    entity_type ENUM('expense', 'vendor', 'user') NOT NULL,
    entity_id INT NOT NULL,
    uploaded_by INT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uploaded_by) REFERENCES users(id)
);

-- ==========================================
-- 11. NOTIFICATIONS TABLE
-- ==========================================
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('expense_pending', 'expense_approved', 'expense_rejected', 'vendor_pending', 'system') NOT NULL,
    reference_type ENUM('expense', 'vendor', 'system'),
    reference_id INT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ==========================================
-- 12. SYSTEM SETTINGS TABLE
-- ==========================================
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    setting_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
    description TEXT,
    updated_by INT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(id)
);

-- ==========================================
-- CREATE INDEXES FOR BETTER PERFORMANCE
-- ==========================================
CREATE INDEX idx_expenses_date ON expenses(date);
CREATE INDEX idx_expenses_status ON expenses(status);
CREATE INDEX idx_expenses_accountant ON expenses(accountant_id);
CREATE INDEX idx_expenses_branch ON expenses(branch_id);
CREATE INDEX idx_expenses_team ON expenses(team_assigned_id);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_vendors_status ON vendors(status);
CREATE INDEX idx_vendors_type ON vendors(type);
CREATE INDEX idx_balance_tracking_date ON balance_tracking(date);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);
CREATE INDEX idx_notifications_user_read ON notifications(user_id, is_read);