-- =====================================================================
-- Cash Handover System Database Schema
-- Complete transparency and approval workflow for cash transfers
-- =====================================================================

-- Table: Accountant Cash Balances
-- Tracks current cash balance for each accountant
CREATE TABLE accountant_balances (
    id SERIAL PRIMARY KEY,
    accountant_id INT NOT NULL,
    accountant_name VARCHAR(100) NOT NULL,
    branch_name VARCHAR(100),
    cash_in_hand DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    pending_outgoing DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    pending_incoming DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    CONSTRAINT check_positive_balances CHECK (
        cash_in_hand >= 0 AND 
        pending_outgoing >= 0 AND 
        pending_incoming >= 0
    ),
    
    INDEX idx_accountant_name (accountant_name),
    INDEX idx_last_updated (last_updated)
);

-- Table: Cash Transfers
-- Main table for all cash transfer transactions
CREATE TABLE cash_transfers (
    id SERIAL PRIMARY KEY,
    transfer_ref VARCHAR(50) UNIQUE NOT NULL,
    from_accountant_id INT NOT NULL,
    from_accountant_name VARCHAR(100) NOT NULL,
    to_accountant_id INT NOT NULL,
    to_accountant_name VARCHAR(100) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    reason TEXT NOT NULL,
    notes TEXT,
    status ENUM('pending', 'approved', 'rejected', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
    initiated_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    responded_date TIMESTAMP NULL,
    completed_date TIMESTAMP NULL,
    rejection_reason TEXT NULL,
    initiated_by VARCHAR(100) NOT NULL,
    responded_by VARCHAR(100) NULL,
    
    -- Financial tracking
    sender_balance_before DECIMAL(15,2),
    sender_balance_after DECIMAL(15,2),
    receiver_balance_before DECIMAL(15,2),
    receiver_balance_after DECIMAL(15,2),
    
    -- Audit fields
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    CONSTRAINT check_positive_amount CHECK (amount > 0),
    CONSTRAINT check_different_accountants CHECK (from_accountant_id != to_accountant_id),
    
    INDEX idx_transfer_ref (transfer_ref),
    INDEX idx_from_accountant (from_accountant_id, from_accountant_name),
    INDEX idx_to_accountant (to_accountant_id, to_accountant_name),
    INDEX idx_status (status),
    INDEX idx_initiated_date (initiated_date),
    INDEX idx_status_date (status, initiated_date)
);

-- Table: Cash Transfer Audit Log
-- Detailed audit trail for all cash transfer activities
CREATE TABLE cash_transfer_audit (
    id SERIAL PRIMARY KEY,
    transfer_id INT NOT NULL,
    transfer_ref VARCHAR(50) NOT NULL,
    action_type ENUM('initiated', 'approved', 'rejected', 'completed', 'cancelled', 'modified') NOT NULL,
    action_description TEXT NOT NULL,
    performed_by VARCHAR(100) NOT NULL,
    performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    old_status ENUM('pending', 'approved', 'rejected', 'completed', 'cancelled') NULL,
    new_status ENUM('pending', 'approved', 'rejected', 'completed', 'cancelled') NULL,
    amount DECIMAL(15,2),
    notes TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    
    FOREIGN KEY (transfer_id) REFERENCES cash_transfers(id) ON DELETE CASCADE,
    
    INDEX idx_transfer_audit (transfer_id),
    INDEX idx_transfer_ref_audit (transfer_ref),
    INDEX idx_performed_at (performed_at),
    INDEX idx_action_type (action_type)
);

-- Table: Accountant Balance History
-- Historical tracking of balance changes
CREATE TABLE accountant_balance_history (
    id SERIAL PRIMARY KEY,
    accountant_id INT NOT NULL,
    accountant_name VARCHAR(100) NOT NULL,
    balance_before DECIMAL(15,2) NOT NULL,
    balance_after DECIMAL(15,2) NOT NULL,
    change_amount DECIMAL(15,2) NOT NULL,
    change_type ENUM('transfer_out', 'transfer_in', 'manual_adjustment', 'system_correction') NOT NULL,
    reference_id INT NULL, -- Can be transfer_id or other reference
    reference_type VARCHAR(50) NULL, -- 'cash_transfer', 'manual_adjustment', etc.
    description TEXT,
    changed_by VARCHAR(100) NOT NULL,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_accountant_history (accountant_id, accountant_name),
    INDEX idx_changed_at (changed_at),
    INDEX idx_change_type (change_type),
    INDEX idx_reference (reference_type, reference_id)
);

-- =====================================================================
-- STORED PROCEDURES FOR CASH HANDOVER OPERATIONS
-- =====================================================================

-- Procedure: Initiate Cash Transfer
DELIMITER $$
CREATE PROCEDURE InitiateCashTransfer(
    IN p_transfer_ref VARCHAR(50),
    IN p_from_accountant_id INT,
    IN p_from_accountant_name VARCHAR(100),
    IN p_to_accountant_id INT,
    IN p_to_accountant_name VARCHAR(100),
    IN p_amount DECIMAL(15,2),
    IN p_reason TEXT,
    IN p_notes TEXT,
    IN p_initiated_by VARCHAR(100),
    OUT p_result_code INT,
    OUT p_result_message VARCHAR(500)
)
BEGIN
    DECLARE v_current_balance DECIMAL(15,2) DEFAULT 0;
    DECLARE v_insufficient_funds CONDITION FOR SQLSTATE '45000';
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        GET DIAGNOSTICS CONDITION 1
            p_result_code = MYSQL_ERRNO, p_result_message = MESSAGE_TEXT;
    END;
    
    START TRANSACTION;
    
    -- Check sender's current balance
    SELECT cash_in_hand INTO v_current_balance 
    FROM accountant_balances 
    WHERE accountant_id = p_from_accountant_id
    FOR UPDATE;
    
    -- Validate sufficient balance
    IF v_current_balance < p_amount THEN
        SIGNAL v_insufficient_funds SET MESSAGE_TEXT = 'Insufficient cash balance for transfer';
    END IF;
    
    -- Create transfer record
    INSERT INTO cash_transfers (
        transfer_ref, from_accountant_id, from_accountant_name,
        to_accountant_id, to_accountant_name, amount, reason, notes,
        status, initiated_by, sender_balance_before
    ) VALUES (
        p_transfer_ref, p_from_accountant_id, p_from_accountant_name,
        p_to_accountant_id, p_to_accountant_name, p_amount, p_reason, p_notes,
        'pending', p_initiated_by, v_current_balance
    );
    
    -- Update sender's balance (deduct amount and add to pending outgoing)
    UPDATE accountant_balances 
    SET 
        cash_in_hand = cash_in_hand - p_amount,
        pending_outgoing = pending_outgoing + p_amount,
        last_updated = CURRENT_TIMESTAMP
    WHERE accountant_id = p_from_accountant_id;
    
    -- Update receiver's pending incoming
    UPDATE accountant_balances 
    SET 
        pending_incoming = pending_incoming + p_amount,
        last_updated = CURRENT_TIMESTAMP
    WHERE accountant_id = p_to_accountant_id;
    
    -- Create audit log
    INSERT INTO cash_transfer_audit (
        transfer_id, transfer_ref, action_type, action_description,
        performed_by, new_status, amount
    ) SELECT 
        id, transfer_ref, 'initiated', 
        CONCAT('Cash transfer initiated for ₹', FORMAT(p_amount, 2), ' to ', p_to_accountant_name),
        p_initiated_by, 'pending', p_amount
    FROM cash_transfers WHERE transfer_ref = p_transfer_ref;
    
    -- Create balance history for sender
    INSERT INTO accountant_balance_history (
        accountant_id, accountant_name, balance_before, balance_after,
        change_amount, change_type, reference_id, reference_type,
        description, changed_by
    ) SELECT 
        p_from_accountant_id, p_from_accountant_name, v_current_balance, 
        v_current_balance - p_amount, -p_amount, 'transfer_out',
        id, 'cash_transfer',
        CONCAT('Transfer initiated to ', p_to_accountant_name, ' - ', p_reason),
        p_initiated_by
    FROM cash_transfers WHERE transfer_ref = p_transfer_ref;
    
    COMMIT;
    
    SET p_result_code = 0;
    SET p_result_message = 'Cash transfer initiated successfully';
    
END$$
DELIMITER ;

-- Procedure: Approve Cash Transfer
DELIMITER $$
CREATE PROCEDURE ApproveCashTransfer(
    IN p_transfer_ref VARCHAR(50),
    IN p_approved_by VARCHAR(100),
    OUT p_result_code INT,
    OUT p_result_message VARCHAR(500)
)
BEGIN
    DECLARE v_transfer_id INT;
    DECLARE v_amount DECIMAL(15,2);
    DECLARE v_to_accountant_id INT;
    DECLARE v_to_accountant_name VARCHAR(100);
    DECLARE v_from_accountant_id INT;
    DECLARE v_from_accountant_name VARCHAR(100);
    DECLARE v_receiver_balance DECIMAL(15,2);
    DECLARE v_transfer_not_found CONDITION FOR SQLSTATE '45000';
    DECLARE v_invalid_status CONDITION FOR SQLSTATE '45000';
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        GET DIAGNOSTICS CONDITION 1
            p_result_code = MYSQL_ERRNO, p_result_message = MESSAGE_TEXT;
    END;
    
    START TRANSACTION;
    
    -- Get transfer details
    SELECT id, amount, to_accountant_id, to_accountant_name, from_accountant_id, from_accountant_name
    INTO v_transfer_id, v_amount, v_to_accountant_id, v_to_accountant_name, v_from_accountant_id, v_from_accountant_name
    FROM cash_transfers 
    WHERE transfer_ref = p_transfer_ref AND status = 'pending'
    FOR UPDATE;
    
    IF v_transfer_id IS NULL THEN
        SIGNAL v_transfer_not_found SET MESSAGE_TEXT = 'Transfer not found or not in pending status';
    END IF;
    
    -- Get receiver's current balance
    SELECT cash_in_hand INTO v_receiver_balance
    FROM accountant_balances 
    WHERE accountant_id = v_to_accountant_id
    FOR UPDATE;
    
    -- Update transfer status
    UPDATE cash_transfers 
    SET 
        status = 'completed',
        responded_date = CURRENT_TIMESTAMP,
        completed_date = CURRENT_TIMESTAMP,
        responded_by = p_approved_by,
        receiver_balance_before = v_receiver_balance,
        receiver_balance_after = v_receiver_balance + v_amount
    WHERE id = v_transfer_id;
    
    -- Update receiver's balance
    UPDATE accountant_balances 
    SET 
        cash_in_hand = cash_in_hand + v_amount,
        pending_incoming = pending_incoming - v_amount,
        last_updated = CURRENT_TIMESTAMP
    WHERE accountant_id = v_to_accountant_id;
    
    -- Update sender's pending outgoing
    UPDATE accountant_balances 
    SET 
        pending_outgoing = pending_outgoing - v_amount,
        last_updated = CURRENT_TIMESTAMP
    WHERE accountant_id = v_from_accountant_id;
    
    -- Create audit log
    INSERT INTO cash_transfer_audit (
        transfer_id, transfer_ref, action_type, action_description,
        performed_by, old_status, new_status, amount
    ) VALUES (
        v_transfer_id, p_transfer_ref, 'approved',
        CONCAT('Cash transfer approved and completed for ₹', FORMAT(v_amount, 2)),
        p_approved_by, 'pending', 'completed', v_amount
    );
    
    -- Create balance history for receiver
    INSERT INTO accountant_balance_history (
        accountant_id, accountant_name, balance_before, balance_after,
        change_amount, change_type, reference_id, reference_type,
        description, changed_by
    ) VALUES (
        v_to_accountant_id, v_to_accountant_name, v_receiver_balance,
        v_receiver_balance + v_amount, v_amount, 'transfer_in',
        v_transfer_id, 'cash_transfer',
        CONCAT('Transfer received from ', v_from_accountant_name),
        p_approved_by
    );
    
    COMMIT;
    
    SET p_result_code = 0;
    SET p_result_message = 'Cash transfer approved and completed successfully';
    
END$$
DELIMITER ;

-- Procedure: Reject Cash Transfer
DELIMITER $$
CREATE PROCEDURE RejectCashTransfer(
    IN p_transfer_ref VARCHAR(50),
    IN p_rejected_by VARCHAR(100),
    IN p_rejection_reason TEXT,
    OUT p_result_code INT,
    OUT p_result_message VARCHAR(500)
)
BEGIN
    DECLARE v_transfer_id INT;
    DECLARE v_amount DECIMAL(15,2);
    DECLARE v_from_accountant_id INT;
    DECLARE v_from_accountant_name VARCHAR(100);
    DECLARE v_to_accountant_id INT;
    DECLARE v_sender_balance DECIMAL(15,2);
    DECLARE v_transfer_not_found CONDITION FOR SQLSTATE '45000';
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        GET DIAGNOSTICS CONDITION 1
            p_result_code = MYSQL_ERRNO, p_result_message = MESSAGE_TEXT;
    END;
    
    START TRANSACTION;
    
    -- Get transfer details
    SELECT id, amount, from_accountant_id, from_accountant_name, to_accountant_id
    INTO v_transfer_id, v_amount, v_from_accountant_id, v_from_accountant_name, v_to_accountant_id
    FROM cash_transfers 
    WHERE transfer_ref = p_transfer_ref AND status = 'pending'
    FOR UPDATE;
    
    IF v_transfer_id IS NULL THEN
        SIGNAL v_transfer_not_found SET MESSAGE_TEXT = 'Transfer not found or not in pending status';
    END IF;
    
    -- Get sender's current balance
    SELECT cash_in_hand INTO v_sender_balance
    FROM accountant_balances 
    WHERE accountant_id = v_from_accountant_id
    FOR UPDATE;
    
    -- Update transfer status
    UPDATE cash_transfers 
    SET 
        status = 'rejected',
        responded_date = CURRENT_TIMESTAMP,
        responded_by = p_rejected_by,
        rejection_reason = p_rejection_reason,
        sender_balance_after = v_sender_balance + v_amount
    WHERE id = v_transfer_id;
    
    -- Restore sender's balance
    UPDATE accountant_balances 
    SET 
        cash_in_hand = cash_in_hand + v_amount,
        pending_outgoing = pending_outgoing - v_amount,
        last_updated = CURRENT_TIMESTAMP
    WHERE accountant_id = v_from_accountant_id;
    
    -- Update receiver's pending incoming
    UPDATE accountant_balances 
    SET 
        pending_incoming = pending_incoming - v_amount,
        last_updated = CURRENT_TIMESTAMP
    WHERE accountant_id = v_to_accountant_id;
    
    -- Create audit log
    INSERT INTO cash_transfer_audit (
        transfer_id, transfer_ref, action_type, action_description,
        performed_by, old_status, new_status, amount, notes
    ) VALUES (
        v_transfer_id, p_transfer_ref, 'rejected',
        CONCAT('Cash transfer rejected for ₹', FORMAT(v_amount, 2), '. Sender balance restored.'),
        p_rejected_by, 'pending', 'rejected', v_amount, p_rejection_reason
    );
    
    -- Create balance history for sender (restoration)
    INSERT INTO accountant_balance_history (
        accountant_id, accountant_name, balance_before, balance_after,
        change_amount, change_type, reference_id, reference_type,
        description, changed_by
    ) VALUES (
        v_from_accountant_id, v_from_accountant_name, v_sender_balance,
        v_sender_balance + v_amount, v_amount, 'system_correction',
        v_transfer_id, 'cash_transfer',
        CONCAT('Balance restored due to transfer rejection - ', p_rejection_reason),
        p_rejected_by
    );
    
    COMMIT;
    
    SET p_result_code = 0;
    SET p_result_message = 'Cash transfer rejected successfully and sender balance restored';
    
END$$
DELIMITER ;

-- =====================================================================
-- VIEWS FOR REPORTING AND ANALYTICS
-- =====================================================================

-- View: Current Accountant Status
CREATE VIEW v_accountant_cash_status AS
SELECT 
    ab.accountant_id,
    ab.accountant_name,
    ab.branch_name,
    ab.cash_in_hand,
    ab.pending_outgoing,
    ab.pending_incoming,
    (ab.cash_in_hand - ab.pending_outgoing + ab.pending_incoming) AS effective_balance,
    ab.last_updated,
    -- Count of pending outgoing transfers
    (SELECT COUNT(*) FROM cash_transfers 
     WHERE from_accountant_id = ab.accountant_id AND status = 'pending') AS pending_outgoing_count,
    -- Count of pending incoming transfers
    (SELECT COUNT(*) FROM cash_transfers 
     WHERE to_accountant_id = ab.accountant_id AND status = 'pending') AS pending_incoming_count
FROM accountant_balances ab;

-- View: Transfer Activity Summary
CREATE VIEW v_transfer_activity_summary AS
SELECT 
    ct.transfer_ref,
    ct.from_accountant_name,
    ct.to_accountant_name,
    ct.amount,
    ct.reason,
    ct.status,
    ct.initiated_date,
    ct.responded_date,
    ct.completed_date,
    CASE 
        WHEN ct.status = 'completed' AND ct.responded_date IS NOT NULL 
        THEN TIMESTAMPDIFF(MINUTE, ct.initiated_date, ct.responded_date)
        ELSE NULL 
    END AS response_time_minutes,
    ct.initiated_by,
    ct.responded_by
FROM cash_transfers ct
ORDER BY ct.initiated_date DESC;

-- View: Daily Transfer Summary
CREATE VIEW v_daily_transfer_summary AS
SELECT 
    DATE(initiated_date) AS transfer_date,
    COUNT(*) AS total_transfers,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed_transfers,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending_transfers,
    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) AS rejected_transfers,
    SUM(amount) AS total_amount,
    SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) AS completed_amount,
    AVG(CASE WHEN status = 'completed' AND responded_date IS NOT NULL 
        THEN TIMESTAMPDIFF(MINUTE, initiated_date, responded_date) 
        ELSE NULL END) AS avg_response_time_minutes
FROM cash_transfers
GROUP BY DATE(initiated_date)
ORDER BY transfer_date DESC;

-- =====================================================================
-- TRIGGERS FOR AUTOMATIC UPDATES
-- =====================================================================

-- Trigger: Update accountant balance timestamp on any change
DELIMITER $$
CREATE TRIGGER tr_accountant_balance_update
    BEFORE UPDATE ON accountant_balances
    FOR EACH ROW
BEGIN
    SET NEW.updated_at = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- Trigger: Update transfer timestamp on status change
DELIMITER $$
CREATE TRIGGER tr_cash_transfer_update
    BEFORE UPDATE ON cash_transfers
    FOR EACH ROW
BEGIN
    SET NEW.updated_at = CURRENT_TIMESTAMP;
    
    -- Auto-set completion date when status changes to completed
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        SET NEW.completed_date = CURRENT_TIMESTAMP;
    END IF;
END$$
DELIMITER ;

-- =====================================================================
-- SAMPLE DATA FOR TESTING
-- =====================================================================

-- Insert sample accountant balances
INSERT INTO accountant_balances (accountant_id, accountant_name, branch_name, cash_in_hand) VALUES
(1, 'Manikantha Kumar', 'Main Branch', 25000.00),
(2, 'Prasad Rao', 'BC-1 Branch', 18500.00),
(3, 'Rajesh Babu', 'DC-1 Branch', 22750.00),
(4, 'Priya Sharma', 'Sontyam Branch', 15000.00),
(5, 'Suresh Kumar', 'Central Office', 30000.00);

-- Sample completed transfer
INSERT INTO cash_transfers (
    transfer_ref, from_accountant_id, from_accountant_name,
    to_accountant_id, to_accountant_name, amount, reason,
    status, initiated_by, responded_by, initiated_date, responded_date, completed_date,
    sender_balance_before, sender_balance_after, receiver_balance_before, receiver_balance_after
) VALUES (
    'CT-20241219-001', 3, 'Rajesh Babu', 4, 'Priya Sharma', 5000.00,
    'Emergency maintenance fund for urgent repairs',
    'completed', 'Rajesh Babu', 'Priya Sharma',
    '2024-12-19 14:20:00', '2024-12-19 14:45:00', '2024-12-19 14:45:00',
    27750.00, 22750.00, 10000.00, 15000.00
);

-- Sample audit log
INSERT INTO cash_transfer_audit (
    transfer_id, transfer_ref, action_type, action_description,
    performed_by, new_status, amount, performed_at
) VALUES 
(1, 'CT-20241219-001', 'initiated', 'Cash transfer initiated for ₹5,000.00 to Priya Sharma', 'Rajesh Babu', 'pending', 5000.00, '2024-12-19 14:20:00'),
(1, 'CT-20241219-001', 'approved', 'Cash transfer approved and completed for ₹5,000.00', 'Priya Sharma', 'completed', 5000.00, '2024-12-19 14:45:00');

-- =====================================================================
-- INDEXES FOR PERFORMANCE OPTIMIZATION
-- =====================================================================

-- Additional composite indexes for common queries
CREATE INDEX idx_transfers_from_status_date ON cash_transfers(from_accountant_id, status, initiated_date);
CREATE INDEX idx_transfers_to_status_date ON cash_transfers(to_accountant_id, status, initiated_date);
CREATE INDEX idx_audit_transfer_action ON cash_transfer_audit(transfer_id, action_type, performed_at);
CREATE INDEX idx_balance_history_accountant_date ON accountant_balance_history(accountant_id, changed_at);

-- =====================================================================
-- PERMISSIONS AND SECURITY
-- =====================================================================

-- Grant appropriate permissions (adjust user names as needed)
-- GRANT SELECT, INSERT, UPDATE ON accountant_balances TO 'accountant_user'@'%';
-- GRANT SELECT, INSERT ON cash_transfers TO 'accountant_user'@'%';
-- GRANT UPDATE (status, responded_date, responded_by, rejection_reason) ON cash_transfers TO 'accountant_user'@'%';
-- GRANT SELECT ON cash_transfer_audit TO 'accountant_user'@'%';
-- GRANT SELECT ON v_accountant_cash_status TO 'accountant_user'@'%';
-- GRANT SELECT ON v_transfer_activity_summary TO 'accountant_user'@'%';

-- Grant admin permissions
-- GRANT ALL PRIVILEGES ON cash_transfers TO 'admin_user'@'%';
-- GRANT ALL PRIVILEGES ON accountant_balances TO 'admin_user'@'%';
-- GRANT ALL PRIVILEGES ON cash_transfer_audit TO 'admin_user'@'%';
-- GRANT ALL PRIVILEGES ON accountant_balance_history TO 'admin_user'@'%';