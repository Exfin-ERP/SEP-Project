-- ==========================================
-- ACCOUNTANTS MASTER TABLE & DATA
-- SRIVISWA-2025 Application
-- ==========================================

-- Create accountants table
CREATE TABLE IF NOT EXISTS accountants (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    campus VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('College', 'School')),
    email VARCHAR(100),
    status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(name, campus)
);

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_accountants_type ON accountants(type);
CREATE INDEX IF NOT EXISTS idx_accountants_status ON accountants(status);
CREATE INDEX IF NOT EXISTS idx_accountants_phone ON accountants(phone);

-- ==========================================
-- INSERT COLLEGE ACCOUNTANTS
-- ==========================================

INSERT INTO accountants (name, campus, phone, type) VALUES
    ('SK NAGOOR SIR', 'DC-2', '9059037007', 'College'),
    ('SURESH SIR', 'CHANDRAPALEM', '9676971116', 'College'),
    ('SATYANARAYANA SIR', 'DC-1', '9704201809', 'College'),
    ('M V GANESH SIR', 'REVOLT', '8297632185', 'College'),
    ('SATYAVENI MADAM', 'LT', '9640314659', 'College'),
    ('SRIDEVI MADAM', 'GH-1,2,3,4,5', '8106662336', 'College'),
    ('CHAKRADHAR SIR', 'INDIAN BULLS', '7095355390', 'College'),
    ('SRIRAM SIR', 'PM PALEM', '9493989799', 'College'),
    ('NAGU SIR', 'YENDADA', '8464968380', 'College'),
    ('MANITEJA SIR', 'MAX', '9110382520', 'College'),
    ('RAMAKRISHNA SIR', 'SIVA SIVANI', '7989451125', 'College')
ON CONFLICT (name, campus) 
DO UPDATE SET 
    phone = EXCLUDED.phone,
    type = EXCLUDED.type,
    updated_at = CURRENT_TIMESTAMP;

-- ==========================================
-- INSERT SCHOOL ACCOUNTANTS
-- ==========================================

INSERT INTO accountants (name, campus, phone, type) VALUES
    ('DURGA MADAM', 'DAY CAMPUS', '9573737184', 'School'),
    ('DURGA MADAM', 'THAGARAPUVALASA', '8499035618', 'School'),
    ('SATYAVATHI MADAM', 'BOYAPALEM', '9666762056', 'School'),
    ('ANANTH SIR', 'SONTYAM', '9494918171', 'School')
ON CONFLICT (name, campus) 
DO UPDATE SET 
    phone = EXCLUDED.phone,
    type = EXCLUDED.type,
    updated_at = CURRENT_TIMESTAMP;

-- ==========================================
-- VERIFICATION QUERY
-- ==========================================

-- View all accountants
-- SELECT * FROM accountants ORDER BY type, name;

-- View by type
-- SELECT type, COUNT(*) as count FROM accountants GROUP BY type;
