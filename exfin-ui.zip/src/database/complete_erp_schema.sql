-- ==========================================
-- COMPLETE EDUCATIONAL ERP SYSTEM SCHEMA
-- Sri Venkateswara Enterprises
-- Comprehensive Multi-Module System
-- ==========================================

-- This schema integrates with existing revenue_expenditure_schema.sql
-- Run this after the base schema.sql and revenue_expenditure_schema.sql

-- ==========================================
-- EXAMINATION MODULE
-- ==========================================

-- Examination Types Table
CREATE TABLE IF NOT EXISTS examination_types (
    id SERIAL PRIMARY KEY,
    exam_name VARCHAR(100) NOT NULL,
    exam_type VARCHAR(50) CHECK (exam_type IN ('Unit Test', 'Mid Term', 'End Term', 'Quarterly', 'Half Yearly', 'Annual', 'Board Exam', 'Entrance')),
    organization_id INT REFERENCES organizations(id),
    academic_year VARCHAR(10) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Examination Schedule Table
CREATE TABLE IF NOT EXISTS examination_schedule (
    id SERIAL PRIMARY KEY,
    exam_id INT REFERENCES examination_types(id),
    class_id INT REFERENCES classes(id),
    subject_name VARCHAR(100) NOT NULL,
    subject_code VARCHAR(20),
    exam_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    duration_minutes INT,
    max_marks DECIMAL(5, 2) NOT NULL,
    passing_marks DECIMAL(5, 2) NOT NULL,
    room_number VARCHAR(50),
    invigilator_id INT REFERENCES staff(id),
    organization_id INT REFERENCES organizations(id),
    branch_id INT REFERENCES branches(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Student Marks Entry Table
CREATE TABLE IF NOT EXISTS student_marks (
    id SERIAL PRIMARY KEY,
    exam_schedule_id INT REFERENCES examination_schedule(id),
    student_id VARCHAR(20) REFERENCES students(student_id),
    obtained_marks DECIMAL(5, 2),
    grade VARCHAR(5),
    remarks TEXT,
    is_absent BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) CHECK (status IN ('Pass', 'Fail', 'Absent', 'Pending')) DEFAULT 'Pending',
    entered_by INT REFERENCES users(id),
    verified_by INT REFERENCES users(id),
    entered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE(exam_schedule_id, student_id)
);

-- Grade Configuration Table
CREATE TABLE IF NOT EXISTS grade_configuration (
    id SERIAL PRIMARY KEY,
    organization_id INT REFERENCES organizations(id),
    grade_name VARCHAR(5) NOT NULL,
    min_percentage DECIMAL(5, 2) NOT NULL,
    max_percentage DECIMAL(5, 2) NOT NULL,
    grade_point DECIMAL(3, 2),
    description VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- LIBRARY MODULE
-- ==========================================

-- Library Books Catalog
CREATE TABLE IF NOT EXISTS library_books (
    id SERIAL PRIMARY KEY,
    book_code VARCHAR(50) UNIQUE NOT NULL,
    isbn VARCHAR(20) UNIQUE,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(200) NOT NULL,
    publisher VARCHAR(200),
    edition VARCHAR(50),
    publication_year INT,
    category VARCHAR(100) CHECK (category IN ('Fiction', 'Non-Fiction', 'Reference', 'Textbook', 'Magazine', 'Journal', 'Other')),
    subject VARCHAR(100),
    language VARCHAR(50),
    total_copies INT DEFAULT 1,
    available_copies INT DEFAULT 1,
    price DECIMAL(10, 2),
    location VARCHAR(100),
    rack_number VARCHAR(50),
    organization_id INT REFERENCES organizations(id),
    branch_id INT REFERENCES branches(id),
    status VARCHAR(20) CHECK (status IN ('Available', 'Issued', 'Lost', 'Damaged', 'Under Repair')) DEFAULT 'Available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Library Book Issue/Return Transactions
CREATE TABLE IF NOT EXISTS library_transactions (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(50) UNIQUE NOT NULL,
    book_id INT REFERENCES library_books(id),
    student_id VARCHAR(20) REFERENCES students(student_id),
    staff_id VARCHAR(20) REFERENCES staff(staff_id),
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE,
    status VARCHAR(20) CHECK (status IN ('Issued', 'Returned', 'Overdue', 'Lost')) DEFAULT 'Issued',
    fine_amount DECIMAL(10, 2) DEFAULT 0.00,
    fine_paid BOOLEAN DEFAULT FALSE,
    remarks TEXT,
    issued_by INT REFERENCES users(id),
    returned_to INT REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Library Fine Configuration
CREATE TABLE IF NOT EXISTS library_fine_config (
    id SERIAL PRIMARY KEY,
    organization_id INT REFERENCES organizations(id),
    user_type VARCHAR(20) CHECK (user_type IN ('Student', 'Staff')),
    fine_per_day DECIMAL(10, 2) NOT NULL,
    max_fine_amount DECIMAL(10, 2),
    grace_period_days INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- TRANSPORT MODULE
-- ==========================================

-- Vehicle Master
CREATE TABLE IF NOT EXISTS vehicles (
    id SERIAL PRIMARY KEY,
    vehicle_number VARCHAR(50) UNIQUE NOT NULL,
    vehicle_type VARCHAR(50) CHECK (vehicle_type IN ('Bus', 'Van', 'Car', 'Auto')),
    model VARCHAR(100),
    manufacturer VARCHAR(100),
    seating_capacity INT,
    registration_date DATE,
    insurance_expiry DATE,
    fitness_certificate_expiry DATE,
    pollution_certificate_expiry DATE,
    driver_id INT REFERENCES staff(staff_id),
    organization_id INT REFERENCES organizations(id),
    status VARCHAR(20) CHECK (status IN ('Active', 'Inactive', 'Under Maintenance', 'Retired')) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Transport Routes
CREATE TABLE IF NOT EXISTS transport_routes (
    id SERIAL PRIMARY KEY,
    route_code VARCHAR(20) UNIQUE NOT NULL,
    route_name VARCHAR(100) NOT NULL,
    start_location VARCHAR(200),
    end_location VARCHAR(200),
    total_distance_km DECIMAL(10, 2),
    estimated_time_minutes INT,
    vehicle_id INT REFERENCES vehicles(id),
    organization_id INT REFERENCES organizations(id),
    branch_id INT REFERENCES branches(id),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Route Stops
CREATE TABLE IF NOT EXISTS route_stops (
    id SERIAL PRIMARY KEY,
    route_id INT REFERENCES transport_routes(id),
    stop_name VARCHAR(200) NOT NULL,
    stop_sequence INT NOT NULL,
    arrival_time TIME,
    pickup_point BOOLEAN DEFAULT TRUE,
    drop_point BOOLEAN DEFAULT TRUE,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Student Transport Mapping
CREATE TABLE IF NOT EXISTS student_transport (
    id SERIAL PRIMARY KEY,
    student_id VARCHAR(20) REFERENCES students(student_id),
    route_id INT REFERENCES transport_routes(id),
    pickup_stop_id INT REFERENCES route_stops(id),
    drop_stop_id INT REFERENCES route_stops(id),
    monthly_fee DECIMAL(10, 2),
    start_date DATE NOT NULL,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Vehicle Maintenance Log
CREATE TABLE IF NOT EXISTS vehicle_maintenance (
    id SERIAL PRIMARY KEY,
    vehicle_id INT REFERENCES vehicles(id),
    maintenance_type VARCHAR(100),
    description TEXT,
    cost DECIMAL(10, 2),
    maintenance_date DATE NOT NULL,
    next_maintenance_date DATE,
    vendor_id INT REFERENCES vendors(id),
    performed_by VARCHAR(200),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- HOSTEL & MESS MODULE
-- ==========================================

-- Hostel Buildings
CREATE TABLE IF NOT EXISTS hostel_buildings (
    id SERIAL PRIMARY KEY,
    building_code VARCHAR(20) UNIQUE NOT NULL,
    building_name VARCHAR(100) NOT NULL,
    gender VARCHAR(10) CHECK (gender IN ('Male', 'Female', 'Co-ed')),
    total_floors INT,
    total_rooms INT,
    organization_id INT REFERENCES organizations(id),
    branch_id INT REFERENCES branches(id),
    warden_id INT REFERENCES staff(staff_id),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Hostel Rooms
CREATE TABLE IF NOT EXISTS hostel_rooms (
    id SERIAL PRIMARY KEY,
    building_id INT REFERENCES hostel_buildings(id),
    room_number VARCHAR(20) NOT NULL,
    floor_number INT,
    room_type VARCHAR(50) CHECK (room_type IN ('Single', 'Double', 'Triple', 'Quad', 'Dormitory')),
    bed_capacity INT NOT NULL,
    occupied_beds INT DEFAULT 0,
    monthly_rent DECIMAL(10, 2),
    amenities TEXT,
    status VARCHAR(20) CHECK (status IN ('Available', 'Occupied', 'Under Maintenance', 'Closed')) DEFAULT 'Available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE(building_id, room_number)
);

-- Hostel Allocation
CREATE TABLE IF NOT EXISTS hostel_allocation (
    id SERIAL PRIMARY KEY,
    student_id VARCHAR(20) REFERENCES students(student_id),
    room_id INT REFERENCES hostel_rooms(id),
    bed_number INT,
    allocation_date DATE NOT NULL,
    checkout_date DATE,
    monthly_rent DECIMAL(10, 2),
    security_deposit DECIMAL(10, 2),
    status VARCHAR(20) CHECK (status IN ('Active', 'Checked Out', 'Vacated')) DEFAULT 'Active',
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Mess Configuration
CREATE TABLE IF NOT EXISTS mess_config (
    id SERIAL PRIMARY KEY,
    mess_name VARCHAR(100) NOT NULL,
    mess_type VARCHAR(50) CHECK (mess_type IN ('Vegetarian', 'Non-Vegetarian', 'Both')),
    organization_id INT REFERENCES organizations(id),
    branch_id INT REFERENCES branches(id),
    monthly_fee DECIMAL(10, 2),
    daily_fee DECIMAL(10, 2),
    manager_id INT REFERENCES staff(staff_id),
    capacity INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Student Mess Enrollment
CREATE TABLE IF NOT EXISTS student_mess (
    id SERIAL PRIMARY KEY,
    student_id VARCHAR(20) REFERENCES students(student_id),
    mess_id INT REFERENCES mess_config(id),
    enrollment_date DATE NOT NULL,
    end_date DATE,
    mess_type VARCHAR(50) CHECK (mess_type IN ('Vegetarian', 'Non-Vegetarian')),
    monthly_fee DECIMAL(10, 2),
    status VARCHAR(20) CHECK (status IN ('Active', 'Inactive', 'Suspended')) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Mess Attendance
CREATE TABLE IF NOT EXISTS mess_attendance (
    id SERIAL PRIMARY KEY,
    student_mess_id INT REFERENCES student_mess(id),
    attendance_date DATE NOT NULL,
    breakfast BOOLEAN DEFAULT FALSE,
    lunch BOOLEAN DEFAULT FALSE,
    dinner BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_mess_id, attendance_date)
);

-- ==========================================
-- TIMETABLE MODULE
-- ==========================================

-- Academic Periods
CREATE TABLE IF NOT EXISTS academic_periods (
    id SERIAL PRIMARY KEY,
    period_number INT NOT NULL,
    period_name VARCHAR(50),
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    duration_minutes INT,
    organization_id INT REFERENCES organizations(id),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Class Timetable
CREATE TABLE IF NOT EXISTS class_timetable (
    id SERIAL PRIMARY KEY,
    class_id INT REFERENCES classes(id),
    day_of_week INT CHECK (day_of_week BETWEEN 1 AND 7), -- 1=Monday, 7=Sunday
    period_id INT REFERENCES academic_periods(id),
    subject_name VARCHAR(100) NOT NULL,
    subject_code VARCHAR(20),
    teacher_id INT REFERENCES staff(staff_id),
    room_number VARCHAR(50),
    academic_year VARCHAR(10),
    semester VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Teacher Substitution
CREATE TABLE IF NOT EXISTS teacher_substitution (
    id SERIAL PRIMARY KEY,
    original_timetable_id INT REFERENCES class_timetable(id),
    substitute_teacher_id INT REFERENCES staff(staff_id),
    substitution_date DATE NOT NULL,
    reason TEXT,
    approved_by INT REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- ATTENDANCE MODULE
-- ==========================================

-- Student Attendance
CREATE TABLE IF NOT EXISTS student_attendance (
    id SERIAL PRIMARY KEY,
    student_id VARCHAR(20) REFERENCES students(student_id),
    class_id INT REFERENCES classes(id),
    attendance_date DATE NOT NULL,
    status VARCHAR(20) CHECK (status IN ('Present', 'Absent', 'Late', 'Half Day', 'On Leave')) DEFAULT 'Present',
    marked_by INT REFERENCES users(id),
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, attendance_date)
);

-- Staff Attendance
CREATE TABLE IF NOT EXISTS staff_attendance (
    id SERIAL PRIMARY KEY,
    staff_id VARCHAR(20) REFERENCES staff(staff_id),
    attendance_date DATE NOT NULL,
    check_in_time TIME,
    check_out_time TIME,
    status VARCHAR(20) CHECK (status IN ('Present', 'Absent', 'Late', 'Half Day', 'On Leave', 'Holiday')) DEFAULT 'Present',
    marked_by INT REFERENCES users(id),
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(staff_id, attendance_date)
);

-- Leave Management
CREATE TABLE IF NOT EXISTS leave_applications (
    id SERIAL PRIMARY KEY,
    application_number VARCHAR(50) UNIQUE NOT NULL,
    applicant_type VARCHAR(20) CHECK (applicant_type IN ('Student', 'Staff')),
    student_id VARCHAR(20) REFERENCES students(student_id),
    staff_id VARCHAR(20) REFERENCES staff(staff_id),
    leave_type VARCHAR(50) CHECK (leave_type IN ('Sick Leave', 'Casual Leave', 'Earned Leave', 'Maternity Leave', 'Paternity Leave', 'Unpaid Leave', 'Other')),
    from_date DATE NOT NULL,
    to_date DATE NOT NULL,
    total_days INT,
    reason TEXT NOT NULL,
    status VARCHAR(20) CHECK (status IN ('Pending', 'Approved', 'Rejected', 'Cancelled')) DEFAULT 'Pending',
    approved_by INT REFERENCES users(id),
    approved_at TIMESTAMP,
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==========================================
-- INVENTORY MODULE
-- ==========================================

-- Inventory Items
CREATE TABLE IF NOT EXISTS inventory_items (
    id SERIAL PRIMARY KEY,
    item_code VARCHAR(50) UNIQUE NOT NULL,
    item_name VARCHAR(200) NOT NULL,
    category VARCHAR(100) CHECK (category IN ('Furniture', 'Electronics', 'Stationery', 'Sports Equipment', 'Lab Equipment', 'Other')),
    description TEXT,
    unit_of_measure VARCHAR(50),
    quantity INT DEFAULT 0,
    minimum_stock_level INT DEFAULT 0,
    unit_price DECIMAL(10, 2),
    total_value DECIMAL(12, 2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
    location VARCHAR(200),
    organization_id INT REFERENCES organizations(id),
    branch_id INT REFERENCES branches(id),
    status VARCHAR(20) CHECK (status IN ('In Stock', 'Low Stock', 'Out of Stock', 'Damaged')) DEFAULT 'In Stock',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Inventory Transactions
CREATE TABLE IF NOT EXISTS inventory_transactions (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(50) UNIQUE NOT NULL,
    item_id INT REFERENCES inventory_items(id),
    transaction_type VARCHAR(50) CHECK (transaction_type IN ('Purchase', 'Issue', 'Return', 'Transfer', 'Damage', 'Loss', 'Adjustment')),
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2),
    total_amount DECIMAL(12, 2),
    transaction_date DATE NOT NULL,
    vendor_id INT REFERENCES vendors(id),
    invoice_number VARCHAR(100),
    issued_to VARCHAR(200),
    department VARCHAR(100),
    remarks TEXT,
    performed_by INT REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- DOCUMENT MANAGEMENT MODULE
-- ==========================================

-- Document Types Configuration
CREATE TABLE IF NOT EXISTS document_types (
    id SERIAL PRIMARY KEY,
    document_code VARCHAR(20) UNIQUE NOT NULL,
    document_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) CHECK (category IN ('Certificate', 'ID Card', 'Receipt', 'Report Card', 'Admit Card', 'Other')),
    template_path VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Generated Documents
CREATE TABLE IF NOT EXISTS generated_documents (
    id SERIAL PRIMARY KEY,
    document_number VARCHAR(100) UNIQUE NOT NULL,
    document_type_id INT REFERENCES document_types(id),
    student_id VARCHAR(20) REFERENCES students(student_id),
    staff_id VARCHAR(20) REFERENCES staff(staff_id),
    issue_date DATE NOT NULL,
    expiry_date DATE,
    file_path VARCHAR(500),
    file_size BIGINT,
    status VARCHAR(20) CHECK (status IN ('Active', 'Expired', 'Cancelled', 'Reissued')) DEFAULT 'Active',
    issued_by INT REFERENCES users(id),
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==========================================
-- COMMUNICATION MODULE
-- ==========================================

-- SMS/Email Templates
CREATE TABLE IF NOT EXISTS communication_templates (
    id SERIAL PRIMARY KEY,
    template_code VARCHAR(50) UNIQUE NOT NULL,
    template_name VARCHAR(100) NOT NULL,
    template_type VARCHAR(50) CHECK (template_type IN ('SMS', 'Email', 'Push Notification')),
    subject VARCHAR(200),
    content TEXT NOT NULL,
    variables TEXT, -- JSON array of variable names
    organization_id INT REFERENCES organizations(id),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Communication Log
CREATE TABLE IF NOT EXISTS communication_log (
    id SERIAL PRIMARY KEY,
    template_id INT REFERENCES communication_templates(id),
    communication_type VARCHAR(50) CHECK (communication_type IN ('SMS', 'Email', 'Push Notification')),
    recipient_type VARCHAR(20) CHECK (recipient_type IN ('Student', 'Staff', 'Parent', 'All')),
    student_id VARCHAR(20) REFERENCES students(student_id),
    staff_id VARCHAR(20) REFERENCES staff(staff_id),
    recipient_contact VARCHAR(255) NOT NULL,
    subject VARCHAR(200),
    message TEXT NOT NULL,
    status VARCHAR(20) CHECK (status IN ('Sent', 'Failed', 'Pending')) DEFAULT 'Pending',
    sent_at TIMESTAMP,
    delivered_at TIMESTAMP,
    error_message TEXT,
    sent_by INT REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- AUDIT TRAIL MODULE
-- ==========================================

-- System Audit Log
CREATE TABLE IF NOT EXISTS audit_log (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    action_type VARCHAR(50) CHECK (action_type IN ('CREATE', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT', 'APPROVE', 'REJECT', 'EXPORT', 'IMPORT')),
    table_name VARCHAR(100),
    record_id VARCHAR(100),
    old_values JSONB,
    new_values JSONB,
    ip_address VARCHAR(45),
    user_agent TEXT,
    organization_id INT REFERENCES organizations(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- ADDITIONAL INDEXES FOR PERFORMANCE
-- ==========================================

-- Examination Indexes
CREATE INDEX idx_exam_schedule_date ON examination_schedule(exam_date);
CREATE INDEX idx_exam_schedule_class ON examination_schedule(class_id);
CREATE INDEX idx_student_marks_student ON student_marks(student_id);
CREATE INDEX idx_student_marks_exam ON student_marks(exam_schedule_id);

-- Library Indexes
CREATE INDEX idx_library_books_category ON library_books(category);
CREATE INDEX idx_library_books_status ON library_books(status);
CREATE INDEX idx_library_transactions_student ON library_transactions(student_id);
CREATE INDEX idx_library_transactions_status ON library_transactions(status);

-- Transport Indexes
CREATE INDEX idx_student_transport_student ON student_transport(student_id);
CREATE INDEX idx_student_transport_route ON student_transport(route_id);

-- Hostel Indexes
CREATE INDEX idx_hostel_allocation_student ON hostel_allocation(student_id);
CREATE INDEX idx_hostel_allocation_status ON hostel_allocation(status);
CREATE INDEX idx_student_mess_student ON student_mess(student_id);

-- Attendance Indexes
CREATE INDEX idx_student_attendance_date ON student_attendance(attendance_date);
CREATE INDEX idx_student_attendance_student ON student_attendance(student_id);
CREATE INDEX idx_staff_attendance_date ON staff_attendance(attendance_date);
CREATE INDEX idx_staff_attendance_staff ON staff_attendance(staff_id);

-- Inventory Indexes
CREATE INDEX idx_inventory_items_category ON inventory_items(category);
CREATE INDEX idx_inventory_items_status ON inventory_items(status);
CREATE INDEX idx_inventory_transactions_item ON inventory_transactions(item_id);

-- Communication Indexes
CREATE INDEX idx_communication_log_recipient ON communication_log(recipient_contact);
CREATE INDEX idx_communication_log_status ON communication_log(status);
CREATE INDEX idx_communication_log_date ON communication_log(created_at);

-- Audit Indexes
CREATE INDEX idx_audit_log_user ON audit_log(user_id);
CREATE INDEX idx_audit_log_action ON audit_log(action_type);
CREATE INDEX idx_audit_log_date ON audit_log(created_at);

-- ==========================================
-- NOTES
-- ==========================================

/*
IMPLEMENTATION NOTES:

1. This schema extends the base schema and revenue/expenditure schema
2. All tables maintain proper foreign key relationships
3. Audit trail is built into most tables via created_at, updated_at
4. Status enums ensure data consistency
5. Indexes are strategically placed for performance

SECURITY CONSIDERATIONS:

1. Implement row-level security for multi-organization access
2. Encrypt sensitive data (contact info, addresses)
3. Regular audit log reviews
4. API rate limiting per user role
5. Field-level permissions

NEXT STEPS:

1. Create stored procedures for complex operations
2. Set up triggers for automatic calculations
3. Create materialized views for reporting
4. Implement backup and recovery procedures
5. Set up replication for high availability
*/
