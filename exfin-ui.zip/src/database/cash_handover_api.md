# Cash Handover System - API Endpoints

## Overview
Complete API documentation for the Cash Handover System with full transparency and approval workflows.

## Base URL
```
/api/cash-handover
```

## Authentication
All endpoints require valid JWT token with accountant permissions.

---

## 1. Get Accountant Balance

### GET `/api/cash-handover/balance/{accountant_id}`

Get current cash balance for a specific accountant.

**Parameters:**
- `accountant_id` (path): Accountant ID

**Response:**
```json
{
  "success": true,
  "data": {
    "accountant_id": 1,
    "accountant_name": "Manikantha Kumar",
    "branch_name": "Main Branch",
    "cash_in_hand": 25000.00,
    "pending_outgoing": 0.00,
    "pending_incoming": 10000.00,
    "effective_balance": 35000.00,
    "last_updated": "2024-12-20T10:30:00Z"
  }
}
```

---

## 2. Get All Accountant Balances

### GET `/api/cash-handover/balances`

Get cash balances for all accountants (read-only view).

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "accountant_id": 1,
      "accountant_name": "Manikantha Kumar",
      "branch_name": "Main Branch",
      "cash_in_hand": 25000.00,
      "pending_outgoing": 0.00,
      "pending_incoming": 10000.00,
      "effective_balance": 35000.00,
      "pending_outgoing_count": 0,
      "pending_incoming_count": 1,
      "last_updated": "2024-12-20T10:30:00Z"
    }
  ]
}
```

---

## 3. Initiate Cash Transfer

### POST `/api/cash-handover/transfer/initiate`

Initiate a new cash transfer from current accountant to another.

**Request Body:**
```json
{
  "to_accountant_id": 2,
  "to_accountant_name": "Prasad Rao",
  "amount": 10000.00,
  "reason": "Urgent bill payment for XYZ vendor",
  "notes": "Required for immediate vendor payment"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Cash transfer initiated successfully",
  "data": {
    "transfer_id": 123,
    "transfer_ref": "CT-20241220-001",
    "from_accountant_name": "Manikantha Kumar",
    "to_accountant_name": "Prasad Rao",
    "amount": 10000.00,
    "status": "pending",
    "initiated_date": "2024-12-20T10:30:00Z",
    "new_balance": 15000.00
  }
}
```

**Error Response:**
```json
{
  "success": false,
  "error": "Insufficient balance",
  "message": "Available balance: ₹8,000. Cannot transfer ₹10,000."
}
```

---

## 4. Get Pending Incoming Transfers

### GET `/api/cash-handover/transfers/pending-incoming`

Get all pending transfers waiting for current user's approval.

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 123,
      "transfer_ref": "CT-20241220-001",
      "from_accountant_id": 1,
      "from_accountant_name": "Manikantha Kumar",
      "amount": 10000.00,
      "reason": "Urgent bill payment for XYZ vendor",
      "notes": "Required for immediate vendor payment",
      "initiated_date": "2024-12-20T10:30:00Z",
      "status": "pending"
    }
  ]
}
```

---

## 5. Approve Cash Transfer

### POST `/api/cash-handover/transfer/approve`

Approve a pending cash transfer.

**Request Body:**
```json
{
  "transfer_ref": "CT-20241220-001"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Cash transfer approved successfully",
  "data": {
    "transfer_ref": "CT-20241220-001",
    "amount": 10000.00,
    "from_accountant": "Manikantha Kumar",
    "status": "completed",
    "completed_date": "2024-12-20T11:15:00Z",
    "new_balance": 28500.00
  }
}
```

---

## 6. Reject Cash Transfer

### POST `/api/cash-handover/transfer/reject`

Reject a pending cash transfer.

**Request Body:**
```json
{
  "transfer_ref": "CT-20241220-001",
  "rejection_reason": "Not required at this time"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Cash transfer rejected successfully",
  "data": {
    "transfer_ref": "CT-20241220-001",
    "amount": 10000.00,
    "from_accountant": "Manikantha Kumar",
    "status": "rejected",
    "rejection_reason": "Not required at this time",
    "responded_date": "2024-12-20T11:20:00Z"
  }
}
```

---

## 7. Get Transfer History

### GET `/api/cash-handover/transfers/history`

Get transfer history for current accountant.

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Records per page (default: 20)
- `status` (optional): Filter by status (pending, completed, rejected)
- `type` (optional): Filter by type (incoming, outgoing, all)

**Response:**
```json
{
  "success": true,
  "data": {
    "transfers": [
      {
        "id": 123,
        "transfer_ref": "CT-20241220-001",
        "type": "outgoing",
        "counterpart": "Prasad Rao",
        "amount": 10000.00,
        "reason": "Urgent bill payment for XYZ vendor",
        "status": "completed",
        "initiated_date": "2024-12-20T10:30:00Z",
        "responded_date": "2024-12-20T11:15:00Z",
        "response_time_minutes": 45
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 20,
      "total": 1,
      "pages": 1
    }
  }
}
```

---

## 8. Get Transfer Details

### GET `/api/cash-handover/transfer/{transfer_ref}`

Get detailed information about a specific transfer.

**Parameters:**
- `transfer_ref` (path): Transfer reference number

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 123,
    "transfer_ref": "CT-20241220-001",
    "from_accountant_id": 1,
    "from_accountant_name": "Manikantha Kumar",
    "to_accountant_id": 2,
    "to_accountant_name": "Prasad Rao",
    "amount": 10000.00,
    "reason": "Urgent bill payment for XYZ vendor",
    "notes": "Required for immediate vendor payment",
    "status": "completed",
    "initiated_date": "2024-12-20T10:30:00Z",
    "responded_date": "2024-12-20T11:15:00Z",
    "completed_date": "2024-12-20T11:15:00Z",
    "initiated_by": "Manikantha Kumar",
    "responded_by": "Prasad Rao",
    "sender_balance_before": 25000.00,
    "sender_balance_after": 15000.00,
    "receiver_balance_before": 18500.00,
    "receiver_balance_after": 28500.00,
    "audit_trail": [
      {
        "action_type": "initiated",
        "action_description": "Cash transfer initiated for ₹10,000.00 to Prasad Rao",
        "performed_by": "Manikantha Kumar",
        "performed_at": "2024-12-20T10:30:00Z",
        "status": "pending"
      },
      {
        "action_type": "approved",
        "action_description": "Cash transfer approved and completed for ₹10,000.00",
        "performed_by": "Prasad Rao",
        "performed_at": "2024-12-20T11:15:00Z",
        "status": "completed"
      }
    ]
  }
}
```

---

## 9. Get Available Accountants

### GET `/api/cash-handover/accountants`

Get list of accountants available for transfer (excluding current user).

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "accountant_id": 2,
      "accountant_name": "Prasad Rao",
      "branch_name": "BC-1 Branch",
      "email": "prasad@sriviswa.edu.in",
      "status": "active"
    }
  ]
}
```

---

## 10. Get Transfer Analytics

### GET `/api/cash-handover/analytics`

Get transfer analytics and summary data.

**Query Parameters:**
- `period` (optional): Period filter (today, week, month, year)
- `from_date` (optional): Start date (YYYY-MM-DD)
- `to_date` (optional): End date (YYYY-MM-DD)

**Response:**
```json
{
  "success": true,
  "data": {
    "summary": {
      "total_transfers": 15,
      "completed_transfers": 12,
      "pending_transfers": 2,
      "rejected_transfers": 1,
      "total_amount": 125000.00,
      "completed_amount": 110000.00,
      "avg_response_time_minutes": 35
    },
    "daily_stats": [
      {
        "date": "2024-12-20",
        "transfers": 3,
        "amount": 25000.00,
        "avg_response_time": 42
      }
    ],
    "top_senders": [
      {
        "accountant_name": "Manikantha Kumar",
        "transfer_count": 5,
        "total_amount": 45000.00
      }
    ],
    "top_receivers": [
      {
        "accountant_name": "Prasad Rao",
        "transfer_count": 4,
        "total_amount": 38000.00
      }
    ]
  }
}
```

---

## 11. Get Audit Trail

### GET `/api/cash-handover/audit`

Get complete audit trail for transfers (Admin only).

**Query Parameters:**
- `transfer_ref` (optional): Filter by specific transfer
- `accountant_id` (optional): Filter by accountant
- `action_type` (optional): Filter by action type
- `from_date` (optional): Start date
- `to_date` (optional): End date

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "transfer_ref": "CT-20241220-001",
      "action_type": "initiated",
      "action_description": "Cash transfer initiated for ₹10,000.00 to Prasad Rao",
      "performed_by": "Manikantha Kumar",
      "performed_at": "2024-12-20T10:30:00Z",
      "old_status": null,
      "new_status": "pending",
      "amount": 10000.00,
      "ip_address": "192.168.1.100"
    }
  ]
}
```

---

## Error Codes

| Code | Message | Description |
|------|---------|-------------|
| 400 | Invalid request data | Missing or invalid request parameters |
| 401 | Unauthorized | Invalid or missing authentication token |
| 403 | Forbidden | Insufficient permissions |
| 404 | Transfer not found | Transfer reference doesn't exist |
| 409 | Insufficient balance | Not enough cash for transfer |
| 409 | Invalid transfer status | Transfer not in correct status for operation |
| 422 | Validation error | Data validation failed |
| 500 | Internal server error | Server-side error |

---

## Rate Limiting

- **Transfer Initiation**: 10 requests per minute per user
- **Approval/Rejection**: 20 requests per minute per user
- **Read Operations**: 100 requests per minute per user

---

## Webhook Notifications

The system can send webhook notifications for:

1. **Transfer Initiated**: When a new transfer is created
2. **Transfer Approved**: When a transfer is approved
3. **Transfer Rejected**: When a transfer is rejected
4. **Balance Low**: When accountant balance falls below threshold

**Webhook Payload:**
```json
{
  "event_type": "transfer_initiated",
  "timestamp": "2024-12-20T10:30:00Z",
  "data": {
    "transfer_ref": "CT-20241220-001",
    "from_accountant": "Manikantha Kumar",
    "to_accountant": "Prasad Rao",
    "amount": 10000.00,
    "reason": "Urgent bill payment"
  }
}
```

---

## Testing

### Postman Collection
Import the provided Postman collection for testing all endpoints:
```
/api/cash-handover/postman-collection.json
```

### Test Scenarios
1. **Happy Path**: Initiate → Approve → Complete
2. **Rejection Flow**: Initiate → Reject → Balance Restored
3. **Insufficient Funds**: Attempt transfer with insufficient balance
4. **Concurrent Transfers**: Multiple transfers from same sender
5. **Invalid Status**: Attempt operations on completed transfers

---

## Security Considerations

1. **Input Validation**: All inputs are validated and sanitized
2. **SQL Injection Protection**: Parameterized queries used
3. **Rate Limiting**: API rate limits prevent abuse
4. **Audit Logging**: All actions are logged with timestamps
5. **Balance Verification**: Double-check balances before transactions
6. **Transaction Isolation**: Database transactions ensure consistency
7. **Permission Checking**: Users can only access their own data
8. **HTTPS Required**: All API calls must use HTTPS