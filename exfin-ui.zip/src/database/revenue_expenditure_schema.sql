-- ==========================================
-- REVENUE & EXPENDITURE MANAGEMENT SCHEMA
-- Sri Venkateswara Enterprises
-- Educational Institution Finance System
-- ==========================================

-- ==========================================
-- 1. STUDENT MASTER TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS students (
    student_id VARCHAR(20) PRIMARY KEY,
    admission_number VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    full_name VARCHAR(200) GENERATED ALWAYS AS (first_name || ' ' || last_name) STORED,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(10) CHECK (gender IN ('Male', 'Female', 'Other')),
    
    -- Academic Information
    class_id INT REFERENCES classes(id),
    section VARCHAR(10),
    roll_number VARCHAR(20),
    academic_year VARCHAR(10) NOT NULL,
    admission_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Passed Out', 'Transferred')),
    
    -- Contact Information
    email VARCHAR(255),
    phone VARCHAR(20),
    parent_phone VARCHAR(20) NOT NULL,
    parent_email VARCHAR(255),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    pincode VARCHAR(10),
    
    -- Organization
    organization_id INT REFERENCES organizations(id),
    branch_id INT REFERENCES branches(id),
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT REFERENCES users(id),
    updated_by INT REFERENCES users(id)
);

-- ==========================================
-- 2. CLASSES/COURSES TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS classes (
    id SERIAL PRIMARY KEY,
    class_name VARCHAR(100) NOT NULL,
    class_type VARCHAR(50) CHECK (class_type IN ('Primary', 'Secondary', 'Higher Secondary', 'Undergraduate', 'Postgraduate')),
    department VARCHAR(100),
    organization_id INT REFERENCES organizations(id),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 3. FEE MASTER TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS fee_master (
    id SERIAL PRIMARY KEY,
    fee_code VARCHAR(20) UNIQUE NOT NULL,
    fee_name VARCHAR(100) NOT NULL,
    fee_category VARCHAR(50) CHECK (fee_category IN ('Tuition', 'Admission', 'Library', 'Lab', 'Transport', 'Sports', 'Annual', 'Exam', 'Mess', 'Hostel', 'Other')),
    
    -- Amount Configuration
    amount DECIMAL(10, 2) NOT NULL,
    is_mandatory BOOLEAN DEFAULT TRUE,
    frequency VARCHAR(20) CHECK (frequency IN ('One Time', 'Monthly', 'Quarterly', 'Half Yearly', 'Annual')),
    
    -- Applicability
    organization_id INT REFERENCES organizations(id),
    class_id INT REFERENCES classes(id),
    academic_year VARCHAR(10),
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    effective_from DATE,
    effective_to DATE,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT REFERENCES users(id)
);

-- ==========================================
-- 4. REVENUE TRANSACTIONS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS revenue_transactions (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(50) UNIQUE NOT NULL,
    receipt_number VARCHAR(50) UNIQUE NOT NULL,
    
    -- Revenue Type
    revenue_type VARCHAR(50) NOT NULL CHECK (revenue_type IN ('Student Fee', 'Examination Fee', 'Mess Fee', 'Institution Fee', 'Donation/Grant', 'Other Income')),
    
    -- Student Information (for fee-related entries)
    student_id VARCHAR(20) REFERENCES students(student_id),
    student_name VARCHAR(200),
    class_grade VARCHAR(100),
    
    -- Fee Details
    fee_id INT REFERENCES fee_master(id),
    fee_type VARCHAR(100),
    
    -- Donation/Grant Details
    donor_name VARCHAR(200),
    purpose VARCHAR(500),
    gst_number VARCHAR(20),
    
    -- Financial Information
    amount DECIMAL(12, 2) NOT NULL,
    payment_mode VARCHAR(20) CHECK (payment_mode IN ('Cash', 'Online', 'Cheque', 'DD', 'UPI', 'Card')),
    payment_reference VARCHAR(100),
    transaction_date DATE NOT NULL,
    
    -- Status
    payment_status VARCHAR(20) DEFAULT 'Paid' CHECK (payment_status IN ('Paid', 'Pending', 'Partial', 'Cancelled', 'Refunded')),
    
    -- Academic Period
    academic_year VARCHAR(10) NOT NULL,
    financial_year VARCHAR(10),
    month_name VARCHAR(20),
    
    -- Organization/Branch
    organization_id INT REFERENCES organizations(id),
    branch_id INT REFERENCES branches(id),
    
    -- Additional Information
    description TEXT,
    remarks TEXT,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT REFERENCES users(id),
    updated_by INT REFERENCES users(id),
    
    -- Audit
    is_deleted BOOLEAN DEFAULT FALSE,
    deleted_at TIMESTAMP,
    deleted_by INT REFERENCES users(id)
);

-- ==========================================
-- 5. STAFF MASTER TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS staff (
    id SERIAL PRIMARY KEY,
    staff_id VARCHAR(20) UNIQUE NOT NULL,
    employee_code VARCHAR(50) UNIQUE NOT NULL,
    
    -- Personal Information
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    full_name VARCHAR(200) GENERATED ALWAYS AS (first_name || ' ' || last_name) STORED,
    date_of_birth DATE,
    gender VARCHAR(10) CHECK (gender IN ('Male', 'Female', 'Other')),
    
    -- Employment Information
    designation VARCHAR(100) NOT NULL,
    department VARCHAR(100),
    date_of_joining DATE NOT NULL,
    employment_type VARCHAR(50) CHECK (employment_type IN ('Permanent', 'Contract', 'Part-Time', 'Temporary')),
    status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Resigned', 'Terminated')),
    
    -- Salary Information
    basic_salary DECIMAL(10, 2),
    gross_salary DECIMAL(10, 2),
    pf_applicable BOOLEAN DEFAULT TRUE,
    esi_applicable BOOLEAN DEFAULT FALSE,
    
    -- Contact Information
    email VARCHAR(255),
    phone VARCHAR(20) NOT NULL,
    address TEXT,
    
    -- Organization
    organization_id INT REFERENCES organizations(id),
    branch_id INT REFERENCES branches(id),
    
    -- Bank Details
    bank_name VARCHAR(100),
    account_number VARCHAR(50),
    ifsc_code VARCHAR(20),
    pan_number VARCHAR(20),
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT REFERENCES users(id)
);

-- ==========================================
-- 6. VENDOR MASTER TABLE (Enhanced)
-- ==========================================
CREATE TABLE IF NOT EXISTS vendors (
    id SERIAL PRIMARY KEY,
    vendor_code VARCHAR(20) UNIQUE NOT NULL,
    vendor_name VARCHAR(200) NOT NULL,
    
    -- Vendor Type
    vendor_type VARCHAR(50) CHECK (vendor_type IN ('Supplier', 'Service Provider', 'Contractor', 'Utility', 'Other')),
    vendor_category VARCHAR(100),
    
    -- Contact Information
    contact_person VARCHAR(100),
    email VARCHAR(255),
    phone VARCHAR(20) NOT NULL,
    alternate_phone VARCHAR(20),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    pincode VARCHAR(10),
    
    -- Business Information
    gst_number VARCHAR(20),
    pan_number VARCHAR(20),
    tan_number VARCHAR(20),
    
    -- Bank Details
    bank_name VARCHAR(100),
    account_number VARCHAR(50),
    ifsc_code VARCHAR(20),
    
    -- Payment Terms
    payment_terms VARCHAR(100),
    credit_days INT DEFAULT 0,
    
    -- Organization
    organization_id INT REFERENCES organizations(id),
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Blocked')),
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT REFERENCES users(id),
    
    -- Notes
    remarks TEXT
);

-- ==========================================
-- 7. EXPENDITURE TRANSACTIONS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS expenditure_transactions (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(50) UNIQUE NOT NULL,
    
    -- Expenditure Category
    category VARCHAR(50) NOT NULL CHECK (category IN ('Salaries', 'Rent & Utilities', 'Purchases', 'Maintenance', 'Events & Activities', 'Loan Repayments', 'Miscellaneous')),
    
    -- Salary-related fields
    staff_id VARCHAR(20) REFERENCES staff(staff_id),
    staff_name VARCHAR(200),
    designation VARCHAR(100),
    salary_month VARCHAR(20),
    gross_salary DECIMAL(10, 2),
    deductions DECIMAL(10, 2),
    net_pay DECIMAL(10, 2),
    
    -- Vendor-related fields
    vendor_id INT REFERENCES vendors(id),
    vendor_name VARCHAR(200),
    bill_number VARCHAR(50),
    invoice_number VARCHAR(50),
    
    -- Purchase-related fields
    item_name VARCHAR(200),
    quantity DECIMAL(10, 2),
    rate DECIMAL(10, 2),
    
    -- Service/Maintenance fields
    service_type VARCHAR(100),
    
    -- Event-related fields
    event_name VARCHAR(200),
    budget_allocated DECIMAL(12, 2),
    actual_spend DECIMAL(12, 2),
    
    -- Loan-related fields
    loan_id VARCHAR(50),
    emi_amount DECIMAL(10, 2),
    balance_amount DECIMAL(12, 2),
    
    -- Financial Information
    amount DECIMAL(12, 2) NOT NULL,
    payment_mode VARCHAR(20) CHECK (payment_mode IN ('Cash', 'Online', 'Cheque', 'DD', 'UPI', 'Card')),
    payment_reference VARCHAR(100),
    
    -- Dates
    transaction_date DATE NOT NULL,
    due_date DATE,
    paid_date DATE,
    
    -- Status
    payment_status VARCHAR(20) DEFAULT 'Pending' CHECK (payment_status IN ('Paid', 'Pending', 'Approved', 'Rejected', 'Cancelled')),
    approval_status VARCHAR(20) DEFAULT 'Pending' CHECK (approval_status IN ('Pending', 'Approved', 'Rejected')),
    approved_by INT REFERENCES users(id),
    approved_at TIMESTAMP,
    
    -- Tax Information
    tds_applicable BOOLEAN DEFAULT FALSE,
    tds_amount DECIMAL(10, 2),
    tds_percentage DECIMAL(5, 2),
    gst_applicable BOOLEAN DEFAULT FALSE,
    gst_amount DECIMAL(10, 2),
    gst_percentage DECIMAL(5, 2),
    
    -- Organization/Branch
    organization_id INT REFERENCES organizations(id),
    branch_id INT REFERENCES branches(id),
    
    -- Financial Period
    financial_year VARCHAR(10),
    month_name VARCHAR(20),
    
    -- Additional Information
    description TEXT NOT NULL,
    remarks TEXT,
    
    -- Attachments
    attachment_count INT DEFAULT 0,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_by INT REFERENCES users(id),
    updated_by INT REFERENCES users(id),
    
    -- Audit
    is_deleted BOOLEAN DEFAULT FALSE,
    deleted_at TIMESTAMP,
    deleted_by INT REFERENCES users(id)
);

-- ==========================================
-- 8. TRANSACTION ATTACHMENTS TABLE
-- ==========================================
CREATE TABLE IF NOT EXISTS transaction_attachments (
    id SERIAL PRIMARY KEY,
    transaction_type VARCHAR(20) CHECK (transaction_type IN ('Revenue', 'Expenditure')),
    transaction_id INT,
    
    -- File Information
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(50),
    file_size BIGINT,
    
    -- Description
    description TEXT,
    
    -- Metadata
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    uploaded_by INT REFERENCES users(id)
);

-- ==========================================
-- 9. REVENUE SUMMARY BY CATEGORY (Materialized View for Performance)
-- ==========================================
CREATE MATERIALIZED VIEW IF NOT EXISTS revenue_summary_by_category AS
SELECT 
    revenue_type,
    organization_id,
    academic_year,
    COUNT(*) as transaction_count,
    SUM(amount) as total_amount,
    AVG(amount) as average_amount,
    MIN(transaction_date) as first_transaction,
    MAX(transaction_date) as last_transaction
FROM revenue_transactions
WHERE is_deleted = FALSE
GROUP BY revenue_type, organization_id, academic_year;

-- ==========================================
-- 10. EXPENDITURE SUMMARY BY CATEGORY (Materialized View)
-- ==========================================
CREATE MATERIALIZED VIEW IF NOT EXISTS expenditure_summary_by_category AS
SELECT 
    category,
    organization_id,
    financial_year,
    COUNT(*) as transaction_count,
    SUM(amount) as total_amount,
    AVG(amount) as average_amount,
    SUM(CASE WHEN payment_status = 'Paid' THEN amount ELSE 0 END) as paid_amount,
    SUM(CASE WHEN payment_status = 'Pending' THEN amount ELSE 0 END) as pending_amount
FROM expenditure_transactions
WHERE is_deleted = FALSE
GROUP BY category, organization_id, financial_year;

-- ==========================================
-- 11. INDEXES FOR PERFORMANCE
-- ==========================================

-- Revenue Transactions Indexes
CREATE INDEX idx_revenue_transaction_date ON revenue_transactions(transaction_date);
CREATE INDEX idx_revenue_student ON revenue_transactions(student_id);
CREATE INDEX idx_revenue_type ON revenue_transactions(revenue_type);
CREATE INDEX idx_revenue_academic_year ON revenue_transactions(academic_year);
CREATE INDEX idx_revenue_organization ON revenue_transactions(organization_id);
CREATE INDEX idx_revenue_status ON revenue_transactions(payment_status);
CREATE INDEX idx_revenue_receipt ON revenue_transactions(receipt_number);

-- Expenditure Transactions Indexes
CREATE INDEX idx_expenditure_transaction_date ON expenditure_transactions(transaction_date);
CREATE INDEX idx_expenditure_category ON expenditure_transactions(category);
CREATE INDEX idx_expenditure_staff ON expenditure_transactions(staff_id);
CREATE INDEX idx_expenditure_vendor ON expenditure_transactions(vendor_id);
CREATE INDEX idx_expenditure_organization ON expenditure_transactions(organization_id);
CREATE INDEX idx_expenditure_payment_status ON expenditure_transactions(payment_status);
CREATE INDEX idx_expenditure_approval_status ON expenditure_transactions(approval_status);

-- Student Indexes
CREATE INDEX idx_student_class ON students(class_id);
CREATE INDEX idx_student_organization ON students(organization_id);
CREATE INDEX idx_student_status ON students(status);
CREATE INDEX idx_student_academic_year ON students(academic_year);

-- Staff Indexes
CREATE INDEX idx_staff_organization ON staff(organization_id);
CREATE INDEX idx_staff_department ON staff(department);
CREATE INDEX idx_staff_status ON staff(status);

-- Vendor Indexes
CREATE INDEX idx_vendor_type ON vendors(vendor_type);
CREATE INDEX idx_vendor_status ON vendors(status);
CREATE INDEX idx_vendor_organization ON vendors(organization_id);

-- ==========================================
-- 12. AUDIT TRIGGERS
-- ==========================================

-- Revenue Transaction Audit
CREATE OR REPLACE FUNCTION audit_revenue_transaction()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'UPDATE') THEN
        NEW.updated_at = CURRENT_TIMESTAMP;
        NEW.updated_by = CURRENT_USER;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER revenue_transaction_audit
BEFORE UPDATE ON revenue_transactions
FOR EACH ROW EXECUTE FUNCTION audit_revenue_transaction();

-- Expenditure Transaction Audit
CREATE OR REPLACE FUNCTION audit_expenditure_transaction()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'UPDATE') THEN
        NEW.updated_at = CURRENT_TIMESTAMP;
        NEW.updated_by = CURRENT_USER;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER expenditure_transaction_audit
BEFORE UPDATE ON expenditure_transactions
FOR EACH ROW EXECUTE FUNCTION audit_expenditure_transaction();

-- ==========================================
-- 13. CONSTRAINTS AND VALIDATIONS
-- ==========================================

-- Ensure paid_date is not before transaction_date
ALTER TABLE expenditure_transactions
ADD CONSTRAINT chk_paid_date_after_transaction 
CHECK (paid_date IS NULL OR paid_date >= transaction_date);

-- Ensure due_date is not before transaction_date
ALTER TABLE expenditure_transactions
ADD CONSTRAINT chk_due_date_after_transaction 
CHECK (due_date IS NULL OR due_date >= transaction_date);

-- Ensure net_pay calculation is correct
ALTER TABLE expenditure_transactions
ADD CONSTRAINT chk_net_pay_calculation 
CHECK (net_pay IS NULL OR net_pay = (gross_salary - COALESCE(deductions, 0)));

-- Ensure actual_spend doesn't exceed budget (with warning)
ALTER TABLE expenditure_transactions
ADD CONSTRAINT chk_budget_warning 
CHECK (actual_spend IS NULL OR budget_allocated IS NULL OR actual_spend <= (budget_allocated * 1.5));

-- Revenue amount must be positive
ALTER TABLE revenue_transactions
ADD CONSTRAINT chk_revenue_amount_positive 
CHECK (amount > 0);

-- Expenditure amount must be positive
ALTER TABLE expenditure_transactions
ADD CONSTRAINT chk_expenditure_amount_positive 
CHECK (amount > 0);

-- ==========================================
-- NOTES AND USAGE
-- ==========================================

/*
USAGE INSTRUCTIONS:

1. This schema is designed to work with the existing schema.sql
   Make sure organizations, branches, and users tables exist first

2. To refresh materialized views:
   REFRESH MATERIALIZED VIEW revenue_summary_by_category;
   REFRESH MATERIALIZED VIEW expenditure_summary_by_category;

3. For automatic refresh, set up a cron job or scheduled task

4. Transaction IDs should follow pattern:
   Revenue: REV-YYYY-MM-DD-XXXX
   Expenditure: EXP-YYYY-MM-DD-XXXX

5. Receipt numbers should be unique and follow organization policy

6. All monetary amounts are stored with 2 decimal precision

7. For soft deletes, use is_deleted flag instead of actual DELETE

8. Audit trail is automatically maintained via triggers

SECURITY RECOMMENDATIONS:

1. Create separate database roles for Admin, Management, Accountant
2. Grant SELECT only to Viewer role
3. Implement row-level security for multi-organization access
4. Use prepared statements to prevent SQL injection
5. Encrypt sensitive data like PAN, account numbers
6. Regular backups and point-in-time recovery setup
7. Monitor for unusual transaction patterns

PERFORMANCE OPTIMIZATION:

1. Regularly ANALYZE tables after bulk inserts
2. Vacuum regularly to maintain table health
3. Monitor index usage and drop unused indexes
4. Partition large tables by financial_year if needed
5. Use connection pooling for better resource management
*/
