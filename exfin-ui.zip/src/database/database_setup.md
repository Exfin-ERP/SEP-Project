# Sri Venkateswara Enterprises Database Setup Guide

## Overview
This guide provides complete instructions for setting up the Sri Venkateswara Enterprises database with all necessary tables, stored procedures, triggers, views, and sample data.

## Prerequisites
- MySQL 8.0 or higher
- MySQL client or MySQL Workbench
- Sufficient database privileges (CREATE, ALTER, INSERT, UPDATE, DELETE, EXECUTE)

## Database Files Structure
```
/database/
├── schema.sql              # Main database schema with all tables
├── sample_data.sql         # Sample data for testing
├── stored_procedures.sql   # Stored procedures for business logic
├── triggers.sql           # Database triggers for automation
├── views.sql              # Database views for reporting
├── api_endpoints.md       # API documentation
└── database_setup.md      # This setup guide
```

## Setup Instructions

### 1. Create Database and Execute Schema
```sql
-- Connect to MySQL as root or admin user
mysql -u root -p

-- Execute the main schema file
source /path/to/database/schema.sql;
```

### 2. Load Sample Data
```sql
-- Execute sample data
source /path/to/database/sample_data.sql;
```

### 3. Create Stored Procedures
```sql
-- Execute stored procedures
source /path/to/database/stored_procedures.sql;
```

### 4. Create Triggers
```sql
-- Execute triggers
source /path/to/database/triggers.sql;
```

### 5. Create Views
```sql
-- Execute views
source /path/to/database/views.sql;
```

## Database Schema Overview

### Core Tables

#### 1. Organizations
- Manages different educational societies (Pragyana, Sriven, Sriviswa)
- Contains organization details and contact information

#### 2. Teams
- Manages teams within organizations (Pragyana Team, Sriven Team, etc.)
- Links to organizations and team leads

#### 3. Branches
- Manages school and college branches/campuses
- Links to organizations and teams
- Contains performance metrics

#### 4. Users
- Manages all system users with role-based access
- Supports Admin, Management, Accountant, and Viewer roles
- Includes OTP authentication fields

#### 5. Expenses
- Core expense/transaction management
- Comprehensive tracking of financial transactions
- Includes approval workflow and audit trail

#### 6. Vendors
- Manages vendor registration and information
- Supports different vendor types (electricity, mess, rental, etc.)
- Includes approval workflow

#### 7. Balance Tracking
- Daily balance tracking per branch/team
- Opening/closing balance management
- Transaction summaries

### Supporting Tables

#### 8. Expense Categories
- Predefined expense categories (maintenance, mess, salary, etc.)

#### 9. File Attachments
- File storage metadata for expense attachments
- Supports multiple file types

#### 10. Notifications
- User notification system
- Expense approval notifications
- System notifications

#### 11. Audit Logs
- Comprehensive audit trail
- Tracks all data changes
- User action logging

#### 12. System Settings
- Configurable system parameters
- Application settings management

## Key Features

### 1. Role-Based Access Control
- **Admin**: Full system access, vendor management, user management
- **Management**: Financial reports, expense approvals, analytics
- **Accountant**: Expense entry, balance tracking, transaction management
- **Viewer**: Read-only access to financial data

### 2. Team-Based Workflow
- **Pragyana Team**: Manages school finances (5 branches)
- **Sriven Team**: Manages college finances (12 branches)
- **Central Admin Team**: Overall system administration

### 3. Expense Management
- Complete expense lifecycle management
- Approval workflow (Accountant → Team → Admin)
- Payment status tracking (Paid/Unpaid/Advance)
- Bill attachment support

### 4. Automated Features
- Auto-generation of expense and vendor codes
- Automatic team assignment based on branch
- Balance tracking updates
- Notification system
- Audit trail logging

## Sample Data Included

### Organizations
- Pragyana Educational Society
- Sriven Educational Society  
- Sri Venkateswara Enterprises

### Users
- 2 Admin users (PSN Sir, Sridhar Sir)
- 2 Management users
- 8 Accountant users (distributed across branches)
- 2 Viewer users

### Branches
- 5 School branches (Pragyana Team)
- 12 College branches (Sriven Team)

### Vendors
- 5 Sample vendors (electricity, rental, mess, water, supplies)

### Expenses
- 5 Sample expense transactions
- Different statuses and payment modes
- Realistic amounts and descriptions

## Security Considerations

### 1. Authentication
- OTP-based login system
- JWT token management
- Session timeout controls

### 2. Data Protection
- Audit logging for all critical operations
- Role-based data access
- Input validation through stored procedures

### 3. Financial Controls
- Approval workflow enforcement
- Balance validation
- Transaction limits

## Performance Optimizations

### 1. Database Indexes
```sql
-- Key indexes for performance
CREATE INDEX idx_expenses_date ON expenses(date);
CREATE INDEX idx_expenses_status ON expenses(status);
CREATE INDEX idx_expenses_accountant ON expenses(accountant_id);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_vendors_status ON vendors(status);
```

### 2. Views for Complex Queries
- `view_expense_details`: Complete expense information
- `view_user_dashboard`: User dashboard data
- `view_monthly_expense_summary`: Monthly financial summaries
- `view_pending_approvals`: Pending approval workflows

### 3. Stored Procedures for Business Logic
- `AuthenticateUser`: User authentication
- `CreateExpense`: Expense creation with validation
- `UpdateExpenseStatus`: Approval/rejection workflow
- `GetDashboardData`: Dashboard analytics

## Backup and Maintenance

### 1. Regular Backups
```bash
# Daily backup script
mysqldump -u backup_user -p sriviswa_finance > backup_$(date +%Y%m%d).sql
```

### 2. Data Archival
```sql
-- Archive old expenses (older than 2 years)
CREATE TABLE expenses_archive LIKE expenses;
INSERT INTO expenses_archive SELECT * FROM expenses WHERE date < DATE_SUB(CURDATE(), INTERVAL 2 YEAR);
```

### 3. Performance Monitoring
```sql
-- Check slow queries
SELECT * FROM mysql.slow_log WHERE start_time > DATE_SUB(NOW(), INTERVAL 1 DAY);

-- Check table sizes
SELECT table_name, ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'Size (MB)'
FROM information_schema.tables 
WHERE table_schema = 'sriviswa_finance'
ORDER BY (data_length + index_length) DESC;
```

## Testing the Setup

### 1. Verify Tables
```sql
USE sriviswa_finance;
SHOW TABLES;
SELECT COUNT(*) FROM users; -- Should return 12
SELECT COUNT(*) FROM branches; -- Should return 17
SELECT COUNT(*) FROM expenses; -- Should return 5
```

### 2. Test Authentication
```sql
CALL GenerateOTP('admin@sriviswa.edu.in', NULL);
-- Use the returned OTP to test authentication
CALL AuthenticateUser('admin@sriviswa.edu.in', NULL, '<otp_code>');
```

### 3. Test Expense Creation
```sql
CALL CreateExpense(
    25000.00, 2, 'Test expense', 'Testing expense creation', 
    CURDATE(), 'Test notes', 1, 'CASH', 'Unpaid', TRUE, 
    'PSN SIR', 4, NULL
);
```

## Troubleshooting

### Common Issues

#### 1. Permission Errors
```sql
-- Grant necessary permissions
GRANT ALL PRIVILEGES ON sriviswa_finance.* TO 'app_user'@'localhost';
FLUSH PRIVILEGES;
```

#### 2. Foreign Key Constraints
```sql
-- Temporarily disable foreign key checks if needed
SET FOREIGN_KEY_CHECKS = 0;
-- Run your operations
SET FOREIGN_KEY_CHECKS = 1;
```

#### 3. Character Set Issues
```sql
-- Ensure UTF8 character set
ALTER DATABASE sriviswa_finance CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

## Contact and Support
For database-related issues or questions, contact the development team or refer to the API documentation in `api_endpoints.md`.