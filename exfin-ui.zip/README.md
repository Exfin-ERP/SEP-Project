
  # Expenditure Finance Web App (Community)

  This is a code bundle for Expenditure Finance Web App (Community). The original project is available at https://www.figma.com/design/J5KNX6hFisbhKDlXDdZhHs/Expenditure-Finance-Web-App--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  